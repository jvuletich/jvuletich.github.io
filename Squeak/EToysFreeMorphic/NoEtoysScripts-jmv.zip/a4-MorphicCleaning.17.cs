'From Squeak3.7 of ''4 September 2004'' [latest update: #5989] on 6 January 2005 at 11:49:25 pm'!Object subclass: #MorphExtension	instanceVariableNames: 'locked visible sticky balloonText balloonTextSelector externalName isPartsDonor actorState player eventHandler otherProperties '	classVariableNames: ''	poolDictionaries: ''	category: 'Morphic-Kernel'!MorphicModel class	instanceVariableNames: 'prototype '!BorderedMorph subclass: #PasteUpMorph	instanceVariableNames: 'model cursor backgroundMorph worldState '	classVariableNames: 'DisableDeferredUpdates MinCycleLapse '	poolDictionaries: ''	category: 'Morphic-Worlds'!!Object methodsFor: 'copying' stamp: 'jmv 1/6/2005 22:03'!veryDeepCopyWith: deepCopier	"Copy me and the entire tree of objects I point to.  An object in the tree twice is copied once, and both references point to him.  deepCopier holds a dictionary of objects we have seen.  Some classes refuse to be copied.  Some classes are picky about which fields get deep copied."	| class index sub subAss new sup has mine |	deepCopier references at: self ifPresent: [:newer | ^ newer]. 	"already did him"	class _ self class.	class isMeta ifTrue: [^ self].		"a class"	new _ self clone.	deepCopier references at: self put: new.	"remember"	(class isVariable and: [class isPointers]) ifTrue: 		[index _ self basicSize.		[index > 0] whileTrue: 			[sub _ self basicAt: index.			(subAss _ deepCopier references associationAt: sub ifAbsent: [nil])				ifNil: [new basicAt: index put: (sub veryDeepCopyWith: deepCopier)]				ifNotNil: [new basicAt: index put: subAss value].			index _ index - 1]].	"Ask each superclass if it wants to share (weak copy) any inst vars"	new veryDeepInner: deepCopier.		"does super a lot"	"other superclasses want all inst vars deep copied"	sup _ class.  index _ class instSize.	[has _ sup compiledMethodAt: #veryDeepInner: ifAbsent: [nil].	has _ has notNil.	mine _ sup instVarNames.	has ifTrue: [index _ index - mine size]	"skip inst vars"		ifFalse: [1 to: mine size do: [:xx |				sub _ self instVarAt: index.				(subAss _ deepCopier references associationAt: sub ifAbsent: [nil])						"use association, not value, so nil is an exceptional value"					ifNil: [new instVarAt: index put: 								(sub veryDeepCopyWith: deepCopier)]					ifNotNil: [new instVarAt: index put: subAss value].				index _ index - 1]].	(sup _ sup superclass) == nil] whileFalse.	new rehash.	"force Sets and Dictionaries to rehash"	^ new! !!BasicClassOrganizer methodsFor: 'fileIn/Out' stamp: 'jmv 1/6/2005 20:38'!objectForDataStream: refStrm	| dp |	"I am about to be written on an object file.  Write a path to me in the other system instead."	self hasSubject ifTrue: [		(self subject isKindOf: Class) ifTrue: [			dp _ DiskProxy global: self subject name selector: #organization args: #().			refStrm replace: self with: dp.			^ dp]].	^ self	"in desparation"! !!Class methodsFor: 'fileIn/Out' stamp: 'jmv 1/6/2005 20:38'!objectForDataStream: refStrm	| |	"I am about to be written on an object file.  Write a reference to a class in Smalltalk instead."	refStrm insideASegment		ifFalse: ["Normal use"			^ DiskProxy global: self theNonMetaClass name selector: #yourself				args: #()]		ifTrue: ["recording objects to go into an ImageSegment"			(refStrm rootObject includes: self) ifTrue: [^ self].				"is in roots, intensionally write out, ^ self"						"A normal class.  remove it from references.  Do not trace."			refStrm references removeKey: self ifAbsent: []. 	"already there"			^ nil]! !!Class methodsFor: 'fileIn/Out' stamp: 'jmv 1/6/2005 20:39'!storeDataOn: aDataStream	"I don't get stored.  Use a DiskProxy"	self error: 'use a DiskProxy to store a Class'! !!ClassBuilder methodsFor: 'class definition' stamp: 'jmv 1/6/2005 22:01'!recompile: force from: oldClass to: newClass mutate: forceMutation	"Do the necessary recompilation after changine oldClass to newClass.	If required (e.g., when oldClass ~~ newClass) mutate oldClass to newClass	and all its subclasses. If forceMutation is true force a mutation even	if oldClass and newClass are the same."	oldClass == nil ifTrue:[^ newClass].	(newClass == oldClass and:[force not and:[forceMutation not]]) ifTrue:[		^newClass].	currentClassIndex _ 0.	maxClassIndex _ oldClass withAllSubclasses size.	(oldClass == newClass and:[forceMutation not]) ifTrue:[		"Recompile from newClass without mutating"		self informUserDuring:[			newClass withAllSubclassesDo:[:cl|				self showProgressFor: cl.				cl compileAll]].		^newClass].	"Recompile and mutate oldClass to newClass"	self informUserDuring:[		self mutate: oldClass to: newClass.	].	^oldClass "now mutated to newClass"! !!ImageSegment methodsFor: 'read/write segment' stamp: 'jmv 1/6/2005 20:40'!writeForExportWithSources: fName inDirectory: aDirectory	"Write the segment on the disk with all info needed to reconstruct it in a new image.  For export.  Out pointers are encoded as normal objects on the disk.  Append the source code of any classes in roots.  Target system will quickly transfer the sources to its changes file."	"this is the old version which I restored until I solve the gzip problem"	| fileStream temp tempFileName zipper allClassesInRoots classesToWriteEntirely methodsWithSource |	state = #activeCopy ifFalse: [self error: 'wrong state'].	(fName includes: $.) ifFalse: [		^ self inform: 'Please use ''.pr'' or ''.extSeg'' at the end of the file name'.].	temp _ endMarker.	endMarker _ nil.	tempFileName _ aDirectory nextNameFor: 'SqProject' extension: 'temp'.	zipper _ [		ProgressNotification signal: '3:uncompressedSaveComplete'.		(aDirectory oldFileNamed: tempFileName) compressFile.	"makes xxx.gz"		aDirectory 			rename: (tempFileName, FileDirectory dot, 'gz')			toBe: fName.		aDirectory			deleteFileNamed: tempFileName			ifAbsent: []	].	fileStream _ aDirectory newFileNamed: tempFileName.	fileStream fileOutClass: nil andObject: self.		"remember extra structures.  Note class names."	endMarker _ temp.	"append sources"	allClassesInRoots _ arrayOfRoots select: [:cls | cls isKindOf: Behavior].	classesToWriteEntirely _ allClassesInRoots.	methodsWithSource _ OrderedCollection new.	allClassesInRoots do: [ :cls |		(classesToWriteEntirely includes: cls) ifFalse: [			cls selectorsAndMethodsDo: [ :sel :meth |				meth sourcePointer = 0 ifFalse: [methodsWithSource add: {cls. sel. meth}].			].		].	].	(classesToWriteEntirely isEmpty and: [methodsWithSource isEmpty]) ifTrue: [zipper value. ^ self].	fileStream reopen; setToEnd.	fileStream nextPutAll: '\\!!ImageSegment new!!\\' withCRs.	methodsWithSource do: [ :each |		fileStream nextPut: $!!.	"try to pacify ImageSegment>>scanFrom:"		fileStream nextChunkPut: 'RenamedClassSourceReader formerClassName: ',				each first name printString,' methodsFor: ',				(each first organization categoryOfElement: each second) asString printString,				' stamp: ',(Utilities timeStampForMethod: each third) printString; cr.		fileStream nextChunkPut: (each third getSourceFor: each second in: each first) asString.		fileStream nextChunkPut: ' '; cr.	].	classesToWriteEntirely do: [:cls | 		cls isMeta ifFalse: [fileStream nextPutAll: 						(cls name, ' category: ''', cls category, '''.!!'); cr; cr].		cls organization			putCommentOnFile: fileStream			numbered: 0			moveSource: false			forClass: cls.	"does nothing if metaclass"		cls organization categories do: 			[:heading |			cls fileOutCategory: heading				on: fileStream				moveSource: false				toFile: 0]].	"no class initialization -- it came in as a real object"	fileStream close.	zipper value.! !!ImageSegment methodsFor: 'read/write segment' stamp: 'jmv 1/6/2005 20:40'!writeForExportWithSources: fName inDirectory: aDirectory changeSet: aChangeSetOrNil	"Write the segment on the disk with all info needed to reconstruct it in a new image.  For export.  Out pointers are encoded as normal objects on the disk.  Append the source code of any classes in roots.  Target system will quickly transfer the sources to its changes file."	"An experimental version to fileout a changeSet first so that a project can contain its own classes"	| fileStream temp tempFileName zipper allClassesInRoots classesToWriteEntirely methodsWithSource |	state = #activeCopy ifFalse: [self error: 'wrong state'].	(fName includes: $.) ifFalse: [		^ self inform: 'Please use ''.pr'' or ''.extSeg'' at the end of the file name'.].	temp _ endMarker.	endMarker _ nil.	tempFileName _ aDirectory nextNameFor: 'SqProject' extension: 'temp'.	zipper _ [		Preferences debugPrintSpaceLog ifTrue:[			fileStream _ aDirectory newFileNamed: 				(fName copyFrom: 1 to: (fName lastIndexOf: $.)), 'space'.			self printSpaceAnalysisOn: fileStream.			fileStream close].		ProgressNotification signal: '3:uncompressedSaveComplete'.		(aDirectory oldFileNamed: tempFileName) compressFile.	"makes xxx.gz"		aDirectory 			rename: (tempFileName, FileDirectory dot, 'gz')			toBe: fName.		aDirectory			deleteFileNamed: tempFileName			ifAbsent: []	].	fileStream _ aDirectory newFileNamed: tempFileName.	fileStream fileOutChangeSet: aChangeSetOrNil andObject: self.		"remember extra structures.  Note class names."	endMarker _ temp.	"append sources"	allClassesInRoots _ arrayOfRoots select: [:cls | cls isKindOf: Behavior].	classesToWriteEntirely _ allClassesInRoots.	methodsWithSource _ OrderedCollection new.	allClassesInRoots do: [ :cls |		(classesToWriteEntirely includes: cls) ifFalse: [			cls selectorsAndMethodsDo: [ :sel :meth |				meth sourcePointer = 0 ifFalse: [methodsWithSource add: {cls. sel. meth}].			].		].	].	(classesToWriteEntirely isEmpty and: [methodsWithSource isEmpty]) ifTrue: [zipper value. ^ self].	fileStream reopen; setToEnd.	fileStream nextPutAll: '\\!!ImageSegment new!!\\' withCRs.	methodsWithSource do: [ :each |		fileStream nextPut: $!!.	"try to pacify ImageSegment>>scanFrom:"		fileStream nextChunkPut: 'RenamedClassSourceReader formerClassName: ',				each first name printString,' methodsFor: ',				(each first organization categoryOfElement: each second) asString printString,				' stamp: ',(Utilities timeStampForMethod: each third) printString; cr.		fileStream nextChunkPut: (each third getSourceFor: each second in: each first) asString.		fileStream nextChunkPut: ' '; cr.	].	classesToWriteEntirely do: [:cls | 		cls isMeta ifFalse: [fileStream nextPutAll: 						(cls name, ' category: ''', cls category, '''.!!'); cr; cr].		cls organization			putCommentOnFile: fileStream			numbered: 0			moveSource: false			forClass: cls.	"does nothing if metaclass"		cls organization categories do: 			[:heading |			cls fileOutCategory: heading				on: fileStream				moveSource: false				toFile: 0]].	"no class initialization -- it came in as a real object"	fileStream close.	zipper value.! !!ImageSegment methodsFor: 'read/write segment' stamp: 'jmv 1/6/2005 20:40'!writeForExportWithSourcesGZ: fName inDirectory: aDirectory	"Write the segment on the disk with all info needed to reconstruct it in a new image.  For export.  Out pointers are encoded as normal objects on the disk.  Append the source code of any classes in roots.  Target system will quickly transfer the sources to its changes file."	"this is the gzipped version which I have temporarily suspended until I can get resolve the problem with forward references tring to reposition the stream - RAA 11 june 2000"	| fileStream temp allClassesInRoots classesToWriteEntirely methodsWithSource |	state = #activeCopy ifFalse: [self error: 'wrong state'].	(fName includes: $.) ifFalse: [		^ self inform: 'Please use ''.pr'' or ''.extSeg'' at the end of the file name'.].	temp _ endMarker.	endMarker _ nil.	fileStream _ GZipSurrogateStream newFileNamed: fName inDirectory: aDirectory.	fileStream fileOutClass: nil andObject: self.		"remember extra structures.  Note class names."	endMarker _ temp.	"append sources"	allClassesInRoots _ arrayOfRoots select: [:cls | cls isKindOf: Behavior].	classesToWriteEntirely _ allClassesInRoots.	methodsWithSource _ OrderedCollection new.	allClassesInRoots do: [ :cls |		(classesToWriteEntirely includes: cls) ifFalse: [			cls selectorsAndMethodsDo: [ :sel :meth |				meth sourcePointer = 0 ifFalse: [methodsWithSource add: {cls. sel. meth}].			].		].	].	(classesToWriteEntirely isEmpty and: [methodsWithSource isEmpty]) ifTrue: [		fileStream reallyClose.	"since #close is ignored"		^ self	].	"fileStream reopen; setToEnd."	"<--not required with gzipped surrogate stream"	fileStream nextPutAll: '\\!!ImageSegment new!!\\' withCRs.	methodsWithSource do: [ :each |		fileStream nextPut: $!!.	"try to pacify ImageSegment>>scanFrom:"		fileStream nextChunkPut: 'RenamedClassSourceReader formerClassName: ',				each first name printString,' methodsFor: ',				(each first organization categoryOfElement: each second) asString printString,				' stamp: ',(Utilities timeStampForMethod: each third) printString; cr.		fileStream nextChunkPut: (each third getSourceFor: each second in: each first) asString.		fileStream nextChunkPut: ' '; cr.	].	classesToWriteEntirely do: [:cls | 		cls isMeta ifFalse: [fileStream nextPutAll: 						(cls name, ' category: ''', cls category, '''.!!'); cr; cr].		cls organization			putCommentOnFile: fileStream			numbered: 0			moveSource: false			forClass: cls.	"does nothing if metaclass"		cls organization categories do: 			[:heading |			cls fileOutCategory: heading				on: fileStream				moveSource: false				toFile: 0]].	"no class initialization -- it came in as a real object"	fileStream reallyClose.	"since #close is ignored"! !!ImageSegment methodsFor: 'fileIn/Out' stamp: 'jmv 1/6/2005 20:06'!declareAndPossiblyRename: classThatIsARoot
	| existing catInstaller |
	"The class just arrived in this segment.  How fit it into the Smalltalk dictionary?  If it had an association, that was installed with associationDeclareAt:."

	catInstaller _ [
			(classThatIsARoot superclass name beginsWith: 'WonderLandActor')
				ifTrue: [classThatIsARoot category: 'Balloon3D-UserObjects']
				ifFalse: [classThatIsARoot category: 'Morphic-Imported'].
	].
	classThatIsARoot superclass addSubclass: classThatIsARoot.
	(Smalltalk includesKey: classThatIsARoot name) ifFalse: [
		"Class entry in Smalltalk not referred to in Segment, install anyway."
		catInstaller value.
		^ Smalltalk at: classThatIsARoot name put: classThatIsARoot].
	existing _ Smalltalk at: classThatIsARoot name.
	existing xxxClass == ImageSegmentRootStub ifTrue: [
		"We are that segment!!  Must ask it carefully!!"
		catInstaller value.
		^ Smalltalk at: classThatIsARoot name put: classThatIsARoot].
	existing == false | (existing == nil) ifTrue: [
		"association is in outPointers, just installed"
		catInstaller value.
		^ Smalltalk at: classThatIsARoot name put: classThatIsARoot].
	"Conflict with existing global or copy of the class"
	(existing isKindOf: Class) ifTrue: [
		"Take the incoming one"
		self inform: 'Using newly arrived version of ', classThatIsARoot name.
		classThatIsARoot superclass removeSubclass: classThatIsARoot.	"just in case"
		(Smalltalk at: classThatIsARoot name) becomeForward: classThatIsARoot.
		catInstaller value.
		^ classThatIsARoot superclass addSubclass: classThatIsARoot].
	self error: 'Name already in use by a non-class: ', classThatIsARoot name.
! !!Metaclass methodsFor: 'fileIn/Out' stamp: 'jmv 1/6/2005 20:40'!objectForDataStream: refStrm	| dp |	"I am about to be written on an object file.  Write a reference to a class in Smalltalk instead."	dp _ DiskProxy global: self theNonMetaClass name selector: #class			args: (Array new).	refStrm replace: self with: dp.	^ dp! !!Metaclass methodsFor: 'fileIn/Out' stamp: 'jmv 1/6/2005 20:41'!storeDataOn: aDataStream	"I don't get stored.  Use a DiskProxy"	self error: 'use a DiskProxy to store a Class'! !!MethodFinder methodsFor: 'initialize' stamp: 'jmv 1/6/2005 22:01'!initialize
	"The methods we are allowed to use.  (MethodFinder new initialize) "

	Approved _ Set new.
	AddAndRemove _ Set new.
	Blocks _ Set new.
	"These modify an argument and are not used by the MethodFinder: longPrintOn: printOn: storeOn: sentTo: storeOn:base: printOn:base: absPrintExactlyOn:base: absPrintOn:base: absPrintOn:base:digitCount: writeOn: writeScanOn: possibleVariablesFor:continuedFrom: printOn:format:"

"Object"  
	#("in class, instance creation" categoryForUniclasses chooseUniqueClassName initialInstance  newFrom: readCarefullyFrom:
"accessing" at: basicAt: basicSize bindWithTemp: in: size yourself 
"testing" basicType ifNil: ifNil:ifNotNil: ifNotNil: ifNotNil:ifNil: isColor isFloat isFraction isInMemory isInteger isMorph isNil isNumber isPoint isPseudoContext isText isTransparent isWebBrowser knownName notNil pointsTo: wantsSteps 
"comparing" = == closeTo: hash hashMappedBy: identityHash identityHashMappedBy: identityHashPrintString ~= ~~ 
"copying" clone copy shallowCopy 
"dependents access" canDiscardEdits dependents hasUnacceptedEdits 
"updating" changed changed: okToChange update: windowIsClosing 
"printing" fullPrintString isLiteral longPrintString printString storeString stringForReadout stringRepresentation 
"class membership" class isKindOf: isKindOf:orOf: isMemberOf: respondsTo: xxxClass 
"error handling" 
"user interface" addModelMenuItemsTo:forMorph:hand: defaultBackgroundColor defaultLabelForInspector fullScreenSize initialExtent modelWakeUp mouseUpBalk: newTileMorphRepresentative windowActiveOnFirstClick windowReqNewLabel: 
"system primitives" asOop instVarAt: instVarNamed: 
"private" 
"associating" -> 
"converting" as: asOrderedCollection asString 
"casing" caseOf: caseOf:otherwise: 
"binding" bindingOf: 
"macpal" contentsChanged currentEvent currentHand currentWorld flash ifKindOf:thenDo: instanceVariableValues 
"flagging" flag: 
"translation support" "objects from disk" "finalization" ) do: [:sel | Approved add: sel].
	#(at:add: at:modify: at:put: basicAt:put: "NOT instVar:at:"
"message handling" perform: perform:orSendTo: perform:with: perform:with:with: perform:with:with:with: perform:withArguments: perform:withArguments:inSuperclass: 
) do: [:sel | AddAndRemove add: sel].

"Boolean, True, False, UndefinedObject"  
	#("logical operations" & eqv: not xor: |
"controlling" and: ifFalse: ifFalse:ifTrue: ifTrue: ifTrue:ifFalse: or:
"copying" 
"testing" isEmptyOrNil) do: [:sel | Approved add: sel].

"Behavior" 
	#("initialize-release"
"accessing" compilerClass decompilerClass evaluatorClass format methodDict parserClass sourceCodeTemplate subclassDefinerClass
"testing" instSize instSpec isBits isBytes isFixed isPointers isVariable isWeak isWords
"copying"
"printing" defaultNameStemForInstances printHierarchy
"creating class hierarchy"
"creating method dictionary"
"instance creation" basicNew basicNew: new new:
"accessing class hierarchy" allSubclasses allSubclassesWithLevelDo:startingLevel: allSuperclasses subclasses superclass withAllSubclasses withAllSuperclasses
"accessing method dictionary" allSelectors changeRecordsAt: compiledMethodAt: compiledMethodAt:ifAbsent: firstCommentAt: lookupSelector: selectors selectorsDo: selectorsWithArgs: "slow but useful ->" sourceCodeAt: sourceCodeAt:ifAbsent: sourceMethodAt: sourceMethodAt:ifAbsent:
"accessing instances and variables" allClassVarNames allInstVarNames allSharedPools classVarNames instVarNames instanceCount sharedPools someInstance subclassInstVarNames
"testing class hierarchy" inheritsFrom: kindOfSubclass
"testing method dictionary" canUnderstand: classThatUnderstands: hasMethods includesSelector: scopeHas:ifTrue: whichClassIncludesSelector: whichSelectorsAccess: whichSelectorsReferTo: whichSelectorsReferTo:special:byte: whichSelectorsStoreInto:
"enumerating"
"user interface"
"private" indexIfCompact) do: [:sel | Approved add: sel].

"ClassDescription"
	#("initialize-release" 
"accessing" classVersion isMeta name theNonMetaClass
"copying" 
"printing" classVariablesString instanceVariablesString sharedPoolsString
"instance variables" checkForInstVarsOK: 
"method dictionary" 
"organization" category organization whichCategoryIncludesSelector:
"compiling" acceptsLoggingOfCompilation wantsChangeSetLogging
"fileIn/Out" definition
"private" ) do: [:sel | Approved add: sel].

"Class"
	#("initialize-release" 
"accessing" classPool
"testing"
"copying" 
"class name" 
"instance variables" 
"class variables" classVarAt: classVariableAssociationAt:
"pool variables" 
"compiling" 
"subclass creation" 
"fileIn/Out" ) do: [:sel | Approved add: sel]. 

"Metaclass"
	#("initialize-release" 
"accessing" soleInstance
"copying" "instance creation" "instance variables"  "pool variables" "class hierarchy"  "compiling"
"fileIn/Out"  nonTrivial ) do: [:sel | Approved add: sel].

"Context, BlockContext"
	#(receiver client method receiver tempAt: 
"debugger access" mclass pc selector sender shortStack sourceCode tempNames tempsAndValues
"controlling"  "printing" "system simulation" 
"initialize-release" 
"accessing" hasMethodReturn home numArgs
"evaluating" value value:ifError: value:value: value:value:value: value:value:value:value: valueWithArguments:
"controlling"  "scheduling"  "instruction decoding"  "printing" "private"  "system simulation" ) do: [:sel | Approved add: sel].
	#(value: "<- Association has it as a store" ) do: [:sel | AddAndRemove add: sel].

"Message"
	#("inclass, instance creation" selector: selector:argument: selector:arguments:
"accessing" argument argument: arguments sends:
"printing" "sending" ) do: [:sel | Approved add: sel].
	#("private" setSelector:arguments:) do: [:sel | AddAndRemove add: sel].

"Magnitude"
	#("comparing" < <= > >= between:and:
"testing" max: min: min:max: ) do: [:sel | Approved add: sel].

"Date, Time"
	#("in class, instance creation" fromDays: fromSeconds: fromString: newDay:month:year: newDay:year: today
	"in class, general inquiries" dateAndTimeNow dayOfWeek: daysInMonth:forYear: daysInYear: firstWeekdayOfMonth:year: indexOfMonth: leapYear: nameOfDay: nameOfMonth:
"accessing" day leap monthIndex monthName weekday year
"arithmetic" addDays: subtractDate: subtractDays:
"comparing"
"inquiries" dayOfMonth daysInMonth daysInYear daysLeftInYear firstDayOfMonth previous:
"converting" asSeconds
"printing" mmddyy mmddyyyy printFormat: 
"private" firstDayOfMonthIndex: weekdayIndex 
	"in class, instance creation" fromSeconds: now 
	"in class, general inquiries" dateAndTimeFromSeconds: dateAndTimeNow millisecondClockValue millisecondsToRun: totalSeconds
"accessing" hours minutes seconds
"arithmetic" addTime: subtractTime:
"comparing"
"printing" intervalString print24 
"converting") do: [:sel | Approved add: sel].
	#("private" hours: hours:minutes:seconds: day:year: 
		 ) do: [:sel | AddAndRemove add: sel].

"Number"
	#("in class" readFrom:base: 
"arithmetic" * + - / // \\ abs negated quo: reciprocal rem:
"mathematical functions" arcCos arcSin arcTan arcTan: cos exp floorLog: ln log log: raisedTo: raisedToInteger: sin sqrt squared tan
"truncation and round off" ceiling detentBy:atMultiplesOf:snap: floor roundTo: roundUpTo: rounded truncateTo: truncated
"comparing"
"testing" even isDivisibleBy: isInf isInfinite isNaN isZero negative odd positive sign strictlyPositive
"converting" @ asInteger asNumber asPoint asSmallAngleDegrees degreesToRadians radiansToDegrees
"intervals" to: to:by: 
"printing" printStringBase: storeStringBase: ) do: [:sel | Approved add: sel].

"Integer"
	#("in class" primesUpTo:
"testing" isPowerOfTwo
"arithmetic" alignedTo:
"comparing"
"truncation and round off" atRandom normalize
"enumerating" timesRepeat:
"mathematical functions" degreeCos degreeSin factorial gcd: lcm: take:
"bit manipulation" << >> allMask: anyMask: bitAnd: bitClear: bitInvert bitInvert32 bitOr: bitShift: bitXor: lowBit noMask:
"converting" asCharacter asColorOfDepth: asFloat asFraction asHexDigit
"printing" asStringWithCommas hex hex8 radix:
"system primitives" lastDigit replaceFrom:to:with:startingAt:
"private" "benchmarks" ) do: [:sel | Approved add: sel].

"SmallInteger, LargeNegativeInteger, LargePositiveInteger"
	#("arithmetic" "bit manipulation" highBit "testing" "comparing" "copying" "converting" "printing" 
"system primitives" digitAt: digitLength 
"private" fromString:radix: ) do: [:sel | Approved add: sel].
	#(digitAt:put: ) do: [:sel | AddAndRemove add: sel].

"Float"
	#("arithmetic"
"mathematical functions" reciprocalFloorLog: reciprocalLogBase2 timesTwoPower:
"comparing" "testing"
"truncation and round off" exponent fractionPart integerPart significand significandAsInteger
"converting" asApproximateFraction asIEEE32BitWord asTrueFraction
"copying") do: [:sel | Approved add: sel].

"Fraction, Random"
	#(denominator numerator reduced next nextValue) do: [:sel | Approved add: sel].
	#(setNumerator:denominator:) do: [:sel | AddAndRemove add: sel].

"Collection"
	#("accessing" anyOne
"testing" includes: includesAllOf: includesAnyOf: includesSubstringAnywhere: isEmpty isSequenceable occurrencesOf:
"enumerating" collect: collect:thenSelect: count: detect: detect:ifNone: detectMax: detectMin: detectSum: inject:into: reject: select: select:thenCollect:
"converting" asBag asCharacterSet asSet asSortedArray asSortedCollection asSortedCollection:
"printing"
"private" maxSize
"arithmetic"
"math functions" average max median min range sum) do: [:sel | Approved add: sel].
	#("adding" add: addAll: addIfNotPresent:
"removing" remove: remove:ifAbsent: removeAll: removeAllFoundIn: removeAllSuchThat: remove:ifAbsent:) do: [:sel | AddAndRemove add: sel].

"SequenceableCollection"
	#("comparing" hasEqualElements:
"accessing" allButFirst allButLast at:ifAbsent: atAll: atPin: atRandom: atWrap: fifth first fourth identityIndexOf: identityIndexOf:ifAbsent: indexOf: indexOf:ifAbsent: indexOf:startingAt:ifAbsent: indexOfSubCollection:startingAt: indexOfSubCollection:startingAt:ifAbsent: last second sixth third
"removing"
"copying" , copyAfterLast: copyAt:put: copyFrom:to: copyReplaceAll:with: copyReplaceFrom:to:with: copyUpTo: copyUpToLast: copyWith: copyWithout: copyWithoutAll: forceTo:paddingWith: shuffled sortBy:
"enumerating" collectWithIndex: findFirst: findLast: pairsCollect: with:collect: withIndexCollect: polynomialEval:
"converting" asArray asDictionary asFloatArray asIntegerArray asStringWithCr asWordArray reversed
"private" copyReplaceAll:with:asTokens: ) do: [:sel | Approved add: sel].
	#( swap:with:) do: [:sel | AddAndRemove add: sel].

"ArrayedCollection, Bag"
	#("private" defaultElement 
"sorting" isSorted
"accessing" cumulativeCounts sortedCounts sortedElements "testing" "adding" add:withOccurrences: "removing" "enumerating" 
	) do: [:sel | Approved add: sel].
	#( mergeSortFrom:to:by: sort sort: add: add:withOccurrences:
"private" setDictionary ) do: [:sel | AddAndRemove add: sel].

"Other messages that modify the receiver"
	#(atAll:put: atAll:putAll: atAllPut: atWrap:put: replaceAll:with: replaceFrom:to:with:  removeFirst removeLast) do: [:sel | AddAndRemove add: sel].

	self initialize2.

"
MethodFinder new initialize.
MethodFinder new organizationFiltered: Set
"

! !!Morph methodsFor: 'button' stamp: 'jmv 1/6/2005 22:45'!fire	"If the receiver has any kind of button-action defined, fire that action now.   Any morph can have special, personal mouseUpCodeToRun, and that will be triggered by this.  Additionally, some morphs have specific buttonness, and these get sent the #doButtonAction message to carry out their firing.  Finally, some morphs have mouse behaviors associated with one or more Player scripts.	For the present, we'll try out doing *all* the firings this object can do. "	self firedMouseUpCode.   	"This will run the mouseUpCodeToRun, if any"	self doButtonAction			"Do my native button action, if any"! !!Morph methodsFor: 'copying' stamp: 'jmv 1/6/2005 23:45'!duplicate
	"Make and return a duplicate of the receiver"

	| newMorph aName w |
	self okayToDuplicate ifFalse: [^ self].
	aName _ (w _ self world) ifNotNil:
		[w nameForCopyIfAlreadyNamed: self].
	newMorph _ self veryDeepCopy.
	aName ifNotNil: [newMorph setNameTo: aName].

	newMorph arrangeToStartStepping.
	newMorph privateOwner: nil. "no longer in world"

	^ newMorph! !!Morph methodsFor: 'copying' stamp: 'jmv 1/6/2005 23:45'!duplicateMorphCollection: aCollection	"Make and return a duplicate of the receiver"	| newCollection names |	names _ aCollection collect: [ :ea | | newMorph w |		(w _ ea world) ifNotNil:			[w nameForCopyIfAlreadyNamed: ea].	].	newCollection _ aCollection veryDeepCopy.	newCollection with: names do: [ :newMorph :name |		name ifNotNil: [ newMorph setNameTo: name ].		newMorph arrangeToStartStepping.		newMorph privateOwner: nil. "no longer in world"	].	^newCollection! !!Morph methodsFor: 'debug and other' stamp: 'jmv 1/6/2005 22:45'!buildDebugMenu: aHand
	"Answer a debugging menu for the receiver.  The hand argument is seemingly historical and plays no role presently"

	| aMenu |
	aMenu _ MenuMorph new defaultTarget: self.
	aMenu addStayUpItem.
	(self hasProperty: #errorOnDraw) ifTrue:
		[aMenu add: 'start drawing again' translated action: #resumeAfterDrawError.
		aMenu addLine].
	(self hasProperty: #errorOnStep) ifTrue:
		[aMenu add: 'start stepping again' translated action: #resumeAfterStepError.
		aMenu addLine].

	aMenu add: 'inspect morph' translated action: #inspectInMorphic:.
	aMenu add: 'inspect owner chain' translated action: #inspectOwnerChain.
	Smalltalk isMorphic ifFalse:
		[aMenu add: 'inspect morph (in MVC)' translated action: #inspect].

	self isMorphicModel ifTrue:
		[aMenu add: 'inspect model' translated target: self model action: #inspect].

     aMenu add: 'explore morph' translated target: self selector: #explore.

	aMenu addLine.
	aMenu add: 'browse morph class' translated target: self selector: #browseHierarchy.
	(self isMorphicModel)
		ifTrue: [aMenu
				add: 'browse model class'
				target: self model
				selector: #browseHierarchy].
	aMenu addLine.

	aMenu add: 'morph protocol (text)' translated target: self selector: #haveFullProtocolBrowsed.

	aMenu addLine.

	aMenu
		add: 'save morph in file' translated  action: #saveOnFile;
		addLine;
		add: 'call #tempCommand' translated action: #tempCommand;
		add: 'define #tempCommand' translated action: #defineTempCommand;
		addLine;

		add: 'control-menu...' translated target: self selector: #invokeMetaMenu:;
		add: 'edit balloon help' translated action: #editBalloonHelpText.

	^ aMenu! !!Morph methodsFor: 'dropping/grabbing' stamp: 'jmv 1/6/2005 23:45'!justDroppedInto: aMorph event: anEvent
	"This message is sent to a dropped morph after it has been dropped on -- and been accepted by -- a drop-sensitive morph"

	| aWindow |
	self formerOwner: nil.
	self formerPosition: nil.
	(aWindow _ aMorph ownerThatIsA: SystemWindow) ifNotNil:
		[aWindow isActive ifFalse:
			[aWindow activate]].
	(self isInWorld ) ifTrue:
		[self world startSteppingSubmorphsOf: self].
	"Note an unhappy inefficiency here:  the startStepping... call will often have already been called in the sequence leading up to entry to this method, but unfortunately the isPartsDonor: call often will not have already happened, with the result that the startStepping... call will not have resulted in the startage of the steppage."

	"An object launched by certain parts-launcher mechanisms should end up fully visible..."
	(self hasProperty: #beFullyVisibleAfterDrop) ifTrue:
		[aMorph == ActiveWorld ifTrue:
			[self goHome].
		self removeProperty: #beFullyVisibleAfterDrop]
! !!Morph methodsFor: 'events-processing' stamp: 'jmv 1/6/2005 23:42'!mouseDownPriority
	"Return the default mouse down priority for the receiver"

	^ ("self isPartsDonor "false)
		ifTrue:	[50]
		ifFalse:	[0]

	"The above is a workaround for the complete confusion between parts donors and parts bins. Morphs residing in a parts bin may or may not have the parts donor property set; if they have they may or may not actually handle events. To work around this, parts bins get an equal priority to parts donors so that when a morph in the parts bin does have the property set but does not handle the event we still get a copy from picking it up through the parts bin. Argh. This just *cries* for a cleanup."
	"And the above comment is Andreas's from 10/2000, which was formerly retrievable by a #flag: call which however caused a problem when trying to recompile the method from decompiled source."! !!Morph methodsFor: 'menus' stamp: 'jmv 1/6/2005 22:42'!absorbStateFromRenderer: aRenderer 
	| current |
	"Transfer knownName, actorState, and player info over from aRenderer, which was formerly imposed above me as a transformation shell but is now going away."

	(current _ aRenderer knownName) ifNotNil:
		[self setNameTo: current.
		aRenderer setNameTo: nil]! !!Morph methodsFor: 'menus' stamp: 'jmv 1/6/2005 22:45'!doMenuItem: menuString	| aMenu anItem aNominalEvent aHand |	aMenu _ self buildHandleMenu: (aHand _ self currentHand).	aMenu allMorphsDo: [:m | m step].  "Get wordings current"	anItem _ aMenu itemWithWording: menuString.	anItem ifNil:		[^ self error: 'Menu item not found: ', menuString].	aNominalEvent _  MouseButtonEvent new		setType: #mouseDown		position: anItem bounds center		which: 4 "red"		buttons: 4 "red"		hand: aHand		stamp: nil.	anItem invokeWithEvent: aNominalEvent! !!Morph methodsFor: 'menus' stamp: 'jmv 1/6/2005 22:42'!transferStateToRenderer: aRenderer
	| current |
	"Transfer knownName, actorState, and player info over to aRenderer, which is being imposed above me as a transformation shell"
	
	(current _ self knownName) ifNotNil:
		[aRenderer setNameTo: current.
		self setNameTo: nil]! !!Morph methodsFor: 'meta-actions' stamp: 'jmv 1/6/2005 20:01'!buildMetaMenu: evt
	"Build the morph menu. This menu has two sections. The first section contains commands that are handled by the hand; the second contains commands handled by the argument morph."
	| menu |
	menu _ MenuMorph new defaultTarget: self.
	menu addStayUpItem.
	menu add: 'grab' translated action: #grabMorph:.
	menu add: 'copy to paste buffer' translated action: #copyToPasteBuffer:.
	self maybeAddCollapseItemTo: menu.
	menu add: 'delete' translated action: #dismissMorph:.
	menu addLine.
	menu add: 'copy text' translated action: #clipText.
	menu addLine.
	menu add: 'go behind' translated action: #goBehind.
	menu add: 'add halo' translated action: #addHalo:.
	menu add: 'duplicate' translated action: #maybeDuplicateMorph:.

	self addEmbeddingMenuItemsTo: menu hand: evt hand.

	menu add: 'resize' translated action: #resizeMorph:.
	"Give the argument control over what should be done about fill styles"
	self addFillStyleMenuItems: menu hand: evt hand.
	self addDropShadowMenuItems: menu hand: evt hand.
	self addLayoutMenuItems: menu hand: evt hand.
	menu addUpdating: #hasClipSubmorphsString target: self selector: #changeClipSubmorphs argumentList: #().
	menu addLine.

	(self morphsAt: evt position) size > 1 ifTrue:
		[menu add: 'submorphs...' translated
			target: self
			selector: #invokeMetaMenuAt:event:
			argument: evt position].
	menu addLine.
	menu add: 'inspect' translated selector: #inspectAt:event: argument: evt position.
	menu add: 'explore' translated action: #explore.
	menu add: 'browse hierarchy' translated action: #browseHierarchy.
	menu add: 'save morph in file' translated action: #saveOnFile.
	menu add: 'show actions' translated action: #showActions.
	menu addLine.
	self addDebuggingItemsTo: menu hand: evt hand.

	self addCustomMenuItems: menu hand: evt hand.
	^ menu
! !!Morph methodsFor: 'stepping and presenter' stamp: 'jmv 1/6/2005 22:44'!stepAt: millisecondClockValue	"Do some periodic activity. Use startStepping/stopStepping to start and stop getting sent this message. The time between steps is specified by this morph's answer to the stepTime message.	The millisecondClockValue parameter gives the value of the millisecond clock at the moment of dispatch.	Default is to dispatch to the parameterless step method for the morph, but this protocol makes it possible for some morphs to do differing things depending on the clock value"	self step! !!Morph methodsFor: 'testing' stamp: 'jmv 1/6/2005 22:50'!stepTime	"Answer the desired time between steps in milliseconds. This default implementation requests that the 'step' method be called once every second."	^ 1000! !!Morph methodsFor: 'testing' stamp: 'jmv 1/6/2005 23:42'!wantsSteps	"Return true if the receiver overrides the default Morph step method."	"Details: Find first class in superclass chain that implements #step and return true if it isn't class Morph."	| c |	c _ self class.	[c includesSelector: #step] whileFalse: [c _ c superclass].	^ c ~= Morph! !!HaloMorph methodsFor: 'private' stamp: 'jmv 1/6/2005 22:44'!startRot: evt with: rotHandle
	"Initialize rotation of my target if it is rotatable.  Launch a command object to represent the action"

	self obtainHaloForEvent: evt andRemoveAllHandlesBut: rotHandle.
	target isFlexMorph ifFalse: 
		[
		target addFlexShellIfNecessary].
	growingOrRotating _ true.

	self removeAllHandlesBut: rotHandle.  "remove all other handles"
	angleOffset _ evt cursorPoint - (target pointInWorld: target referencePosition).
	angleOffset _ Point
			r: angleOffset r
			degrees: angleOffset degrees - target rotationDegrees

! !!HandMorph methodsFor: 'paste buffer' stamp: 'jmv 1/6/2005 22:45'!pasteMorph	| aPastee |	PasteBuffer ifNil: [^ self inform: 'Nothing to paste.'].	self attachMorph: (aPastee _ self objectToPaste).	aPastee align: aPastee center with: self position! !!MorphExtension methodsFor: 'accessing - other properties' stamp: 'jmv 1/6/2005 23:41'!sortedPropertyNames	"answer the receiver's property names in a sorted way"	| props |	props := WriteStream on: (Array new: 10).	locked == true ifTrue: [props nextPut: #locked].	visible == false ifTrue: [props nextPut: #visible].	sticky == true ifTrue: [props nextPut: #sticky].	balloonText isNil ifFalse: [props nextPut: #balloonText].	balloonTextSelector isNil ifFalse: [props nextPut: #balloonTextSelector].	externalName isNil ifFalse: [props nextPut: #externalName].	eventHandler isNil ifFalse: [props nextPut: #eventHandler].	self hasOtherProperties 		ifTrue: [self otherProperties associationsDo: [:a | props nextPut: a key]].	^props contents sort: [:s1 :s2 | s1 <= s2]! !!MorphExtension methodsFor: 'copying' stamp: 'jmv 1/6/2005 23:45'!veryDeepInner: deepCopier 	"Copy all of my instance variables. Some need to be not copied at 	all, but shared. This is special code for the dictionary. See  	DeepCopier."	| list values vv |	super veryDeepInner: deepCopier.	locked _ locked veryDeepCopyWith: deepCopier.	visible _ visible veryDeepCopyWith: deepCopier.	sticky _ sticky veryDeepCopyWith: deepCopier.	balloonText _ balloonText veryDeepCopyWith: deepCopier.	balloonTextSelector _ balloonTextSelector veryDeepCopyWith: deepCopier.	externalName _ externalName veryDeepCopyWith: deepCopier.	eventHandler _ eventHandler veryDeepCopyWith: deepCopier.	"has its own restrictions"	self hasOtherProperties		ifTrue: [""			self privateOtherProperties: self otherProperties copy.			list _ self copyWeakly.			"Properties whose values are only copied weakly"			values _ list						collect: [:pp | 							vv _ self otherProperties										at: pp										ifAbsent: [].							vv								ifNotNil: [self otherProperties at: pp put: nil].							"zap it"							vv].			self				privateOtherProperties: (self otherProperties veryDeepCopyWith: deepCopier).			1				to: list size				do: [:ii | "put old values back"					(values at: ii)						ifNotNil: [self otherProperties								at: (list at: ii)								put: (values at: ii)]]]! !!MorphExtension methodsFor: 'initialization' stamp: 'jmv 1/6/2005 23:44'!initialize	"Init all booleans to default values"	locked _ false.	visible _ true.	sticky _ false! !!MorphExtension methodsFor: 'objects from disk' stamp: 'jmv 1/6/2005 23:44'!comeFullyUpOnReload: smartRefStream	"inst vars have default booplean values."	locked ifNil: [locked _ false].	visible ifNil: [visible _ true].	sticky ifNil: [sticky _ false].	^ self! !!MorphExtension methodsFor: 'other' stamp: 'jmv 1/6/2005 23:41'!isDefault	"Return true if the receiver is a default and can be omitted"	locked == true		ifTrue: [^ false].	visible == false		ifTrue: [^ false].	sticky == true		ifTrue: [^ false].	balloonText isNil		ifFalse: [^ false].	balloonTextSelector isNil		ifFalse: [^ false].	externalName isNil		ifFalse: [^ false].	eventHandler isNil		ifFalse: [^ false].	self hasOtherProperties		ifTrue: [self otherProperties isEmpty				ifFalse: [^ false]].	^ true! !!MorphExtension methodsFor: 'printing' stamp: 'jmv 1/6/2005 23:41'!printOn: aStream 	"Append to the argument, aStream, a sequence of characters that 	identifies the receiver." 	super printOn: aStream.	aStream nextPutAll: ' ' , self identityHashPrintString.	locked == true		ifTrue: [aStream nextPutAll: ' [locked] '].	visible == false		ifTrue: [aStream nextPutAll: '[not visible] '].	sticky == true		ifTrue: [aStream nextPutAll: ' [sticky] '].	balloonText		ifNotNil: [aStream nextPutAll: ' [balloonText] '].	balloonTextSelector		ifNotNil: [aStream nextPutAll: ' [balloonTextSelector: ' , balloonTextSelector printString , '] '].	externalName		ifNotNil: [aStream nextPutAll: ' [externalName = ' , externalName , ' ] '].	eventHandler		ifNotNil: [aStream nextPutAll: ' [eventHandler = ' , eventHandler printString , '] '].	(self hasOtherProperties not or: [ self otherProperties isEmpty ])		ifTrue: [^ self].	aStream nextPutAll: ' [other: '.	self otherProperties		keysDo: [:aKey | aStream nextPutAll: ' (' , aKey , ' -> ' , (self otherProperties at: aKey) printString , ')'].	aStream nextPut: $]! !!Object class methodsFor: 'instance creation' stamp: 'jmv 1/6/2005 20:42'!newUniqueClassInstVars: instVarString classInstVars: classInstVarString	"Create a unique class for the receiver"	| aName aClass |	aName _ self chooseUniqueClassName.	aClass _ self subclass: aName instanceVariableNames: instVarString 		classVariableNames: '' poolDictionaries: '' category: self categoryForUniclasses.	classInstVarString size > 0 ifTrue:		[aClass class instanceVariableNames: classInstVarString].	^ aClass! !!ObjectScanner methodsFor: 'as yet unclassified' stamp: 'jmv 1/6/2005 20:42'!lookAhead: aChunk	"See if this chunk is a class Definition, and if the new class name already exists and is instance-specific.  Modify the chunk, and record the rename in the SmartRefStream and in me."	| pieces sup oldName existing |	aChunk size < 90 ifTrue: [^ aChunk].		"class defn is big!!"	(aChunk at: 1) == $!! ifTrue: [^ aChunk].	"method def, fast exit"	pieces _ (aChunk copyFrom: 1 to: (300 min: aChunk size)) findTokens: ' #	\' withCRs.	pieces size < 3 ifTrue: [^ aChunk].	"really bigger, but just took front"	(pieces at: 2) = 'subclass:' ifFalse: [^ aChunk].	sup _ Smalltalk at: (pieces at: 1) asSymbol ifAbsent: [^ aChunk].	sup class class == Metaclass ifFalse: [^ aChunk].	((oldName _ pieces at: 3) at: 1) isUppercase ifFalse: [^ aChunk].	oldName _ oldName asSymbol.	(Smalltalk includesKey: oldName) ifFalse: [^ aChunk].	"no conflict"	existing _ Smalltalk at: oldName.	(existing isKindOf: Class) ifFalse: [^ aChunk].	"Write over non-class global"	^ aChunk.	"Go ahead and redefine it!!"! !!PasteUpMorph methodsFor: 'world menu' stamp: 'jmv 1/6/2005 23:31'!newDrawingFromMenu: evt	self assureNotPaintingElse: [^ self].	evt hand attachMorph: PaintInvokingMorph new "markAsPartsDonor"! !!PasteUpMorph methodsFor: 'world state' stamp: 'jmv 1/6/2005 19:54'!initForProject: aWorldState

	worldState _ aWorldState.
	bounds _ Display boundingBox.
	color _ (Color r:0.937 g: 0.937 b: 0.937).
	self addHand: HandMorph new.
	self setProperty: #optimumExtentFromAuthor toValue: Display extent.
	self borderWidth: 0
! !!ReferenceStream methodsFor: 'writing' stamp: 'jmv 1/6/2005 20:43'!beginInstance: aClass size: anInteger	"This is for use by storeDataOn: methods.  Cf. Object>>storeDataOn:."	"Addition of 1 seems to make extra work, since readInstance has to compensate.  Here for historical reasons dating back to Kent Beck's original implementation in late 1988.	In ReferenceStream, class is just 5 bytes for shared symbol.	SmartRefStream puts out the names and number of class's instances variables for checking.6/10/97 16:09 tk: See if we can put on a short header. Type = 16. "	| short ref |	short _ true.	"All tests for object header that can be written in 4 bytes"	anInteger <= 254 ifFalse: [short _ false].	"one byte size"	ref _ references at: aClass name ifAbsent: [short _ false. nil].	ref isInteger ifFalse: [short _ false].	short ifTrue: [short _ (ref < 65536) & (ref > 0) "& (ref ~= self vacantRef)"].  "vacantRef is big"	short ifTrue: [		byteStream skip: -1.		short _ byteStream next = 9.		byteStream skip: 0].	"ugly workaround"	short 		ifTrue: ["passed all the tests!!"			byteStream skip: -1; nextPut: 16; "type = short header"				nextPut: anInteger + 1;	"size is short"				nextNumber: 2 put: ref]		ifFalse: [			"default to normal longer object header"			byteStream nextNumber: 4 put: anInteger + 1.			self nextPut: aClass name]! !!SARInstaller methodsFor: 'client services' stamp: 'jmv 1/6/2005 19:51'!installMember: memberOrName	| memberName extension isGraphic stream member |	member _ self memberNamed: memberOrName.	member ifNil: [ ^false ].	memberName _ member fileName.	extension _ (FileDirectory extensionFor: memberName) asLowercase.	Smalltalk at: #CRDictionary ifPresent: [ :crDictionary |		(extension = crDictionary fileNameSuffix) ifTrue: [  self fileInGenieDictionaryNamed: memberName. ^true ] ].	extension caseOf: {		[ Project projectExtension ] -> [ self fileInProjectNamed: memberName createView: true ].		[ 'st' ] -> [ self fileInPackageNamed: memberName ].		[ 'cs' ] -> [  self fileInMemberNamed: memberName  ].		[ 'mc' ] -> [ self fileInMonticelloPackageNamed: memberName ].		[ 'mcv' ] -> [ self fileInMonticelloVersionNamed: memberName ].		[ 'mcz' ] -> [ self fileInMonticelloZipVersionNamed: memberName ].		[ 'ttf' ] -> [ self fileInTrueTypeFontNamed: memberName ].	} otherwise: [		('t*xt' match: extension) ifTrue: [ self openTextFile: memberName ]			ifFalse: [ stream _ member contentStream.		isGraphic _ ImageReadWriter understandsImageFormat: stream.		stream reset.		isGraphic			ifTrue: [ self openGraphicsFile: member ]			ifFalse: [ "now what?" ^false ]]	].	^true! !!SimpleButtonMorph methodsFor: 'event handling' stamp: 'jmv 1/6/2005 23:43'!handlesMouseDown: evt	^  true! !!SmartRefStream methodsFor: 'read write' stamp: 'jmv 1/6/2005 20:47'!appendClassDefns	"Make this a fileOut format file.  For each UniClass mentioned, prepend its source code to the file.  Class name conflicts during reading will be resolved then.  Assume instVarInfo: has already been done."byteStream ascii.byteStream position = 0 ifTrue: [	byteStream setFileTypeToObject.		"Type and Creator not to be text, so can attach correctly to an email msg"	byteStream header; timeStamp].byteStream cr; nextPutAll: '!!ObjectScanner new initialize!!'; cr; cr.	byteStream trailer.	"Does nothing for normal files.  		HTML streams will have trouble with object data"	"Append the object's raw data"	byteStream cr; cr; nextPutAll: '!!self smartRefStream!!'.	byteStream binary.		"get ready for objects"! !!SmartRefStream methodsFor: 'read write' stamp: 'jmv 1/6/2005 22:00'!instVarInfo: anObject	"Return the object to write on the outgoing file that contains the structure of each class we are about to write out.  Must be an Array whose first element is 'class structure'.  Its second element is a Dictionary of pairs of the form #Rectangle -> #(<classVersion> 'origin' 'corner').  "	"Make a pass through the objects, not writing, but recording the classes.  Construct a database of their inst vars and any version info (classVersion)."	| dummy refs cls newSupers |	structures _ Dictionary new.	superclasses _ Dictionary new.	dummy _ ReferenceStream on: (DummyStream on: nil).		"Write to a fake Stream, not a file"	"Collect all objects"	dummy rootObject: anObject.	"inform him about the root"	dummy nextPut: anObject.	refs _ dummy references.	objCount _ refs size.		"for progress bar"		"Note that Dictionary must not change its implementation!!  If it does, how do we read this reading information?"	(refs includesKey: #AnImageSegment) 		ifFalse: [			refs keysDo: [:each | 				cls _ each class.				"cls isObsolete ifTrue: [self error: 'Trying to write ', cls name]."				(cls class ~~ Metaclass) & (cls isObsolete not) ifTrue: [					structures at: cls name put: false]]]		ifTrue: [self recordImageSegment: refs].	"Save work by only computing inst vars once for each class"	newSupers _ Set new.	structures at: #Point put: false.	"writeRectangle: does not put out class pointer"	structures at: #Rectangle put: false.	structures at: #LargePositiveInteger put: false.	"used in slow case of WordArray"	structures keysDo: [:nm | 		cls _ (nm endsWith: ' class') 			ifFalse: [Smalltalk at: nm]			ifTrue: [(Smalltalk at: nm substrings first asSymbol) class].		cls allSuperclasses do: [:aSuper |			structures at: aSuper name ifAbsent: [newSupers add: aSuper name]]].			"Don't modify structures during iteration"	newSupers do: [:nm | structures at: nm put: 3].	"Get all superclasses into list"	structures keysDo: [:nm | "Nothing added to classes during loop"		cls _ (nm endsWith: ' class') 			ifFalse: [Smalltalk at: nm]			ifTrue: [(Smalltalk at: nm substrings first asSymbol) class].		structures at: nm put: 			((Array with: cls classVersion), (cls allInstVarNames)).		superclasses at: nm ifAbsent: [				superclasses at: nm put: cls superclass name]].	(refs includesKey: #AnImageSegment) 		ifTrue: [classInstVars _ #()]		ifFalse: [self saveClassInstVars].	"of UniClassses"	^ (Array with: 'class structure' with: structures with: 'superclasses' with: superclasses)! !!SmartRefStream methodsFor: 'read write' stamp: 'jmv 1/6/2005 20:48'!nextPutObjOnly: anObject	"Really write three objects: (version, class structure, object).  But only when called from the outside.  Not in fileOut format.  No class definitions will be written for instance-specific classes.  Error if find one.  (Use nextPut: instead)"	| info |	topCall == nil 		ifTrue:			[topCall _ anObject.			super nextPut: ReferenceStream versionCode.			'Please wait while objects are counted' displayProgressAt: Sensor cursorPoint				from: 0 to: 10				during: [:bar |					info _ self instVarInfo: anObject].			'Writing an object file' displayProgressAt: Sensor cursorPoint				from: 0 to: objCount*4	"estimate"				during: [:bar |					objCount _ 0.					progressBar _ bar.					super nextPut: info.					super nextPut: anObject.	"<- the real writing"					"Class inst vars not written here!!"].			"references is an IDict of every object that got written			(in case you want to take statistics)"			"Transcript cr; show: structures keys printString."		"debug"			topCall _ progressBar _ nil]	"reset it"		ifFalse:			[super nextPut: anObject.			progressBar ifNotNil: [progressBar value: (objCount _ objCount + 1)]].! !!SmartRefStream methodsFor: 'read write' stamp: 'jmv 1/6/2005 20:49'!saveClassInstVars	"Install the values of the instance variables of UniClasses.classInstVars is an array of arrays (#Player3 (Player3 class's inst varscripts) (Player3 class's inst var slotInfo) ...) "	classInstVars _ classInstVars asArray.	! !!SmartRefStream methodsFor: 'read write' stamp: 'jmv 1/6/2005 22:12'!uniClassInstVarsRefs: dummy	"If some of the objects seen so far are instances UniClasses, check the UniClasses for extra class inst vars, and send them to the steam also.  The new objects get added to (dummy references), where they will be noticed by the caller.  They will wind up in the structures array and will be written on the disk by class.	Return all classes seen." | allClasses |"Note: Any classes used in the structure of classInstVars must be written out also!!"allClasses _ IdentitySet new.	dummy references keysDo: [:each |		each class class isMeta ifFalse: ["it is a class" allClasses add: each]].^ allClasses! !!SystemWindow methodsFor: 'stepping' stamp: 'jmv 1/6/2005 23:43'!wantsSteps	"Return true if the model wants its view to be stepped.  For an open system window, we give the model to offer an opinion"	^ isCollapsed not and: [model wantsStepsIn: self]! !!TextMorph methodsFor: 'event handling' stamp: 'jmv 1/6/2005 23:43'!handlesMouseDown: evt	^ self innerBounds containsPoint: evt cursorPoint! !!TheWorldMenu methodsFor: 'construction' stamp: 'jmv 1/6/2005 19:52'!newMorph	"The user requested 'new morph' from the world menu.  Put up a menu that allows many ways of obtaining new morphs.  If the preference #classicNewMorphMenu is true, the full form of yore is used; otherwise, a much shortened form is used."	| menu subMenu catDict shortCat class |	menu _ self menu: 'Add a new morph'.	menu 		add: 'from paste buffer' translated target: myHand action: #pasteMorph;		add: 'from alphabetical list' translated subMenu: self alphabeticalMorphMenu.	menu addLine.	menu add: 'grab rectangle from screen' translated target: myWorld action: #grabDrawingFromScreen:;		add: 'grab with lasso from screen' translated target: myWorld action: #grabLassoFromScreen:;		add: 'grab rubber band from screen' translated target: myWorld action: #grabRubberBandFromScreen:;		add: 'grab flood area from screen' translated target: myWorld action: #grabFloodFromScreen:.	menu addLine.	menu add: 'make new drawing' translated target: myWorld action: #newDrawingFromMenu:;		add: 'make link to project...' translated target: self action: #projectThumbnail.	Preferences classicNewMorphMenu ifTrue:		[menu addLine.		catDict _ Dictionary new.		SystemOrganization categories do:			[:cat |			((cat beginsWith: 'Morphic-')					and: [(#('Morphic-Menus' 'Morphic-Support') includes: cat) not])			ifTrue:				[shortCat _ (cat copyFrom: 'Morphic-' size+1 to: cat size) translated.				(SystemOrganization listAtCategoryNamed: cat) do:					[:cName | class _ Smalltalk at: cName.					((class inheritsFrom: Morph)						and: [class includeInNewMorphMenu])						ifTrue:						[(catDict includesKey: shortCat) 						ifTrue: [(catDict at: shortCat) addLast: class]						ifFalse: [catDict at: shortCat put: (OrderedCollection with: class)]]]]].		catDict keys asSortedCollection do:			[:categ |			subMenu _ MenuMorph new.			((catDict at: categ) asSortedCollection: [:c1 :c2 | c1 name < c2 name]) do:				[:cl | subMenu add: cl name						target: self						selector: #newMorphOfClass:event:						argument: cl].			menu add: categ subMenu: subMenu]].	self doPopUp: menu.! !!TransformationMorph methodsFor: 'menu' stamp: 'jmv 1/6/2005 22:47'!removeFlexShell	"Remove the shell used to make a morph rotatable and scalable."	| oldHalo unflexed pensDown myWorld refPos |	refPos _ self referencePosition.	myWorld _ self world.	oldHalo _ self halo.	submorphs isEmpty ifTrue: [^ self delete].	unflexed _ self firstSubmorph.	pensDown _ OrderedCollection new.	self submorphs do: [:m |		m position: self center - (m extent // 2).		owner addMorph: m].	unflexed absorbStateFromRenderer: self.	pensDown do: [:p | p setPenDown: true].	oldHalo ifNotNil: [oldHalo setTarget: unflexed].	myWorld ifNotNil: [myWorld startSteppingSubmorphsOf: unflexed].	self delete.	unflexed referencePosition: refPos.	^ unflexed! !TheWorldMenu removeSelector: #readMorphFromAFile!TextMorph class removeSelector: #authoringPrototype!TextMorph class removeSelector: #borderedPrototype!TextMorph class removeSelector: #exampleBackgroundLabel!TextFieldMorph class removeSelector: #authoringPrototype!StringMorph class removeSelector: #authoringPrototype!SmartRefStream removeSelector: #uniClasesDo:!ColorPickerMorph removeSelector: #isLikelyRecipientForMouseOverHalos!SketchMorph removeSelector: #isLikelyRecipientForMouseOverHalos!SimpleSliderMorph class removeSelector: #authoringPrototype!SimpleButtonMorph class removeSelector: #authoringPrototype!SARInstaller removeSelector: #fileInMorphsNamed:addToWorld:!RectangleMorph class removeSelector: #diagonalPrototype!RectangleMorph class removeSelector: #gradientPrototype!RectangleMorph class removeSelector: #roundRectPrototype!PluggableTextMorphWithModel class removeSelector: #authoringPrototype!PasteUpMorph class removeSelector: #authoringPrototype!PasteUpMorph removeSelector: #addMorphsAndModel:!PasteUpMorph removeSelector: #createCustomModel!PasteUpMorph removeSelector: #model!PasteUpMorph removeSelector: #modelOrNil!PasteUpMorph removeSelector: #setModel:!BorderedMorph subclass: #PasteUpMorph	instanceVariableNames: 'cursor backgroundMorph worldState'	classVariableNames: 'DisableDeferredUpdates MinCycleLapse'	poolDictionaries: ''	category: 'Morphic-Worlds'!PaintInvokingMorph class removeSelector: #authoringPrototype!MorphicModel class removeSelector: #baseUniclass!MorphicModel class removeSelector: #categoryForSubclasses!MorphicModel class removeSelector: #hasPrototype!MorphicModel class removeSelector: #new!MorphicModel class removeSelector: #prototype!MorphicModel class removeSelector: #prototype:!MorphicModel class	instanceVariableNames: ''!!MorphicModel class reorganize!('compilation' chooseNewName compileAccessorsFor: compilePropagationForVarName:slotName:)('compiling' acceptsLoggingOfCompilation wantsChangeSetLogging)('housekeeping' removeUninstantiatedModels)('instance creation' newBounds:model:slotName:)('new-morph participation' includeInNewMorphMenu)('queries')('subclass creation' newSubclass)('testing')!ImageMorph class removeSelector: #authoringPrototype!Morph class removeSelector: #authoringPrototype!Morph class removeSelector: #fileReaderServicesForFile:suffix:!Morph class removeSelector: #fromFileName:!Morph class removeSelector: #serviceLoadMorphFromFile!Morph class removeSelector: #services!ComponentLikeModel removeSelector: #choosePartName!ComponentLikeModel removeSelector: #nameMeIn:!ComponentLikeModel removeSelector: #renameMe!MorphicModel removeSelector: #choosePartName!MorphicModel removeSelector: #modelOrNil!MorphExtension removeSelector: #actorState!MorphExtension removeSelector: #isPartsDonor!MorphExtension removeSelector: #isPartsDonor:!MorphExtension removeSelector: #player!MorphExtension removeSelector: #player:!Object subclass: #MorphExtension	instanceVariableNames: 'locked visible sticky balloonText balloonTextSelector externalName eventHandler otherProperties'	classVariableNames: ''	poolDictionaries: ''	category: 'Morphic-Kernel'!Morph removeSelector: #beThisWorldsModel!Morph removeSelector: #choosePartName!Morph removeSelector: #isLikelyRecipientForMouseOverHalos!Morph removeSelector: #isPartsDonor!Morph removeSelector: #isPartsDonor:!Morph removeSelector: #markAsPartsDonor!Morph removeSelector: #modelOrNil!Morph removeSelector: #player!Morph removeSelector: #player:!Morph removeSelector: #saveAsPrototype!Morph removeSelector: #subclassMorph!Metaclass removeSelector: #isSystemDefined!Class removeSelector: #isSystemDefined!