'From Squeak3.7 of ''4 September 2004'' [latest update: #5989] on 5 January 2005 at 4:29:13 pm'!
Morph subclass: #HandMorph
	instanceVariableNames: 'mouseFocus keyboardFocus eventListeners mouseListeners keyboardListeners mouseClickState mouseOverHandler lastMouseEvent targetOffset damageRecorder cacheCanvas cachedCanvasHasHoles temporaryCursor temporaryCursorOffset hasChanged savedPatch userInitials lastEventBuffer genieGestureProcessor '
	classVariableNames: 'DoubleClickTime EventStats NewEventRules NormalCursor PasteBuffer ShowEvents '
	poolDictionaries: 'EventSensorConstants'
	category: 'Morphic-Kernel'!
BorderedMorph subclass: #PasteUpMorph
	instanceVariableNames: 'presenter model cursor padding backgroundMorph turtleTrailsForm turtlePen lastTurtlePositions isPartsBin autoLineLayout indicateCursor resizeToFit wantsMouseOverHalos worldState griddingOn '
	classVariableNames: 'DisableDeferredUpdates MinCycleLapse StillAlive '
	poolDictionaries: ''
	category: 'Morphic-Worlds'!
Object subclass: #ServerDirectory
	instanceVariableNames: 'server directory type user passwordHolder group moniker altURL urlObject client loaderUrl eToyUserListUrl eToyUserList keepAlive '
	classVariableNames: 'LocalEToyBaseFolderSpecs LocalEToyUserListUrls LocalProjectDirectories Servers '
	poolDictionaries: ''
	category: 'Network-RemoteDirectory'!
Object subclass: #StandardScriptingSystem
	instanceVariableNames: ''
	classVariableNames: 'ClassVarNamesInUse FormDictionary HelpStrings StandardPartsBin '
	poolDictionaries: ''
	category: 'Morphic-Scripting'!
Object subclass: #WorldState
	instanceVariableNames: 'hands activeHand viewBox canvas damageRecorder stepList lastStepTime lastStepMessage lastCycleTime commandHistory alarms lastAlarmTime remoteServer multiCanvas '
	classVariableNames: 'CanSurrenderToOS DeferredUIMessages DisableDeferredUpdates LastCycleTime MinCycleLapse '
	poolDictionaries: ''
	category: 'Morphic-Worlds'!

!Object methodsFor: 'copying' stamp: 'jmv 12/2/2004 23:14'!
veryDeepCopy
	"Do a complete tree copy using a dictionary.  An object in the tree twice is only copied once.  All references to the object in the copy of the tree will point to the new copy."

	| copier new |
	copier _ DeepCopier new initialize: self initialDeepCopierSize.
	new _ self veryDeepCopyWith: copier.
	copier references associationsDo: [:assoc | 
		assoc value veryDeepFixupWith: copier].
	copier fixDependents.
	^ new! !

!Object methodsFor: 'copying' stamp: 'jmv 12/2/2004 23:14'!
veryDeepCopySibling
	"Do a complete tree copy using a dictionary.  Substitute a clone of oldPlayer for the root.  Normally, a Player or non systemDefined object would have a new class.  We do not want one this time.  An object in the tree twice, is only copied once.  All references to the object in the copy of the tree will point to the new copy."

	| copier new |
	copier _ DeepCopier new initialize: self initialDeepCopierSize.
	copier newUniClasses: false.
	new _ self veryDeepCopyWith: copier.
	copier references associationsDo: [:assoc | 
		assoc value veryDeepFixupWith: copier].
	copier fixDependents.
	^ new! !

!Object methodsFor: 'copying' stamp: 'jmv 12/2/2004 23:14'!
veryDeepCopyUsing: copier
	"Do a complete tree copy using a dictionary.  An object in the tree twice is only copied once.  All references to the object in the copy of the tree will point to the new copy.
	Same as veryDeepCopy except copier (with dictionary) is supplied.
	** do not delete this method, even if it has no callers **"

	| new refs newDep newModel |
	new _ self veryDeepCopyWith: copier.
	copier references associationsDo: [:assoc | 
		assoc value veryDeepFixupWith: copier].
	"Fix dependents"
	refs _ copier references.
	DependentsFields associationsDo: [:pair |
		pair value do: [:dep | 
			(newDep _ refs at: dep ifAbsent: [nil]) ifNotNil: [
				newModel _ refs at: pair key ifAbsent: [pair key].
				newModel addDependent: newDep]]].
	^ new! !

!Object methodsFor: 'events-accessing' stamp: 'jmv 12/6/2004 08:42'!
actionsDo: aBlock

	self actionMap do: aBlock! !

!Object methodsFor: 'macpal' stamp: 'jmv 12/6/2004 08:37'!
contentsChanged
	self changed: #contents! !

!Object methodsFor: 'macpal' stamp: 'jmv 12/20/2004 21:43'!
currentWorld
	"Answer a morphic world that is the current UI focus.
		If in an embedded world, it's that world.
		If in a morphic project, it's that project's world.  
		If in an mvc project, it is the topmost morphic-mvc-window's worldMorph. 
		If in an mvc project that has no morphic-mvc-windows, then it's just some existing worldmorph instance.
		If in an mvc project in a Squeak that has NO WorldMorph instances, one is created.

	This method will never return nil, it will always return its best effort at returning a relevant world morph, but if need be -- if there are no worlds anywhere, it will create a new one."

	| |
	ActiveWorld ifNotNil:[^ActiveWorld].
	World ifNotNil:[^World].
	"jmv broken"
	self toBeDeletedJMV.
	self halt.
	^nil! !

!Object methodsFor: 'parts bin' stamp: 'jmv 12/6/2004 20:58'!
descriptionForPartsBin
	"If the receiver is a member of a class that would like to be represented in a parts bin, answer the name by which it should be known, and a documentation string to be provided, for example, as balloon help.  When the 'nativitySelector' is sent to the 'globalReceiver', it is expected that some kind of Morph will result.  The parameters used in the implementation below are for documentation purposes only!!"

	^ "DescriptionForPartsBin
		formalName: 'PutFormalNameHere'
		categoryList: #(PutACategoryHere MaybePutAnotherCategoryHere)
		documentation: 'Put the balloon help here'
		globalReceiverSymbol: #PutAGlobalHere
		nativitySelector: #PutASelectorHere"
	nil! !

!Object methodsFor: 'testing' stamp: 'jmv 12/31/2004 15:45'!
knownName
	"If a formal name has been handed out for this object, answer it, else nil"
	
	^ nil! !

!Object methodsFor: 'testing' stamp: 'jmv 12/31/2004 15:36'!
nameForViewer
	"Answer a name to be shown in a Viewer that is viewing the receiver"

	| aName |
	(aName _ self knownName) ifNotNil: [^ aName].

	^ [(self asString copyWithout: Character cr) truncateTo:  27] ifError:
		[:msg :rcvr | ^ self class name printString]! !


!Class methodsFor: 'testing' stamp: 'jmv 12/31/2004 11:08'!
isSystemDefined
	"Answer true if the receiver is a system-defined class, and not a UniClass (an instance-specific lightweight class)"

	^ true! !


!DeepCopier methodsFor: 'like fullCopy' stamp: 'jmv 12/2/2004 23:13'!
checkBasicClasses
	"Check that no indexes of instance vars have changed in certain classes.  If you get an error in this method, an implementation of veryDeepCopyWith: needs to be updated.  The idea is to catch a change while it is still in the system of the programmer who made it.  
	DeepCopier new checkVariables	"

	| str objCls morphCls |
	str _ '|veryDeepCopyWith: or veryDeepInner: is out of date.'.
	(objCls _ self objInMemory: #Object) ifNotNil: [
		objCls instSize = 0 ifFalse: [self error: 
			'Many implementers of veryDeepCopyWith: are out of date']].
	(morphCls _ self objInMemory: #Morph) ifNotNil: [
		morphCls superclass == Object ifFalse: [self error: 'Morph', str].
		(morphCls instVarNames copyFrom: 1 to: 6) = #('bounds' 'owner' 'submorphs' 
				'fullBounds' 'color' 'extension') 
			ifFalse: [self error: 'Morph', str]].	"added ones are OK"
! !


!Form methodsFor: 'other' stamp: 'jmv 12/2/2004 23:26'!
setAsBackground
	"Set this form as a background image."

	| world newColor |
	Smalltalk isMorphic 
		ifTrue:
			[world _ self currentWorld.
			newColor _ InfiniteForm with: self.
			world color: newColor]
		ifFalse:
			[ScheduledControllers screenController model form: self.
			Display restoreAfter: []]! !


!ImageSegment methodsFor: 'read/write segment' stamp: 'jmv 12/31/2004 15:35'!
copySmartRootsExport: rootArray 
	"Use SmartRefStream to find the object.  Make them all roots.  Create the segment in memory.  Project should be in first five objects in rootArray."
	| newRoots list segSize symbolHolder dummy replacements naughtyBlocks goodToGo allClasses sizeHint proj |
	Smalltalk forgetDoIts.

	symbolHolder _ Symbol allInstances.	"Hold onto Symbols with strong pointers, 
		so they will be in outPointers"

	dummy _ ReferenceStream on: (DummyStream on: nil).
		"Write to a fake Stream, not a file"
	"Collect all objects"
	dummy insideASegment: true.	"So Uniclasses will be traced"
	dummy rootObject: rootArray.	"inform him about the root"
	dummy nextPut: rootArray.
	(proj _dummy project) ifNotNil: [self dependentsSave: dummy].
	allClasses _ SmartRefStream new uniClassInstVarsRefs: dummy.
		"catalog the extra objects in UniClass inst vars.  Put into dummy"
	allClasses do: [:cls | 
		dummy references at: cls class put: false.	"put Player5 class in roots"
		dummy blockers removeKey: cls class ifAbsent: []].
	"refs _ dummy references."
	arrayOfRoots _ self smartFillRoots: dummy.	"guaranteed none repeat"
	replacements _ dummy blockers.
	dummy project "recompute it" ifNil: [self error: 'lost the project!!'].
	dummy project class == DiskProxy ifTrue: [self error: 'saving the wrong project'].
	dummy _ nil.	"force GC?"
	naughtyBlocks _ arrayOfRoots select: [ :each |
		(each isKindOf: ContextPart) and: [each hasInstVarRef]
	].

	"since the caller switched ActiveWorld, put the real one back temporarily"
	naughtyBlocks isEmpty ifFalse: [
		World becomeActiveDuring: [
			goodToGo _ PopUpMenu
				confirm: 
'Some block(s) which reference instance variables 
are included in this segment. These may fail when
the segment is loaded if the class has been reshaped.
What would you like to do?' 
				trueChoice: 'keep going' 
				falseChoice: 'stop and take a look'.
			goodToGo ifFalse: [
				naughtyBlocks inspect.
				self error: 'Here are the bad blocks'].
		].
	].
	"Creation of the segment happens here"

	"try using one-quarter of memory min: four megs to publish (will get bumped later)"
	sizeHint _ (Smalltalk garbageCollect // 4 // 4) min: 1024*1024.
	self copyFromRoots: arrayOfRoots sizeHint: sizeHint areUnique: true.
	segSize _ segment size.
	[(newRoots _ self rootsIncludingBlockMethods) == nil] whileFalse: [
		arrayOfRoots _ newRoots.
		self copyFromRoots: arrayOfRoots sizeHint: segSize areUnique: true].
		"with methods pointed at from outside"
	[(newRoots _ self rootsIncludingBlocks) == nil] whileFalse: [
		arrayOfRoots _ newRoots.
		self copyFromRoots: arrayOfRoots sizeHint: segSize areUnique: true].
		"with methods, blocks from outPointers"
	list _ self compactClassesArray.
	outPointers _ outPointers, ((list select: [:cls | cls ~~ nil]), (Array with: 1717 with: list)).
	1 to: outPointers size do: [:ii | 
		(outPointers at: ii) class == BlockContext ifTrue: [outPointers at: ii put: nil].
		(outPointers at: ii) class == MethodContext ifTrue: [outPointers at: ii put: nil].
		"substitute new object in outPointers"
		(replacements includesKey: (outPointers at: ii)) ifTrue: [
			outPointers at: ii put: (replacements at: (outPointers at: ii))]].
	proj ifNotNil: [self dependentsCancel: proj].
	symbolHolder.! !

!ImageSegment methodsFor: 'read/write segment' stamp: 'jmv 12/2/2004 23:01'!
rootsIncludingPlayers
	"Return a new roots array with more objects.  (Caller should store into rootArray.) Player (non-systemDefined) gets its class and metaclass put into the Roots array.  Then ask for the segment again."

| extras existing |
userRootCnt ifNil: [userRootCnt _ arrayOfRoots size].
extras _ OrderedCollection new.

existing _ arrayOfRoots asIdentitySet.
extras _ extras reject: [ :each | existing includes: each].
extras isEmpty ifTrue: [^ nil].	"no change"

		^ arrayOfRoots, extras	"will contain multiples of some, but reduced later"
! !

!ImageSegment methodsFor: 'testing' stamp: 'jmv 12/2/2004 23:21'!
findRogueRootsAllMorphs: rootArray 
	"This is a tool to track down unwanted pointers into the segment.  If we don't deal with these pointers, the segment turns out much smaller than it should.  These pointers keep a subtree of objects out of the segment.
1) assemble all objects should be in seg:  morph tree, presenter, scripts, player classes, metaclasses.  Put in a Set.
2) Remove the roots from this list.  Ask for senders of each.  Of the senders, forget the ones that are in the segment already.  Keep others.  The list is now all the 'incorrect' pointers into the segment."

	| inSeg testRoots pointIn wld xRoots |
	Smalltalk garbageCollect.
	inSeg := IdentitySet new: 200.
	arrayOfRoots := rootArray.
	(testRoots := self rootsIncludingPlayers) ifNil: [testRoots := rootArray].
	testRoots do: 
			[:obj | 
			(obj isKindOf: Project) 
				ifTrue: 
					[inSeg add: obj.
					wld := obj world].
			].
	xRoots := wld ifNil: [testRoots] ifNotNil: [testRoots , (Array with: wld)].
	xRoots do: 
			[:obj | 
			"root is a project"

			obj isMorph 
				ifTrue: 
					[obj allMorphs do: 
							[:mm | 
							inSeg add: mm].
					]].
	testRoots do: [:each | inSeg remove: each ifAbsent: []].
	"want them to be pointed at from outside"
	pointIn := IdentitySet new: 400.
	inSeg do: [:ob | pointIn addAll: (Smalltalk pointersTo: ob except: inSeg)].
	testRoots do: [:each | pointIn remove: each ifAbsent: []].
	pointIn remove: inSeg array ifAbsent: [].
	pointIn remove: pointIn array ifAbsent: [].
	inSeg do: 
			[:obj | 
			(obj isMorph) 
				ifTrue: 
					[pointIn remove: (obj instVarAt: 3)
						ifAbsent: 
							["submorphs"

							].
					"associations in extension"
					pointIn remove: obj extension ifAbsent: [].
					obj extension ifNotNil: 
							[obj extension otherProperties ifNotNil: 
									[obj extension otherProperties 
										associationsDo: [:ass | pointIn remove: ass ifAbsent: []]
									"*** and extension actorState"
									"*** and ActorState instantiatedUserScriptsDictionary ScriptInstantiations"]]].
			].
	"*** presenter playerlist"
	self halt: 'Examine local variables pointIn and inSeg'.
	^pointIn! !

!ImageSegment methodsFor: 'testing' stamp: 'jmv 12/2/2004 22:30'!
findRogueRootsPrep
	"Part of the tool to track down unwanted pointers into the segment.  Break all owner pointers in submorphs, scripts, and viewers in flaps."

| wld morphs |
wld _ arrayOfRoots detect: [:obj | 
	obj isMorph ifTrue: [obj isWorldMorph] ifFalse: [false]] ifNone: [nil].
wld ifNil: [wld _ arrayOfRoots detect: [:obj | obj isMorph] 
				ifNone: [^ self error: 'can''t find a root morph']].
morphs _ IdentitySet new: 400.
wld allMorphsAndBookPagesInto: morphs.
morphs do: [:mm | 	"break the back pointers"
	mm isInMemory ifTrue: [
	(mm respondsTo: #target) ifTrue: [
		mm nearestOwnerThat: [:ow | ow == mm target 
			ifTrue: [mm target: nil. true]
			ifFalse: [false]]].
	(mm respondsTo: #arguments) ifTrue: [
		mm arguments do: [:arg | arg ifNotNil: [
			mm nearestOwnerThat: [:ow | ow == arg
				ifTrue: [mm arguments at: (mm arguments indexOf: arg) put: nil. true]
				ifFalse: [false]]]]].
	mm eventHandler ifNotNil: ["recipients point back up"
		(morphs includesAllOf: (mm eventHandler allRecipients)) ifTrue: [
			mm eventHandler: nil]].
	"temporary, until using Model for PartsBin"
	(mm isMorphicModel) ifTrue: [
		(mm model isMorphicModel) ifTrue: [
			mm model breakDependents]].
	(mm isTextMorph) ifTrue: [mm setContainer: nil]]].
(Smalltalk includesKey: #Owners) ifTrue: [Smalltalk at: #Owners put: nil].
	"in case findOwnerMap: is commented out"
"self findOwnerMap: morphs."
morphs do: [:mm | 	"break the back pointers"
	mm isInMemory ifTrue: [mm privateOwner: nil]].
"more in extensions?"

! !

!ImageSegment methodsFor: 'fileIn/Out' stamp: 'jmv 12/31/2004 15:35'!
comeFullyUpOnReload: smartRefStream
	"fix up the objects in the segment that changed size.  An object in the segment is the wrong size for the modern version of the class.  Construct a fake class that is the old size.  Replace the modern class with the old one in outPointers.  Load the segment.  Traverse the instances, making new instances by copying fields, and running conversion messages.  Keep the new instances.  Bulk forward become the old to the new.  Let go of the fake objects and classes.
	After the install (below), arrayOfRoots is filled in.  Globalize new classes.  Caller may want to do some special install on certain objects in arrayOfRoots. 
	May want to write the segment out to disk in its new form."

	| mapFakeClassesToReal ccFixups receiverClasses rootsToUnhiberhate myProject |

	self flag: #bobconv.	

	RecentlyRenamedClasses _ nil.		"in case old data hanging around"
	mapFakeClassesToReal _ smartRefStream reshapedClassesIn: outPointers.
		"Dictionary of just the ones that change shape.  Substitute them in outPointers."
	ccFixups _ self remapCompactClasses: mapFakeClassesToReal 
				refStrm: smartRefStream.
	ccFixups ifFalse: [^ self error: 'A class in the file is not compatible'].
	endMarker _ segment nextObject. 	"for enumeration of objects"
	endMarker == 0 ifTrue: [endMarker _ 'End' clone].
	arrayOfRoots _ self loadSegmentFrom: segment outPointers: outPointers.
		"Can't use install.  Not ready for rehashSets"
	mapFakeClassesToReal isEmpty ifFalse: [
		self reshapeClasses: mapFakeClassesToReal refStream: smartRefStream
	].
	receiverClasses _ self restoreEndianness.		"rehash sets"
	smartRefStream checkFatalReshape: receiverClasses.

	"Classes in this segment."
	arrayOfRoots do: [:importedObject | 
		importedObject class class == Metaclass ifTrue: [self declare: importedObject]].
	arrayOfRoots do: [:importedObject | 
		(importedObject isKindOf: CompiledMethod) ifTrue: [
			importedObject sourcePointer > 0 ifTrue: [importedObject zapSourcePointer]].
		(importedObject isKindOf: Project) ifTrue: [
			myProject _ importedObject.
			importedObject ensureChangeSetNameUnique.
			Project addingProject: importedObject.
			self dependentsRestore: importedObject.
			]].
	
	rootsToUnhiberhate _ arrayOfRoots select: [:importedObject | 
		importedObject respondsTo: #unhibernate	"ScriptEditors and ViewerFlapTabs"
	].
	myProject ifNotNil: [
		myProject world setProperty: #thingsToUnhibernate toValue: rootsToUnhiberhate
	].

	mapFakeClassesToReal isEmpty ifFalse: [
		mapFakeClassesToReal keys do: [:aFake | 
			aFake indexIfCompact > 0 ifTrue: [aFake becomeUncompact].
			aFake removeFromSystemUnlogged].
		SystemOrganization removeEmptyCategories].
	"^ self"! !

!ImageSegment methodsFor: 'fileIn/Out' stamp: 'jmv 12/2/2004 23:14'!
declareAndPossiblyRename: classThatIsARoot
	| existing catInstaller |
	"The class just arrived in this segment.  How fit it into the Smalltalk dictionary?  If it had an association, that was installed with associationDeclareAt:."

	catInstaller _ [
			(classThatIsARoot superclass name beginsWith: 'WonderLandActor')
				ifTrue: [classThatIsARoot category: 'Balloon3D-UserObjects']
				ifFalse: [classThatIsARoot category: 'Morphic-Imported'].
	].
	classThatIsARoot superclass addSubclass: classThatIsARoot.
	(Smalltalk includesKey: classThatIsARoot name) ifFalse: [
		"Class entry in Smalltalk not referred to in Segment, install anyway."
		catInstaller value.
		^ Smalltalk at: classThatIsARoot name put: classThatIsARoot].
	existing _ Smalltalk at: classThatIsARoot name.
	existing xxxClass == ImageSegmentRootStub ifTrue: [
		"We are that segment!!  Must ask it carefully!!"
		catInstaller value.
		^ Smalltalk at: classThatIsARoot name put: classThatIsARoot].
	existing == false | (existing == nil) ifTrue: [
		"association is in outPointers, just installed"
		catInstaller value.
		^ Smalltalk at: classThatIsARoot name put: classThatIsARoot].
	"Conflict with existing global or copy of the class"
	(existing isKindOf: Class) ifTrue: [
		classThatIsARoot isSystemDefined not ifTrue: [
			"UniClass.  give it a new name"
			classThatIsARoot setName: classThatIsARoot baseUniclass chooseUniqueClassName.
			catInstaller value.	"must be after new name"
			^ Smalltalk at: classThatIsARoot name put: classThatIsARoot].
		"Take the incoming one"
		self inform: 'Using newly arrived version of ', classThatIsARoot name.
		classThatIsARoot superclass removeSubclass: classThatIsARoot.	"just in case"
		(Smalltalk at: classThatIsARoot name) becomeForward: classThatIsARoot.
		catInstaller value.
		^ classThatIsARoot superclass addSubclass: classThatIsARoot].
	self error: 'Name already in use by a non-class: ', classThatIsARoot name.
! !


!Imports methodsFor: 'images' stamp: 'jmv 12/1/2004 17:44'!
viewImages
	"Open up a special Form inspector on the dictionary of graphical imports."
	"Imports default viewImages"
	| widgetClass |
	imports size isZero ifTrue:
		[^ self inform: 
'The ImageImports repository is currently empty,
so there is nothing to view at this time.  You can
use a file list to import graphics from external files
into Imports, and once you have done that,
you will find this command more interesting.'].
	
	widgetClass := self couldOpenInMorphic
                ifTrue: [GraphicalDictionaryMenu]
			  ifFalse: [nil "fix this!!"].
	widgetClass openOn:  imports withLabel: 'Graphical Imports'

! !


!MethodFinder methodsFor: 'initialize' stamp: 'jmv 12/31/2004 11:09'!
initialize
	"The methods we are allowed to use.  (MethodFinder new initialize) "

	Approved _ Set new.
	AddAndRemove _ Set new.
	Blocks _ Set new.
	"These modify an argument and are not used by the MethodFinder: longPrintOn: printOn: storeOn: sentTo: storeOn:base: printOn:base: absPrintExactlyOn:base: absPrintOn:base: absPrintOn:base:digitCount: writeOn: writeScanOn: possibleVariablesFor:continuedFrom: printOn:format:"

"Object"  
	#("in class, instance creation" categoryForUniclasses chooseUniqueClassName initialInstance isSystemDefined newFrom: readCarefullyFrom:
"accessing" at: basicAt: basicSize bindWithTemp: in: size yourself 
"testing" basicType ifNil: ifNil:ifNotNil: ifNotNil: ifNotNil:ifNil: isColor isFloat isFraction isInMemory isInteger isMorph isNil isNumber isPoint isPseudoContext isText isTransparent isWebBrowser knownName notNil pointsTo: wantsSteps 
"comparing" = == closeTo: hash hashMappedBy: identityHash identityHashMappedBy: identityHashPrintString ~= ~~ 
"copying" clone copy shallowCopy 
"dependents access" canDiscardEdits dependents hasUnacceptedEdits 
"updating" changed changed: okToChange update: windowIsClosing 
"printing" fullPrintString isLiteral longPrintString printString storeString stringForReadout stringRepresentation 
"class membership" class isKindOf: isKindOf:orOf: isMemberOf: respondsTo: xxxClass 
"error handling" 
"user interface" addModelMenuItemsTo:forMorph:hand: defaultBackgroundColor defaultLabelForInspector fullScreenSize initialExtent modelWakeUp mouseUpBalk: newTileMorphRepresentative windowActiveOnFirstClick windowReqNewLabel: 
"system primitives" asOop instVarAt: instVarNamed: 
"private" 
"associating" -> 
"converting" as: asOrderedCollection asString 
"casing" caseOf: caseOf:otherwise: 
"binding" bindingOf: 
"macpal" contentsChanged currentEvent currentHand currentWorld flash ifKindOf:thenDo: instanceVariableValues 
"flagging" flag: 
"translation support" "objects from disk" "finalization" ) do: [:sel | Approved add: sel].
	#(at:add: at:modify: at:put: basicAt:put: "NOT instVar:at:"
"message handling" perform: perform:orSendTo: perform:with: perform:with:with: perform:with:with:with: perform:withArguments: perform:withArguments:inSuperclass: 
) do: [:sel | AddAndRemove add: sel].

"Boolean, True, False, UndefinedObject"  
	#("logical operations" & eqv: not xor: |
"controlling" and: ifFalse: ifFalse:ifTrue: ifTrue: ifTrue:ifFalse: or:
"copying" 
"testing" isEmptyOrNil) do: [:sel | Approved add: sel].

"Behavior" 
	#("initialize-release"
"accessing" compilerClass decompilerClass evaluatorClass format methodDict parserClass sourceCodeTemplate subclassDefinerClass
"testing" instSize instSpec isBits isBytes isFixed isPointers isVariable isWeak isWords
"copying"
"printing" defaultNameStemForInstances printHierarchy
"creating class hierarchy"
"creating method dictionary"
"instance creation" basicNew basicNew: new new:
"accessing class hierarchy" allSubclasses allSubclassesWithLevelDo:startingLevel: allSuperclasses subclasses superclass withAllSubclasses withAllSuperclasses
"accessing method dictionary" allSelectors changeRecordsAt: compiledMethodAt: compiledMethodAt:ifAbsent: firstCommentAt: lookupSelector: selectors selectorsDo: selectorsWithArgs: "slow but useful ->" sourceCodeAt: sourceCodeAt:ifAbsent: sourceMethodAt: sourceMethodAt:ifAbsent:
"accessing instances and variables" allClassVarNames allInstVarNames allSharedPools classVarNames instVarNames instanceCount sharedPools someInstance subclassInstVarNames
"testing class hierarchy" inheritsFrom: kindOfSubclass
"testing method dictionary" canUnderstand: classThatUnderstands: hasMethods includesSelector: scopeHas:ifTrue: whichClassIncludesSelector: whichSelectorsAccess: whichSelectorsReferTo: whichSelectorsReferTo:special:byte: whichSelectorsStoreInto:
"enumerating"
"user interface"
"private" indexIfCompact) do: [:sel | Approved add: sel].

"ClassDescription"
	#("initialize-release" 
"accessing" classVersion isMeta name theNonMetaClass
"copying" 
"printing" classVariablesString instanceVariablesString sharedPoolsString
"instance variables" checkForInstVarsOK: 
"method dictionary" 
"organization" category organization whichCategoryIncludesSelector:
"compiling" acceptsLoggingOfCompilation wantsChangeSetLogging
"fileIn/Out" definition
"private" ) do: [:sel | Approved add: sel].

"Class"
	#("initialize-release" 
"accessing" classPool
"testing"
"copying" 
"class name" 
"instance variables" 
"class variables" classVarAt: classVariableAssociationAt:
"pool variables" 
"compiling" 
"subclass creation" 
"fileIn/Out" ) do: [:sel | Approved add: sel]. 

"Metaclass"
	#("initialize-release" 
"accessing" isSystemDefined soleInstance
"copying" "instance creation" "instance variables"  "pool variables" "class hierarchy"  "compiling"
"fileIn/Out"  nonTrivial ) do: [:sel | Approved add: sel].

"Context, BlockContext"
	#(receiver client method receiver tempAt: 
"debugger access" mclass pc selector sender shortStack sourceCode tempNames tempsAndValues
"controlling"  "printing" "system simulation" 
"initialize-release" 
"accessing" hasMethodReturn home numArgs
"evaluating" value value:ifError: value:value: value:value:value: value:value:value:value: valueWithArguments:
"controlling"  "scheduling"  "instruction decoding"  "printing" "private"  "system simulation" ) do: [:sel | Approved add: sel].
	#(value: "<- Association has it as a store" ) do: [:sel | AddAndRemove add: sel].

"Message"
	#("inclass, instance creation" selector: selector:argument: selector:arguments:
"accessing" argument argument: arguments sends:
"printing" "sending" ) do: [:sel | Approved add: sel].
	#("private" setSelector:arguments:) do: [:sel | AddAndRemove add: sel].

"Magnitude"
	#("comparing" < <= > >= between:and:
"testing" max: min: min:max: ) do: [:sel | Approved add: sel].

"Date, Time"
	#("in class, instance creation" fromDays: fromSeconds: fromString: newDay:month:year: newDay:year: today
	"in class, general inquiries" dateAndTimeNow dayOfWeek: daysInMonth:forYear: daysInYear: firstWeekdayOfMonth:year: indexOfMonth: leapYear: nameOfDay: nameOfMonth:
"accessing" day leap monthIndex monthName weekday year
"arithmetic" addDays: subtractDate: subtractDays:
"comparing"
"inquiries" dayOfMonth daysInMonth daysInYear daysLeftInYear firstDayOfMonth previous:
"converting" asSeconds
"printing" mmddyy mmddyyyy printFormat: 
"private" firstDayOfMonthIndex: weekdayIndex 
	"in class, instance creation" fromSeconds: now 
	"in class, general inquiries" dateAndTimeFromSeconds: dateAndTimeNow millisecondClockValue millisecondsToRun: totalSeconds
"accessing" hours minutes seconds
"arithmetic" addTime: subtractTime:
"comparing"
"printing" intervalString print24 
"converting") do: [:sel | Approved add: sel].
	#("private" hours: hours:minutes:seconds: day:year: 
		 ) do: [:sel | AddAndRemove add: sel].

"Number"
	#("in class" readFrom:base: 
"arithmetic" * + - / // \\ abs negated quo: reciprocal rem:
"mathematical functions" arcCos arcSin arcTan arcTan: cos exp floorLog: ln log log: raisedTo: raisedToInteger: sin sqrt squared tan
"truncation and round off" ceiling detentBy:atMultiplesOf:snap: floor roundTo: roundUpTo: rounded truncateTo: truncated
"comparing"
"testing" even isDivisibleBy: isInf isInfinite isNaN isZero negative odd positive sign strictlyPositive
"converting" @ asInteger asNumber asPoint asSmallAngleDegrees degreesToRadians radiansToDegrees
"intervals" to: to:by: 
"printing" printStringBase: storeStringBase: ) do: [:sel | Approved add: sel].

"Integer"
	#("in class" primesUpTo:
"testing" isPowerOfTwo
"arithmetic" alignedTo:
"comparing"
"truncation and round off" atRandom normalize
"enumerating" timesRepeat:
"mathematical functions" degreeCos degreeSin factorial gcd: lcm: take:
"bit manipulation" << >> allMask: anyMask: bitAnd: bitClear: bitInvert bitInvert32 bitOr: bitShift: bitXor: lowBit noMask:
"converting" asCharacter asColorOfDepth: asFloat asFraction asHexDigit
"printing" asStringWithCommas hex hex8 radix:
"system primitives" lastDigit replaceFrom:to:with:startingAt:
"private" "benchmarks" ) do: [:sel | Approved add: sel].

"SmallInteger, LargeNegativeInteger, LargePositiveInteger"
	#("arithmetic" "bit manipulation" highBit "testing" "comparing" "copying" "converting" "printing" 
"system primitives" digitAt: digitLength 
"private" fromString:radix: ) do: [:sel | Approved add: sel].
	#(digitAt:put: ) do: [:sel | AddAndRemove add: sel].

"Float"
	#("arithmetic"
"mathematical functions" reciprocalFloorLog: reciprocalLogBase2 timesTwoPower:
"comparing" "testing"
"truncation and round off" exponent fractionPart integerPart significand significandAsInteger
"converting" asApproximateFraction asIEEE32BitWord asTrueFraction
"copying") do: [:sel | Approved add: sel].

"Fraction, Random"
	#(denominator numerator reduced next nextValue) do: [:sel | Approved add: sel].
	#(setNumerator:denominator:) do: [:sel | AddAndRemove add: sel].

"Collection"
	#("accessing" anyOne
"testing" includes: includesAllOf: includesAnyOf: includesSubstringAnywhere: isEmpty isSequenceable occurrencesOf:
"enumerating" collect: collect:thenSelect: count: detect: detect:ifNone: detectMax: detectMin: detectSum: inject:into: reject: select: select:thenCollect:
"converting" asBag asCharacterSet asSet asSortedArray asSortedCollection asSortedCollection:
"printing"
"private" maxSize
"arithmetic"
"math functions" average max median min range sum) do: [:sel | Approved add: sel].
	#("adding" add: addAll: addIfNotPresent:
"removing" remove: remove:ifAbsent: removeAll: removeAllFoundIn: removeAllSuchThat: remove:ifAbsent:) do: [:sel | AddAndRemove add: sel].

"SequenceableCollection"
	#("comparing" hasEqualElements:
"accessing" allButFirst allButLast at:ifAbsent: atAll: atPin: atRandom: atWrap: fifth first fourth identityIndexOf: identityIndexOf:ifAbsent: indexOf: indexOf:ifAbsent: indexOf:startingAt:ifAbsent: indexOfSubCollection:startingAt: indexOfSubCollection:startingAt:ifAbsent: last second sixth third
"removing"
"copying" , copyAfterLast: copyAt:put: copyFrom:to: copyReplaceAll:with: copyReplaceFrom:to:with: copyUpTo: copyUpToLast: copyWith: copyWithout: copyWithoutAll: forceTo:paddingWith: shuffled sortBy:
"enumerating" collectWithIndex: findFirst: findLast: pairsCollect: with:collect: withIndexCollect: polynomialEval:
"converting" asArray asDictionary asFloatArray asIntegerArray asStringWithCr asWordArray reversed
"private" copyReplaceAll:with:asTokens: ) do: [:sel | Approved add: sel].
	#( swap:with:) do: [:sel | AddAndRemove add: sel].

"ArrayedCollection, Bag"
	#("private" defaultElement 
"sorting" isSorted
"accessing" cumulativeCounts sortedCounts sortedElements "testing" "adding" add:withOccurrences: "removing" "enumerating" 
	) do: [:sel | Approved add: sel].
	#( mergeSortFrom:to:by: sort sort: add: add:withOccurrences:
"private" setDictionary ) do: [:sel | AddAndRemove add: sel].

"Other messages that modify the receiver"
	#(atAll:put: atAll:putAll: atAllPut: atWrap:put: replaceAll:with: replaceFrom:to:with:  removeFirst removeLast) do: [:sel | AddAndRemove add: sel].

	self initialize2.

"
MethodFinder new initialize.
MethodFinder new organizationFiltered: Set
"

! !


!Model methodsFor: 'dependents' stamp: 'jmv 12/20/2004 21:32'!
containingWindow
	"Answer the window that holds the receiver.  The dependents technique is odious and may not be airtight, if multiple windows have the same model."

	^ self dependents detect:
		[:d | (d isKindOf: SystemWindow orOf: StandardSystemView) and: [d model == self]] ifNone: [nil]! !


!Morph methodsFor: 'WiW support' stamp: 'jmv 12/24/2004 14:59'!
eToyRejectDropMorph: morphToDrop event: evt

	| tm am |

	tm _ TextMorph new 
		contents: 'GOT IT!!'.
	(am _ AlignmentMorph new)
		color: Color yellow;
		layoutInset: 10;
		useRoundedCorners;
		vResizing: #shrinkWrap;
		hResizing: #shrinkWrap;
		addMorph: tm;
		fullBounds;
		position: (self bounds center - (am extent // 2));
		openInWorld: self world.
	SoundService default playSoundNamed: 'yum' ifAbsentReadFrom: 'yum.aif'.
	morphToDrop rejectDropMorphEvent: evt.		"send it back where it came from"
	am delete
! !

!Morph methodsFor: 'accessing' stamp: 'jmv 12/8/2004 12:50'!
balloonText
	"Answer balloon help text or nil, if no help is available.  
	NB: subclasses may override such that they programatically  
	construct the text, for economy's sake, such as model phrases in 
	a Viewer"

	| text balloonSelector aString |
	self hasExtension ifFalse: [^nil].
	(text := self extension balloonText) ifNotNil: [^text].
	(balloonSelector := self extension balloonTextSelector) ifNotNil: 
			[aString := ScriptingSystem helpStringOrNilFor: balloonSelector.
			((aString isNil and: [balloonSelector numArgs = 0]) 
				and: [self respondsTo: balloonSelector]) 
					ifTrue: [aString := self perform: balloonSelector]].
	^aString ifNotNil: 
			[aString asString 
				withNoLineLongerThan: Preferences maxBalloonHelpLineLength]! !

!Morph methodsFor: 'caching' stamp: 'jmv 12/25/2004 14:19'!
releaseCachedState
	"Release any state that can be recomputed on demand, such as the pixel values for a color gradient or the editor state for a TextMorph. This method may be called to save space when a morph becomes inaccessible. Implementations of this method should do 'super releaseCachedState'."
	self borderStyle releaseCachedState.
! !

!Morph methodsFor: 'change reporting' stamp: 'jmv 12/25/2004 14:20'!
invalidRect: aRectangle from: aMorph
	| damageRect |
	aRectangle hasPositiveExtent ifFalse: [ ^self ].
	damageRect _ aRectangle.
	aMorph == self ifFalse:[
		"Clip to receiver's clipping bounds if the damage came from a child"
		self clipSubmorphs 
			ifTrue:[damageRect _ aRectangle intersect: self clippingBounds]].
	owner ifNotNil: [owner invalidRect: damageRect from: self]
! !

!Morph methodsFor: 'copying' stamp: 'jmv 12/1/2004 12:12'!
duplicate
	"Make and return a duplicate of the receiver"

	| newMorph aName w |
	self okayToDuplicate ifFalse: [^ self].
	aName _ (w _ self world) ifNotNil:
		[w nameForCopyIfAlreadyNamed: self].
	newMorph _ self veryDeepCopy.
	aName ifNotNil: [newMorph setNameTo: aName].

	newMorph arrangeToStartStepping.
	newMorph privateOwner: nil. "no longer in world"
	newMorph isPartsDonor: false. "no longer parts donor"

	^ newMorph! !

!Morph methodsFor: 'debug and other' stamp: 'jmv 12/1/2004 12:38'!
buildDebugMenu: aHand
	"Answer a debugging menu for the receiver.  The hand argument is seemingly historical and plays no role presently"

	| aMenu aPlayer |
	aMenu _ MenuMorph new defaultTarget: self.
	aMenu addStayUpItem.
	(self hasProperty: #errorOnDraw) ifTrue:
		[aMenu add: 'start drawing again' translated action: #resumeAfterDrawError.
		aMenu addLine].
	(self hasProperty: #errorOnStep) ifTrue:
		[aMenu add: 'start stepping again' translated action: #resumeAfterStepError.
		aMenu addLine].

	aMenu add: 'inspect morph' translated action: #inspectInMorphic:.
	aMenu add: 'inspect owner chain' translated action: #inspectOwnerChain.
	Smalltalk isMorphic ifFalse:
		[aMenu add: 'inspect morph (in MVC)' translated action: #inspect].

	self isMorphicModel ifTrue:
		[aMenu add: 'inspect model' translated target: self model action: #inspect].
	(aPlayer _ self player) ifNotNil:
		[aMenu add: 'inspect player' translated target: aPlayer action: #inspect].

     aMenu add: 'explore morph' translated target: self selector: #explore.

	aMenu addLine.

	aPlayer ifNotNil:
		[aPlayer class isUniClass ifTrue: [
			aMenu add: 'browse player class' translated target: aPlayer action: #browseHierarchy]].
	aMenu add: 'browse morph class' translated target: self selector: #browseHierarchy.
	(self isMorphicModel)
		ifTrue: [aMenu
				add: 'browse model class'
				target: self model
				selector: #browseHierarchy].
	aMenu addLine.

	aMenu add: 'morph protocol (text)' translated target: self selector: #haveFullProtocolBrowsed.

	aMenu addLine.

	aMenu 
		add: 'make own subclass' translated action: #subclassMorph;
		add: 'internal name ' translated action: #choosePartName;
		add: 'save morph in file' translated  action: #saveOnFile;
		addLine;
		add: 'call #tempCommand' translated action: #tempCommand;
		add: 'define #tempCommand' translated action: #defineTempCommand;
		addLine;

		add: 'control-menu...' translated target: self selector: #invokeMetaMenu:;
		add: 'edit balloon help' translated action: #editBalloonHelpText.

	^ aMenu! !

!Morph methodsFor: 'dropping/grabbing' stamp: 'jmv 12/25/2004 14:39'!
aboutToBeGrabbedBy: aHand
	"The receiver is being grabbed by a hand.
	Perform necessary adjustments (if any) and return the actual morph
	that should be added to the hand."
	self formerOwner: owner.
	self formerPosition: self position.
	^self "Grab me"! !

!Morph methodsFor: 'dropping/grabbing' stamp: 'jmv 12/8/2004 09:44'!
justDroppedInto: aMorph event: anEvent
	"This message is sent to a dropped morph after it has been dropped on -- and been accepted by -- a drop-sensitive morph"

	| aWindow |
	self formerOwner: nil.
	self formerPosition: nil.
	self isPartsDonor: false.
	(aWindow _ aMorph ownerThatIsA: SystemWindow) ifNotNil:
		[aWindow isActive ifFalse:
			[aWindow activate]].
	(self isInWorld ) ifTrue:
		[self world startSteppingSubmorphsOf: self].
	"Note an unhappy inefficiency here:  the startStepping... call will often have already been called in the sequence leading up to entry to this method, but unfortunately the isPartsDonor: call often will not have already happened, with the result that the startStepping... call will not have resulted in the startage of the steppage."

	"An object launched by certain parts-launcher mechanisms should end up fully visible..."
	(self hasProperty: #beFullyVisibleAfterDrop) ifTrue:
		[aMorph == ActiveWorld ifTrue:
			[self goHome].
		self removeProperty: #beFullyVisibleAfterDrop]
! !

!Morph methodsFor: 'dropping/grabbing' stamp: 'jmv 12/8/2004 09:45'!
rejectDropMorphEvent: evt
	"The receiver has been rejected, and must be put back somewhere.  There are three cases:
	(1)  It remembers its former owner and position, and goes right back there
	(2)  It remembers its former position only, in which case it was torn off from a parts bin, and the UI is that it floats back to its donor position and then vanishes.
	(3)  Neither former owner nor position is remembered, in which case it is whisked to the Trash"

	(self formerOwner notNil ) ifTrue:
		[^ self slideBackToFormerSituation: evt].

	self formerPosition ifNotNil:  "Position but no owner -- can just make it vanish"
		[^ self vanishAfterSlidingTo: self formerPosition event: evt].
		
	self slideToTrash: evt! !

!Morph methodsFor: 'dropping/grabbing' stamp: 'jmv 12/6/2004 09:54'!
slideToTrash: evt
	"Perhaps slide the receiver across the screen to a trash can and make it disappear into it.  In any case, remove the receiver from the screen."

	self delete.
	ActiveWorld displayWorld! !

!Morph methodsFor: 'dropping/grabbing' stamp: 'jmv 12/6/2004 09:54'!
vanishAfterSlidingTo: aPosition event: evt

	| aForm aWorld startPoint endPoint |
	aForm _ self imageForm offset: 0@0.
	aWorld _ self world.
	startPoint _ evt hand fullBounds origin.
	self delete.
	aWorld displayWorld.
	endPoint _ aPosition.
	aForm slideFrom: startPoint  to: endPoint nSteps: 12 delay: 15
! !

!Morph methodsFor: 'e-toy support' stamp: 'jmv 12/1/2004 12:09'!
allMorphsAndBookPagesInto: aSet
	"Return a set of all submorphs.  Don't forget the hidden ones like BookMorph pages that are not showing.  Consider only objects that are in memory (see allNonSubmorphMorphs)." 

	submorphs do: [:m | m allMorphsAndBookPagesInto: aSet].
	self allNonSubmorphMorphs do: [:m | 
			(aSet includes: m) ifFalse: ["Stop infinite recursion"
				m allMorphsAndBookPagesInto: aSet]].
	aSet add: self.
	^ aSet! !

!Morph methodsFor: 'e-toy support' stamp: 'jmv 12/20/2004 21:33'!
containingWindow
	"Answer a window or window-with-mvc that contains the receiver"

	^ self ownerThatIsA: SystemWindow! !

!Morph methodsFor: 'events-processing' stamp: 'jmv 12/1/2004 13:20'!
handleDropMorph: anEvent
	"Handle a dropping morph."
	| aMorph localPt |
	aMorph _ anEvent contents.
	"Do a symmetric check if both morphs like each other"
	((self wantsDroppedMorph: aMorph event: anEvent)	"I want her"
		and: [aMorph wantsToBeDroppedInto: self])		"she wants me"
		ifFalse: [
				^ self].
	anEvent wasHandled: true.
	"Transform the morph into the receiver's coordinate frame. This is currently incomplete since it only takes the offset into account where it really should take the entire transform."
	localPt _ (self transformedFrom: anEvent hand world) "full transform down"
				globalPointToLocal: aMorph referencePosition.
	aMorph referencePosition: localPt.
	self acceptDroppingMorph: aMorph event: anEvent.
	aMorph justDroppedInto: self event: anEvent.
! !

!Morph methodsFor: 'events-processing' stamp: 'jmv 12/8/2004 12:39'!
handleMouseEnter: anEvent
	"System level event handling."
	(anEvent isDraggingEvent) ifTrue:[
		(self handlesMouseOverDragging: anEvent) ifTrue:[
			anEvent wasHandled: true.
			self mouseEnterDragging: anEvent].
		^self].
	self wantsBalloon
			ifTrue:[anEvent hand triggerBalloonFor: self after: self balloonHelpDelayTime].
	(self handlesMouseOver: anEvent) ifTrue:[
		anEvent wasHandled: true.
		self mouseEnter: anEvent.
	].! !

!Morph methodsFor: 'events-processing' stamp: 'jmv 12/8/2004 09:45'!
mouseDownPriority
	"Return the default mouse down priority for the receiver"

	^ (self isPartsDonor )
		ifTrue:	[50]
		ifFalse:	[0]

	"The above is a workaround for the complete confusion between parts donors and parts bins. Morphs residing in a parts bin may or may not have the parts donor property set; if they have they may or may not actually handle events. To work around this, parts bins get an equal priority to parts donors so that when a morph in the parts bin does have the property set but does not handle the event we still get a copy from picking it up through the parts bin. Argh. This just *cries* for a cleanup."
	"And the above comment is Andreas's from 10/2000, which was formerly retrievable by a #flag: call which however caused a problem when trying to recompile the method from decompiled source."! !

!Morph methodsFor: 'geometry' stamp: 'jmv 12/5/2004 16:50'!
shiftSubmorphsBy: delta
	self shiftSubmorphsOtherThan: (submorphs select: [:m | false]) by: delta! !

!Morph methodsFor: 'halos and balloon help' stamp: 'jmv 12/20/2004 21:28'!
balloonHelpTextForHandle: aHandle
	"Answer a string providing balloon help for the given halo handle"

	|  itsSelector |
	itsSelector _ aHandle eventHandler firstMouseSelector.
	#(	(addFullHandles							'More halo handles')
		(addSimpleHandles						'Fewer halo handles')
		(chooseEmphasisOrAlignment				'Emphasis & alignment')
		(chooseFont								'Change font')
		(chooseNewGraphicFromHalo				'Choose a new graphic')
		(chooseStyle								'Change style')
		(dismiss									'Remove')
		(doDebug:with:							'Debug')
		(doDirection:with:						'Choose forward direction')
		(doDup:with:							'Duplicate')
		(doMenu:with:							'Menu')
		(doGrab:with:							'Pick up')
		(doRecolor:with:							'Change color')
		(editDrawing							'Repaint')
		(maybeDoDup:with:						'Duplicate')
		(makeNewDrawingWithin				'Paint new object')
		(mouseDownInCollapseHandle:with:		'Collapse')
		(mouseDownOnHelpHandle:				'Help')
		(prepareToTrackCenterOfRotation:with:	'Move object or set center of rotation')
		(startDrag:with:							'Move')
		(startGrow:with:							'Change size') 
		(startRot:with:							'Rotate')
		(startScale:with:							'Change scale') 
		(trackCenterOfRotation:with:				'Set center of rotation')) 


	do:
		[:pair | itsSelector == pair first ifTrue: [^ pair last]].

	(itsSelector == #mouseDownInDimissHandle:with:) ifTrue:
				['Remove from screen'].

	^ 'unknown halo handle'! !

!Morph methodsFor: 'initialization' stamp: 'jmv 12/25/2004 14:33'!
inATwoWayScrollPane
	"Answer a two-way scroll pane that allows the user to scroll the receiver in either direction.  It will have permanent scroll bars unless you take some special action."

	| widget |
	widget _ ScrollPane new.
	widget extent: ((self width min: 300 max: 100) @ (self height min: 150 max: 100));
		borderWidth: 0.
	widget scroller addMorph: self.
	widget setScrollDeltas.
	widget color: self color darker darker.
	^ widget! !

!Morph methodsFor: 'initialization' stamp: 'jmv 12/20/2004 21:37'!
openInWorld
        "Add this morph to the world.  If in MVC, then provide a Morphic window for it."

        self couldOpenInMorphic
                ifTrue: [self openInWorld: self currentWorld]
                ifFalse: [self halt openInMVC]! !

!Morph methodsFor: 'menus' stamp: 'jmv 12/1/2004 17:48'!
absorbStateFromRenderer: aRenderer 
	| current |
	"Transfer knownName, actorState, and player info over from aRenderer, which was formerly imposed above me as a transformation shell but is now going away."

	(current _ aRenderer knownName) ifNotNil:
		[self setNameTo: current.
		aRenderer setNameTo: nil].

	(current _ aRenderer player) ifNotNil:
		[self player: current.
		current rawCostume: self.
		aRenderer player: nil]! !

!Morph methodsFor: 'menus' stamp: 'jmv 12/5/2004 15:54'!
addCopyItemsTo: aMenu
	"Add copy-like items to the halo menu"

	| subMenu |
	subMenu _ MenuMorph new defaultTarget: self.
	subMenu add: 'copy to paste buffer' translated action: #copyToPasteBuffer:.
	subMenu add: 'copy text' translated action: #clipText.
	aMenu add: 'copy & print...' translated subMenu: subMenu! !

!Morph methodsFor: 'menus' stamp: 'jmv 12/1/2004 12:27'!
addHaloActionsTo: aMenu
	"Add items to aMenu representing actions requestable via halo"

	| subMenu |
	subMenu _ MenuMorph new defaultTarget: self.
	subMenu addTitle: self externalName.
	subMenu addStayUpItemSpecial.
	subMenu addLine.
	subMenu add: 'delete' translated action: #dismissViaHalo.
	subMenu balloonTextForLastItem: 'Delete this object -- warning -- can be destructive!!' translated.

	self maybeAddCollapseItemTo: subMenu.
	subMenu add: 'grab' translated action: #openInHand.
	subMenu balloonTextForLastItem: 'Pick this object up -- warning, since this removes it from its container, it can have adverse effects.' translated.

	subMenu addLine.

	subMenu add: 'resize' translated action: #resizeFromMenu.
	subMenu balloonTextForLastItem: 'Change the size of this object' translated.

	subMenu add: 'duplicate' translated action: #maybeDuplicateMorph.
	subMenu balloonTextForLastItem: 'Hand me a copy of this object' translated.

	subMenu add: 'set color' translated target: self renderedMorph action: #changeColor.
	subMenu balloonTextForLastItem: 'Change the color of this object' translated.

	subMenu add: 'inspect' translated target: self action: #inspect.
	subMenu balloonTextForLastItem: 'Open an Inspector on this object' translated.

	aMenu add: 'halo actions...' translated subMenu: subMenu
! !

!Morph methodsFor: 'menus' stamp: 'jmv 12/28/2004 22:51'!
addMiscExtrasTo: aMenu
	"Add a submenu of miscellaneous extra items to the menu."

	| subMenu |
	subMenu _ MenuMorph new defaultTarget: self.
	(self isWorldMorph not and: [(self renderedMorph isSystemWindow) not])
		ifTrue: [subMenu add: 'put in a window' translated action: #embedInWindow].

	self isWorldMorph ifFalse:
		[subMenu add: 'adhere to edge...' translated action: #adhereToEdge.
		subMenu addLine].

	subMenu
		add: 'add mouse up action' translated action: #addMouseUpAction;
		add: 'remove mouse up action' translated action: #removeMouseUpAction.
	subMenu addLine.

	subMenu defaultTarget: self topRendererOrSelf.

	self addGestureMenuItems: subMenu hand: ActiveHand.

	aMenu add: 'extras...' translated subMenu: subMenu! !

!Morph methodsFor: 'menus' stamp: 'jmv 12/1/2004 12:12'!
addStandardHaloMenuItemsTo: aMenu hand: aHandMorph
	"Add standard halo items to the menu"

	| unlockables |

	self isWorldMorph ifTrue:
		[^ self addWorldHaloMenuItemsTo: aMenu hand: aHandMorph].

	self mustBeBackmost ifFalse:
		[aMenu add: 'send to back' translated action: #goBehind.
		aMenu add: 'bring to front' translated action: #comeToFront.
		self addEmbeddingMenuItemsTo: aMenu hand: aHandMorph.
		aMenu addLine].

	self addFillStyleMenuItems: aMenu hand: aHandMorph.
	self addBorderStyleMenuItems: aMenu hand: aHandMorph.
	self addDropShadowMenuItems: aMenu hand: aHandMorph.
	self addLayoutMenuItems: aMenu hand: aHandMorph.
	self addHaloActionsTo: aMenu.
	owner isTextMorph ifTrue:[self addTextAnchorMenuItems: aMenu hand: aHandMorph].
	aMenu addLine.
	self addToggleItemsToHaloMenu: aMenu.
	aMenu addLine.
	self addCopyItemsTo: aMenu.
	self addExportMenuItems: aMenu hand: aHandMorph.
	self addMiscExtrasTo: aMenu.
	Preferences noviceMode ifFalse:
		[self addDebuggingItemsTo: aMenu hand: aHandMorph].

	aMenu addLine.
	aMenu defaultTarget: self.

	aMenu addLine.

	unlockables _ self submorphs select:
		[:m | m isLocked].
	unlockables size == 1 ifTrue:
		[aMenu
			add: ('unlock "{1}"' translated format: unlockables first externalName)
			action: #unlockContents].
	unlockables size > 1 ifTrue:
		[aMenu add: 'unlock all contents' translated action: #unlockContents.
		aMenu add: 'unlock...' translated action: #unlockOneSubpart].

	aMenu defaultTarget: aHandMorph.
! !

!Morph methodsFor: 'menus' stamp: 'jmv 12/1/2004 17:48'!
transferStateToRenderer: aRenderer
	| current |
	"Transfer knownName, actorState, and player info over to aRenderer, which is being imposed above me as a transformation shell"
	
	(current _ self knownName) ifNotNil:
		[aRenderer setNameTo: current.
		self setNameTo: nil].

	(current _ self player) ifNotNil:
		[aRenderer player: current.
		self player rawCostume: aRenderer.
		"self player: nil"]! !

!Morph methodsFor: 'meta-actions' stamp: 'jmv 12/28/2004 22:50'!
buildMetaMenu: evt
	"Build the morph menu. This menu has two sections. The first section contains commands that are handled by the hand; the second contains commands handled by the argument morph."
	| menu |
	menu _ MenuMorph new defaultTarget: self.
	menu addStayUpItem.
	menu add: 'grab' translated action: #grabMorph:.
	menu add: 'copy to paste buffer' translated action: #copyToPasteBuffer:.
	self maybeAddCollapseItemTo: menu.
	menu add: 'delete' translated action: #dismissMorph:.
	menu addLine.
	menu add: 'copy text' translated action: #clipText.
	menu addLine.
	menu add: 'go behind' translated action: #goBehind.
	menu add: 'add halo' translated action: #addHalo:.
	menu add: 'duplicate' translated action: #maybeDuplicateMorph:.

	self addEmbeddingMenuItemsTo: menu hand: evt hand.

	menu add: 'resize' translated action: #resizeMorph:.
	"Give the argument control over what should be done about fill styles"
	self addFillStyleMenuItems: menu hand: evt hand.
	self addDropShadowMenuItems: menu hand: evt hand.
	self addLayoutMenuItems: menu hand: evt hand.
	menu addUpdating: #hasClipSubmorphsString target: self selector: #changeClipSubmorphs argumentList: #().
	menu addLine.

	(self morphsAt: evt position) size > 1 ifTrue:
		[menu add: 'submorphs...' translated
			target: self
			selector: #invokeMetaMenuAt:event:
			argument: evt position].
	menu addLine.
	menu add: 'inspect' translated selector: #inspectAt:event: argument: evt position.
	menu add: 'explore' translated action: #explore.
	menu add: 'browse hierarchy' translated action: #browseHierarchy.
	menu add: 'make own subclass' translated action: #subclassMorph.
	menu addLine.
	menu add: 'set variable name...' translated action: #choosePartName.
	(self isMorphicModel) ifTrue:
		[menu add: 'save morph as prototype' translated action: #saveAsPrototype.
		(self ~~ self world modelOrNil) ifTrue:
			 [menu add: 'become this world''s model' translated action: #beThisWorldsModel]].
	menu add: 'save morph in file' translated action: #saveOnFile.
	menu add: 'show actions' translated action: #showActions.
	menu addLine.
	self addDebuggingItemsTo: menu hand: evt hand.

	self addCustomMenuItems: menu hand: evt hand.
	^ menu
! !

!Morph methodsFor: 'meta-actions' stamp: 'jmv 12/5/2004 16:55'!
handlerForBlueButtonDown: anEvent
	"Return the (prospective) handler for a mouse down event. The handler is temporarily installed and can be used for morphs further down the hierarchy to negotiate whether the inner or the outer morph should finally handle the event.
	Note: Halos handle blue button events themselves so we will only be asked if there is currently no halo on top of us."
	self wantsHaloFromClick ifFalse:[^nil].
	anEvent handler ifNil:[^self].
	anEvent handler isPlayfieldLike ifTrue:[^self]. "by default exclude playfields"
	(anEvent shiftPressed)
		ifFalse:[^nil] "let outer guy have it"
		ifTrue:[^self] "let me have it"
! !

!Morph methodsFor: 'meta-actions' stamp: 'jmv 12/8/2004 12:29'!
resizeMorph: evt
	| handle |
	handle _ HandleMorph new forEachPointDo: [:newPoint | 
		self extent: newPoint - self bounds topLeft].
	evt hand attachMorph: handle.
	handle startStepping.
! !

!Morph methodsFor: 'naming' stamp: 'jmv 12/1/2004 18:12'!
choosePartName
	"Pick an unused name for this morph."
	| className |
	className _ self class name.
	(className size > 5 and: [className endsWith: 'Morph'])
		ifTrue: [className _ className copyFrom: 1 to: className size - 5].
	^ self world model addPartNameLike: className withValue: self! !

!Morph methodsFor: 'objects from disk' stamp: 'jmv 12/20/2004 21:22'!
objectForDataStream: refStrm 
	"I am being written out on an object file"
	self prepareToBeSaved.	"Amen"
	^self! !

!Morph methodsFor: 'submorphs-accessing' stamp: 'jmv 12/8/2004 09:42'!
allSubmorphNamesDo: nameBlock
	"Return a list of all known names of submorphs and nested submorphs of the receiver, based on the scope of the receiver.  Items in parts bins are excluded"

	self submorphsDo: 
		[:m | m knownName ifNotNilDo: [:n | nameBlock value: n].
		m allSubmorphNamesDo: nameBlock].
! !

!Morph methodsFor: 'submorphs-add/remove' stamp: 'jmv 12/2/2004 22:50'!
delete
	"Remove the receiver as a submorph of its owner and make its 
	new owner be nil."

	| aWorld |
	aWorld := self world ifNil: [World].
	"Terminate genie recognition focus"
	"I encountered a case where the hand was nil, so I put in a little 
	protection - raa "
	" This happens when we are in an MVC project and open
	  a morphic window. - BG "
	aWorld ifNotNil:
	  [self disableSubmorphFocusForHand: self activeHand.
	  self activeHand releaseKeyboardFocus: self;
		  releaseMouseFocus: self.].
	owner ifNotNil:[ self privateDelete].! !

!Morph methodsFor: 'submorphs-add/remove' stamp: 'jmv 12/6/2004 09:52'!
dismissViaHalo
	"The user has clicked in the delete halo-handle.  This provides a hook in case some concomitant action should be taken, or if the particular morph is not one which should be put in the trash can, for example."

	^ self dismissMorph: ActiveEvent! !

!Morph methodsFor: 'private' stamp: 'jmv 12/1/2004 17:55'!
privateMoveBy: delta 
	"Private!! Use 'position:' instead."
	| fill |
	bounds _ bounds translateBy: delta.
	fullBounds
		ifNotNil: [fullBounds _ fullBounds translateBy: delta].
	fill _ self fillStyle.
	fill isOrientedFill
		ifTrue: [fill origin: fill origin + delta]! !

!Morph methodsFor: '*geniestubs-stubs' stamp: 'jmv 12/25/2004 14:29'!
handleMouseDown: anEvent
	"System level event handling."
	anEvent wasHandled ifTrue:[^self]. "not interested"
	anEvent hand removePendingBalloonFor: self.
	anEvent hand removePendingHaloFor: self.
	anEvent wasHandled: true.

	(anEvent controlKeyPressed
			and: [Preferences cmdGesturesEnabled])
		ifTrue: [^ self invokeMetaMenu: anEvent].

	"Make me modal during mouse transitions"
	anEvent hand newMouseFocus: self event: anEvent.
	anEvent blueButtonChanged ifTrue:[^self blueButtonDown: anEvent].

	self mouseDown: anEvent.
	anEvent hand removeHaloFromClick: anEvent on: self.

	(self handlesMouseStillDown: anEvent) ifTrue:[
		self startStepping: #handleMouseStillDown: 
			at: Time millisecondClockValue + self mouseStillDownThreshold
			arguments: {anEvent copy resetHandlerFields}
			stepTime: self mouseStillDownStepRate ].
! !


!BorderedMorph methodsFor: 'menu' stamp: 'jmv 12/6/2004 20:43'!
changeBorderWidth: evt
	| handle origin aHand newWidth |
	aHand _ evt ifNil: [self primaryHand] ifNotNil: [evt hand].
	origin _ aHand position.
	handle _ HandleMorph new
		forEachPointDo:
			[:newPoint | handle removeAllMorphs.
			handle addMorph:
				(LineMorph from: origin to: newPoint color: Color black width: 1).
			newWidth _ (newPoint - origin) r asInteger // 5.
			self borderWidth: newWidth]
		lastPointDo:
			[:newPoint | handle deleteBalloon.
			self halo ifNotNilDo: [:halo | halo addHandles].
			].
	aHand attachMorph: handle.
	handle setProperty: #helpAtCenter toValue: true.
	handle showBalloon:
'Move cursor farther from
this point to increase border width.
Click when done.' hand: evt hand.
	handle startStepping! !


!AlignmentMorph methodsFor: 'initialization' stamp: 'jmv 12/6/2004 20:52'!
addUpDownArrowsFor: aMorph
	"Add a column of up and down arrows that serve to send upArrowHit and downArrowHit to aMorph when they're pressed/held down"

	| holder downArrow upArrow |
	holder _ Morph new extent: 16 @ 16; beTransparent.
	downArrow _ ImageMorph new image: (ScriptingSystem formAtKey: 'DownArrow').
	upArrow _ ImageMorph new image: (ScriptingSystem formAtKey: 'UpArrow').
	upArrow position: holder bounds topLeft + (2@2).
	downArrow align: downArrow bottomLeft
				with: holder topLeft + (0 @ "TileMorph defaultH" 22) + (2@-2).
	holder addMorph: upArrow.
	holder addMorph: downArrow.
	self addMorphBack: holder.
	upArrow on: #mouseDown send: #upArrowHit to: aMorph.
	upArrow on: #mouseStillDown send: #upArrowHit to: aMorph.
	downArrow on: #mouseDown send: #downArrowHit to: aMorph.
	downArrow on: #mouseStillDown send: #downArrowHit to: aMorph.! !


!CodecDemoMorph methodsFor: 'dropping/grabbing' stamp: 'jmv 12/6/2004 22:03'!
wantsDroppedMorph: aMorph event: evt

	^ false! !


!HaloMorph methodsFor: 'dropping/grabbing' stamp: 'jmv 12/1/2004 12:35'!
startDrag: evt with: dragHandle
	"Drag my target without removing it from its owner."

	| |
	self obtainHaloForEvent: evt andRemoveAllHandlesBut: dragHandle.
	positionOffset _ dragHandle center - (target point: target position in: owner)! !

!HaloMorph methodsFor: 'handles' stamp: 'jmv 12/5/2004 16:28'!
addDismissHandle: handleSpec
	"Add the dismiss handle according to the spec, unless selectiveHalos is on and my target resists dismissal"

	| dismissHandle |
		dismissHandle _ self addHandle: handleSpec
			on: #mouseDown send: #mouseDownInDimissHandle:with: to: self.
		dismissHandle on: #mouseUp send: #maybeDismiss:with: to: self.
		dismissHandle on: #mouseDown send: #setDismissColor:with: to: self.
		dismissHandle on: #mouseMove send: #setDismissColor:with: to: self! !

!HaloMorph methodsFor: 'handles' stamp: 'jmv 12/5/2004 16:28'!
addGrabHandle: haloSpec
	"If appropriate, add the black halo handle for picking up the target"

	self addHandle: haloSpec on: #mouseDown send: #doGrab:with: to: self

! !

!HaloMorph methodsFor: 'private' stamp: 'jmv 12/8/2004 12:29'!
doDrag: evt with: dragHandle
	| thePoint |
	evt hand obtainHalo: self.
	thePoint _ target point: evt position - positionOffset from: owner.
	target setConstrainedPosition: thePoint hangOut: true.
! !

!HaloMorph methodsFor: 'private' stamp: 'jmv 12/8/2004 12:29'!
doGrow: evt with: growHandle
	"Called while the mouse is down in the grow handle"

	| newExtent |
	evt hand obtainHalo: self.
	newExtent _ (target pointFromWorld: evt cursorPoint - positionOffset)
								- target topLeft.
	evt shiftPressed ifTrue: [newExtent _ (newExtent x max: newExtent y) asPoint].
	(newExtent x = 0 or: [newExtent y = 0]) ifTrue: [^ self].
	target renderedMorph setExtentFromHalo: newExtent.
	growHandle position: evt cursorPoint - (growHandle extent // 2).
	self layoutChanged
! !

!HaloMorph methodsFor: 'private' stamp: 'jmv 12/1/2004 12:30'!
doRecolor: evt with: aHandle
	"The mouse went down in the 'recolor' halo handle.  Allow the user to change the color of the innerTarget"

	evt hand obtainHalo: self.
	(aHandle containsPoint: evt cursorPoint)
		ifFalse:  "only do it if mouse still in handle on mouse up"
			[self delete.
			target addHalo: evt]
		ifTrue:
			[(Preferences propertySheetFromHalo == evt shiftPressed)
				ifFalse:	["innerTarget openAPropertySheet jmv"]
				ifTrue:	[innerTarget changeColor].
			self showingDirectionHandles ifTrue: [self addHandles]]! !

!HaloMorph methodsFor: 'private' stamp: 'jmv 12/2/2004 23:28'!
doRot: evt with: rotHandle
	"Update the rotation of my target if it is rotatable.  Keep the relevant command object up to date."

	| degrees |
	evt hand obtainHalo: self.
	degrees _ (evt cursorPoint - (target pointInWorld: target referencePosition)) degrees.
	degrees _ degrees - angleOffset degrees.
	degrees _ degrees detentBy: 10.0 atMultiplesOf: 90.0 snap: false.
	degrees = 0.0
		ifTrue: [rotHandle color: Color lightBlue]
		ifFalse: [rotHandle color: Color blue].
	rotHandle submorphsDo:
		[:m | m color: rotHandle color makeForegroundColor].
	self removeAllHandlesBut: rotHandle.
	self showingDirectionHandles ifFalse:
		[self showDirectionHandles: true addHandles: false].
	self addDirectionHandles.

	target rotationDegrees: degrees.

	rotHandle position: evt cursorPoint - (rotHandle extent // 2).
	self layoutChanged! !

!HaloMorph methodsFor: 'private' stamp: 'jmv 12/2/2004 23:26'!
endInteraction
	"Clean up after a user interaction with the a halo control"

	| m |
	self isMagicHalo: false.	"no longer"
	self magicAlpha: 1.0.
	(target isInWorld not or: [owner isNil]) ifTrue: [^self].
	[target isFlexMorph and: [target hasNoScaleOrRotation]] whileTrue: 
			[m := target firstSubmorph.
			target removeFlexShell.
			target := m].
	self isInWorld 
		ifTrue: 
			["make sure handles show in front, even if flex shell added"

			self comeToFront.
			self addHandles]! !

!HaloMorph methodsFor: 'private' stamp: 'jmv 12/6/2004 09:51'!
maybeDismiss: evt with: dismissHandle
	"Ask hand to dismiss my target if mouse comes up in it."

	evt hand obtainHalo: self.
	(dismissHandle containsPoint: evt cursorPoint)
		ifFalse:
			[self delete.
			target addHalo: evt]
		ifTrue:
			[target resistsRemoval ifTrue:
				[(PopUpMenu
					confirm: 'Really throw this away' translated
					trueChoice: 'Yes' translated
					falseChoice: 'Um, no, let me reconsider' translated) ifFalse: [^ self]].

			Preferences preserveTrash
				ifTrue:
					[
					self stopStepping.
					super delete.
					target slideToTrash: evt]
				ifFalse:
					[self delete.
					target dismissViaHalo]]! !

!HaloMorph methodsFor: 'private' stamp: 'jmv 12/6/2004 09:51'!
mouseDownInDimissHandle: evt with: dismissHandle
	evt hand obtainHalo: self.
	self removeAllHandlesBut: dismissHandle.
	dismissHandle color: Color darkGray.! !

!HaloMorph methodsFor: 'private' stamp: 'jmv 12/2/2004 23:29'!
startGrow: evt with: growHandle
	"Initialize resizing of my target.  Launch a command representing it, to support Undo"

	| botRt |
	self obtainHaloForEvent: evt andRemoveAllHandlesBut: growHandle.
	botRt _ target point: target bottomRight in: owner.
	positionOffset _ (self world viewBox containsPoint: botRt)
		ifTrue: [evt cursorPoint - botRt]
		ifFalse: [0@0]! !

!HaloMorph methodsFor: 'private' stamp: 'jmv 12/2/2004 23:29'!
startRot: evt with: rotHandle
	"Initialize rotation of my target if it is rotatable.  Launch a command object to represent the action"

	self obtainHaloForEvent: evt andRemoveAllHandlesBut: rotHandle.
	target isFlexMorph ifFalse: 
		[target isInWorld ifFalse: [self setTarget: target player costume].
		target addFlexShellIfNecessary].
	growingOrRotating _ true.

	self removeAllHandlesBut: rotHandle.  "remove all other handles"
	angleOffset _ evt cursorPoint - (target pointInWorld: target referencePosition).
	angleOffset _ Point
			r: angleOffset r
			degrees: angleOffset degrees - target rotationDegrees

! !


!MorphExtension methodsFor: 'copying' stamp: 'jmv 12/25/2004 14:41'!
copyWeakly
	"list of names of properties whose values should be weak-copied when veryDeepCopying a morph.  See DeepCopier."

	^ #()	"add yours to this list" !
]style[(10 101 10 36)f1b,f1,f1LDeepCopier Comment;,f1! !


!ComponentLikeModel methodsFor: 'naming' stamp: 'jmv 12/9/2004 20:15'!
choosePartName
	"When I am renamed, get a slot, make default methods, move any existing methods."

	| old |
	old := slotName.
	super choosePartName.
	slotName ifNil: [^self].	"user chose bad slot name"
	self model: self world model slotName: slotName.
	old isNil 
		ifTrue: [self compilePropagationMethods]
		ifFalse: [self copySlotMethodsFrom: old]
	"old ones not erased!!"! !

!ComponentLikeModel methodsFor: 'submorphs-add/remove' stamp: 'jmv 12/9/2004 20:15'!
delete
	"Delete the receiver.  Possibly put up confirming dialog.  Abort if user changes mind"

	(model isMorphicModel) ifFalse: [^super delete].
	slotName ifNotNil: 
			[(PopUpMenu confirm: 'Shall I remove the slot ' , slotName 
						, '
	along with all associated methods?') 
				ifTrue: 
					[(model class selectors select: [:s | s beginsWith: slotName]) 
						do: [:s | model class removeSelector: s].
					(model class instVarNames includes: slotName) 
						ifTrue: [model class removeInstVarName: slotName]]
				ifFalse: 
					[(PopUpMenu 
						confirm: '...but should I at least dismiss this morph?
	[choose no to leave everything unchanged]') 
							ifFalse: [^self]]].
	super delete! !


!DisplayScreen class methodsFor: 'display box access' stamp: 'jmv 12/2/2004 22:39'!
checkForNewScreenSize
	"Check whether the screen size has changed and if so take appropriate actions"

	Display extent = DisplayScreen actualScreenSize ifTrue: [^ self].
	DisplayScreen startUp.
	Smalltalk isMorphic
		ifTrue:
			[World restoreMorphicDisplay]
		ifFalse:
			[ScheduledControllers restore; searchForActiveController]! !


!Language class methodsFor: 'applying' stamp: 'jmv 12/6/2004 09:56'!
applyTranslations
	"private - try to apply the translations as much as possible all  
	over the image"
	Cursor wait
		showWhile: [
			ParagraphEditor initializeTextEditorMenus.
			MenuIcons initializeTranslations.]! !


!Morph class methodsFor: 'fileIn/Out' stamp: 'jmv 12/1/2004 17:43'!
fromFileName: fullName
	"Reconstitute a Morph from the file, presumed to be represent a Morph saved
	via the SmartRefStream mechanism, and open it in an appropriate Morphic world"

 	| aFileStream morphOrList |
	aFileStream _ FileStream readOnlyFileNamed: fullName.
	morphOrList _ aFileStream fileInObjectAndCode.
	Smalltalk isMorphic
		ifTrue: [ActiveWorld addMorphsAndModel: morphOrList]
		ifFalse:
			[morphOrList isMorph ifFalse: [self inform: 'Can only load a single morph
into an mvc project via this mechanism.'].
			morphOrList openInWorld]! !

!Morph class methodsFor: 'new-morph participation' stamp: 'jmv 12/9/2004 22:39'!
partName: aName categories: aList documentation: aDoc
	"Answer a DescriptionForPartsBin which will represent a launch of a new instance of my class via the #newStandAlone protocol sent to my class. Use the category-list and documentation provided"

	self halt: 'jmv What�s the purpose of this?'
"	^ DescriptionForPartsBin new
		formalName: aName
		categoryList: aList
		documentation: aDoc
		globalReceiverSymbol: self name
		nativitySelector: #newStandAlone"! !

!Morph class methodsFor: 'scripting' stamp: 'jmv 12/25/2004 14:14'!
helpContributions
	"Answer a list of pairs of the form (<symbol> <help message> ) to contribute to the system help dictionary"
	
"NB: Many of the items here are not needed any more since they're specified as part of command definitions now.  Someone needs to take the time to go through the list and remove items no longer needed.  But who's got that kind of time?"

	^ #(
		(beep:
			'make the specified sound')
		(borderColor
			'The color of the object''s border')
		(borderWidth
			'The width of the object''s border')
		(bottom
			'My bottom edge, measured downward from the top edge of the world')
		(color	
			'The object''s interior color')
		(copy
			'Return a new object that is very much like this one')
		(cursor	
			'The index of the chosen element')
		(dismiss
			'Click here to dismiss me')
		(heading
			'Which direction the object is facing.  0 is straight up') 
		(height	
			'The distance between the top and bottom edges of the object')
		(hide
			'Make the object so that it does not display and cannot handle input')
		(isOverColor
			'Whether any part of this object is directly over the specified color')
		(isUnderMouse
			'Whether any part of this object is beneath the current mouse-cursor position')
		(left
			'My left edge, measured from the left edge of the World')
		(leftRight
			'The horizontal displacement')
		(mouseX
			'The x coordinate of the mouse pointer')
		(mouseY
			'The y coordinate of the mouse pointer')
		(moveToward:
			'Move in the direction of another object.')
		(numberAtCursor
			'The number held by the object at the chosen element')
		(objectNameInHalo
			'Object''s name -- To change: click here, edit, hit ENTER')
		(obtrudes
			'Whether any part of the object sticks out beyond its container''s borders')
		(show
			'If object was hidden, make it show itself again.')
		(top
			'My top edge, measured downward from the top edge of the world')
		(right
			'My right edge, measured from the left edge of the world')
		(scaleFactor
			'The amount by which the object is scaled')
		(unhideHiddenObjects
			'Unhide all hidden objects.')
		(upDown
			'The vertical displacement')
		(width	
			'The distance between the left and right edges of the object')
		(x
			'The x coordinate, measured from the left of the container')
		(y
			'The y-coordinate, measured upward from the bottom of the container')

		)
! !


!EllipseMorph class methodsFor: 'parts bin' stamp: 'jmv 12/6/2004 20:58'!
descriptionForPartsBin
	^ self partName:	'Ellipse'
		categories:		#('Graphics' ' Basic 1 ')
		documentation:	'An elliptical or circular shape'! !


!ImageMorph class methodsFor: 'class initialization' stamp: 'jmv 12/1/2004 12:01'!
initialize
	"ImageMorph initialize"

	| h p d |
	DefaultForm _ (Form extent: 80@40 depth: 16).
	h _ DefaultForm height // 2.
	0 to: h - 1 do: [:i |
		p _ (i * 2)@i.
		d _ i asFloat / h asFloat.
		DefaultForm fill:
			(p corner: DefaultForm extent - p)
			fillColor: (Color r: d g: 0.5 b: 1.0 - d)]! !


!ObjectExplorer methodsFor: 'menus' stamp: 'jmv 12/1/2004 12:29'!
explorerKey: aChar from: view

	"Similar to #genericMenu:..."
	| insideObject parentObject |
	currentSelection ifNotNil: [
		insideObject _ self object.
		parentObject _ self parentObject.
		inspector ifNil: [inspector _ Inspector new].
		inspector
			inspect: parentObject;
			object: insideObject.

		aChar == $i ifTrue: [^ self inspectSelection].
		aChar == $I ifTrue: [^ self exploreSelection].

		aChar == $b ifTrue:	[^ inspector browseMethodFull].
		aChar == $h ifTrue:	[^ inspector classHierarchy].
		aChar == $c ifTrue: [^ inspector copyName].
		aChar == $p ifTrue: [^ inspector browseFullProtocol].
		aChar == $N ifTrue: [^ inspector browseClassRefs]].

	^ self arrowKey: aChar from: view! !


!ObjectWithDocumentation methodsFor: 'translation' stamp: 'jmv 12/1/2004 12:08'!
translatedToLanguage: languageSymbol 
	"Answer an ElementTranslation object in the prevailing natural  
	language, or, if none found, in English"
	| fallback elSym el wrd doc |
	elSym := self elementSymbol.
	^ naturalLanguageTranslations isEmptyOrNil
		ifTrue: [(el := self elementSymbol)
				ifNotNil: [((el beginsWith: 'get')
							and: [elSym size > 3])
						ifTrue: [wrd := (elSym copyFrom: 4 to: elSym size) withFirstCharacterDownshifted.
							doc := 'get value of ' , elSym]
						ifFalse: [((elSym beginsWith: 'set')
									and: [elSym size > 4])
								ifTrue: [wrd := (elSym copyFrom: 4 to: elSym size - 1) withFirstCharacterDownshifted.
									doc := 'set value of ' , elSym]
								ifFalse: ["wrd := ScriptingSystem wordingForOperator: elSym.
									doc := nil"]]].
			^ ElementTranslation new
				wording: wrd
				helpMessage: doc
				language: #English]
		ifFalse: [naturalLanguageTranslations
				do: [:aTranslation | 
					aTranslation language == languageSymbol
						ifTrue: [^ aTranslation].
					aTranslation language == #English
						ifTrue: [fallback := aTranslation]].
			fallback
				ifNil: [ElementCategory new categoryName: elSym]]! !


!PaintInvokingMorph methodsFor: 'dropping/grabbing' stamp: 'jmv 12/8/2004 09:45'!
justDroppedInto: aPasteUpMorph event: anEvent
	"This message is sent to a dropped morph after it has been dropped on--and been accepted by--a drop-sensitive morph"
		self delete.
		^aPasteUpMorph makeNewDrawing: anEvent! !

!PaintInvokingMorph methodsFor: 'dropping/grabbing' stamp: 'jmv 12/5/2004 16:53'!
wantsToBeDroppedInto: aMorph
	"Only into PasteUps that are not part bins"
	^false! !


!ParagraphEditor class methodsFor: 'class initialization' stamp: 'jmv 12/2/2004 23:15'!
shiftedYellowButtonMenu
	"Answer the menu to be presented when the yellow button is pressed while the shift key is down"

	^ SelectionMenu fromArray: {
		{'set font... (k)' translated.					#offerFontMenu}.
		{'set style... (K)' translated.					#changeStyle}.
		{'set alignment...' translated.				#chooseAlignment}.
		#-.
		{'explain' translated.						#explain}.
		{'pretty print' translated.					#prettyPrint}.
		{'pretty print with color' translated.			#prettyPrintWithColor}.
		{'file it in (G)' translated.					#fileItIn}.
		{'spawn (o)' translated.						#spawn}.
		#-.
		{'browse it (b)' translated.					#browseIt}.
		{'senders of it (n)' translated.				#sendersOfIt}.
		{'implementors of it (m)' translated.		#implementorsOfIt}.
		{'references to it (N)' translated.			#referencesToIt}.
		#-.
		{'selectors containing it (W)' translated.	#methodNamesContainingIt}.
		{'method strings with it (E)' translated.	#methodStringsContainingit}.
		{'method source with it' translated.		#methodSourceContainingIt}.
		{'class names containing it' translated.	#classNamesContainingIt}.
		{'class comments with it' translated.		#classCommentsContainingIt}.
		{'change sets with it' translated.			#browseChangeSetsWithSelector}.
		#-.
		{'save contents to file...' translated.		#saveContentsInFile}.
		{'send contents to printer' translated.		#sendContentsToPrinter}.
		{'printer setup' translated.					#printerSetup}.
		#-.
		{'special menu...' translated.				#presentSpecialMenu}.
		{'more...' translated.							#yellowButtonActivity}.
	}
! !


!Parser methodsFor: 'public access' stamp: 'jmv 12/6/2004 20:44'!
parse: sourceStream class: class noPattern: noPattern context: ctxt notifying: req ifFail: aBlock 
        "Answer a MethodNode for the argument, sourceStream, that is the root of 
        a parse tree. Parsing is done with respect to the argument, class, to find 
        instance, class, and pool variables; and with respect to the argument, 
        ctxt, to find temporary variables. Errors in parsing are reported to the 
        argument, req, if not nil; otherwise aBlock is evaluated. The argument 
        noPattern is a Boolean that is true if the the sourceStream does not 
        contain a method header (i.e., for DoIts)."

         | methNode repeatNeeded myStream parser s p |
        (req notNil and: [RequestAlternateSyntaxSetting signal and: [(sourceStream isKindOf: FileStream) not]])
                ifTrue: [parser _ self as: DialectParser]
                ifFalse: [parser _ self].
        myStream _ sourceStream.
        [repeatNeeded _ false.
	   p _ myStream position.
	   s _ myStream upToEnd.
	   myStream position: p.
        parser init: myStream notifying: req failBlock: [^ aBlock value].
        doitFlag _ noPattern.
        failBlock_ aBlock.
        [methNode _ parser method: noPattern context: ctxt
                                encoder: (Encoder new init: class context: ctxt notifying: parser)] 
                on: ParserRemovedUnusedTemps 
                do: 
                        [ :ex | repeatNeeded _ (requestor isKindOf: TextMorphEditor) not.
                        myStream _ ReadStream on: requestor text string.
                        ex resume].
        repeatNeeded] whileTrue.
        encoder _ failBlock _ requestor _ parseNode _ nil. "break cycles & mitigate refct overflow"
	   methNode sourceText: s.
        ^ methNode! !

!Parser methodsFor: 'error correction' stamp: 'jmv 12/6/2004 20:44'!
removeUnusedTemps
	"Scan for unused temp names, and prompt the user about the prospect of removing each one found"

	| str end start madeChanges | 
	madeChanges _ false.
	str _ requestor text string.
	((tempsMark between: 1 and: str size)
		and: [(str at: tempsMark) = $|]) ifFalse: [^ self].
	encoder unusedTempNames do:
		[:temp |
		((PopUpMenu labels: 'yes\no' withCRs) startUpWithCaption:
			((temp , ' appears to be
unused in this method.
OK to remove it?') asText makeBoldFrom: 1 to: temp size))
			= 1
		ifTrue:
		[(encoder encodeVariable: temp) isUndefTemp
			ifTrue:
			[end _ tempsMark.
			["Beginning at right temp marker..."
			start _ end - temp size + 1.
			end < temp size or: [temp = (str copyFrom: start to: end)
					and: [(str at: start-1) isSeparator & (str at: end+1) isSeparator]]]
			whileFalse:
				["Search left for the unused temp"
				end _ requestor nextTokenFrom: end direction: -1].
			end < temp size ifFalse:
				[(str at: start-1) = $  ifTrue: [start _ start-1].
				requestor correctFrom: start to: end with: ''.
				str _ str copyReplaceFrom: start to: end with: ''. 
				madeChanges _ true.
				tempsMark _ tempsMark - (end-start+1)]]
			ifFalse:
			[self inform:
'You''ll first have to remove the
statement where it''s stored into']]].
	madeChanges ifTrue: [ParserRemovedUnusedTemps signal]! !


!PasteUpMorph methodsFor: 'caching' stamp: 'jmv 12/2/2004 22:57'!
releaseCachedState
	super releaseCachedState.
	self isWorldMorph ifTrue:[self cleanseStepList].! !

!PasteUpMorph methodsFor: 'cursor' stamp: 'jmv 12/8/2004 12:20'!
cursorWrapped: aNumber 
	"Set the cursor to the given number, modulo the number of items I contain. Fractional cursor values are allowed."

	| truncP |
	cursor ~= aNumber 
		ifTrue: 
			[
			cursor := self asNumber: aNumber.
			truncP := cursor truncated.
			truncP > submorphs size 
				ifTrue: [cursor := submorphs notEmpty ifTrue: [cursor \\ submorphs size] ifFalse: [1]].
			truncP < 0 ifTrue: [cursor := 1]]! !

!PasteUpMorph methodsFor: 'drawing' stamp: 'jmv 12/8/2004 12:27'!
drawOn: aCanvas 
	"Draw in order:
	- background color
	- grid, if any
	- background sketch, if any
	- Update and draw the turtleTrails form. See the comment in updateTrailsForm.
	- cursor box if any

	Later (in drawSubmorphsOn:) I will skip drawing the background sketch."

	"draw background fill"
	super drawOn: aCanvas.

	"draw background sketch."
	backgroundMorph ifNotNil: [
		self clipSubmorphs ifTrue: [
			aCanvas clipBy: self clippingBounds
				during: [ :canvas | canvas fullDrawMorph: backgroundMorph ]]
			ifFalse: [ aCanvas fullDrawMorph: backgroundMorph ]]! !

!PasteUpMorph methodsFor: 'dropping/grabbing' stamp: 'jmv 12/8/2004 12:16'!
acceptDroppingMorph: dropped event: evt
	"The supplied morph, known to be acceptable to the receiver, is now to be assimilated; the precipitating event is supplied"

	| aMorph |
	aMorph _ self morphToDropFrom: dropped.
	self isWorldMorph
		ifTrue:["Add the given morph to this world and start stepping it if it wants to be."
				self addMorphFront: aMorph.
				(aMorph fullBounds intersects: self viewBox) ifFalse:
					[Beeper beep.  aMorph position: self bounds center]]
		ifFalse:[super acceptDroppingMorph: aMorph event: evt].

	aMorph submorphsDo: [:m | (m isKindOf: HaloMorph) ifTrue: [m delete]].

	self world startSteppingSubmorphsOf: aMorph! !

!PasteUpMorph methodsFor: 'dropping/grabbing' stamp: 'jmv 12/19/2004 09:18'!
morphToDropFrom: aMorph 
	"Given a morph being carried by the hand, which the hand is about to drop, answer the actual morph to be deposited.  Normally this would be just the morph itself, but several unusual cases arise, which this method is designed to service."

	^aMorph! !

!PasteUpMorph methodsFor: 'event handling' stamp: 'jmv 12/5/2004 16:14'!
keyStroke: anEvent
	"A keystroke has been made.  Service event handlers and, if it's a keystroke presented to the world, dispatch it to #unfocusedKeystroke:"

	super keyStroke: anEvent.  "Give event handlers a chance"
"	(anEvent keyCharacter == Character tab) ifTrue:
		[(self hasProperty: #tabAmongFields)
			ifTrue:[^ self tabHitWithEvent: anEvent]]."
	self isWorldMorph ifTrue:
		[self keystrokeInWorld: anEvent]! !

!PasteUpMorph methodsFor: 'event handling' stamp: 'jmv 12/8/2004 09:46'!
mouseDown: evt
	"Handle a mouse down event."
	| grabbedMorph handHadHalos |
	grabbedMorph _ self morphToGrab: evt.
	grabbedMorph ifNotNil:[
		grabbedMorph isSticky ifTrue:[^self].
		^evt hand grabMorph: grabbedMorph].

	(super handlesMouseDown: evt)
		ifTrue:[^super mouseDown: evt].
	handHadHalos _ evt hand halo notNil.
	evt hand halo: nil. "shake off halos"
	evt hand releaseKeyboardFocus. "shake of keyboard foci"
	evt shiftPressed ifTrue:[
		^evt hand 
			waitForClicksOrDrag: self 
			event: evt 
			selectors: { #findWindow:. nil. nil. #dragThroughOnDesktop:}
			threshold: 5].
	self isWorldMorph ifTrue: [
		handHadHalos ifTrue: [^self addAlarm: #invokeWorldMenu: with: evt after: 200].
		^self invokeWorldMenu: evt
	].
	"otherwise, explicitly ignore the event if we're not the world,
	so that we could be picked up if need be"
	self isWorldMorph ifFalse:[evt wasHandled: false].
! !

!PasteUpMorph methodsFor: 'event handling' stamp: 'jmv 12/8/2004 09:42'!
wantsKeyboardFocusFor: aSubmorph
	aSubmorph wouldAcceptKeyboardFocus ifTrue: [ ^ true].
	^ super wantsKeyboardFocusFor: aSubmorph! !

!PasteUpMorph methodsFor: 'initialization' stamp: 'jmv 12/28/2004 23:13'!
initialize
"initialize the state of the receiver"
	super initialize.
""
	cursor _ 1.
	self enableDragNDrop.
	self clipSubmorphs: true! !

!PasteUpMorph methodsFor: 'menu & halo' stamp: 'jmv 12/8/2004 09:32'!
addCustomMenuItems: menu hand: aHandMorph
	"Add morph-specific menu itemns to the menu for the hand"

	super addCustomMenuItems: menu hand: aHandMorph.

	self isWorldMorph ifTrue:
		[(owner isKindOf: BOBTransformationMorph) ifTrue:
			[self addScalingMenuItems: menu hand: aHandMorph].
		menu add: 'desktop menu...' translated target: self action: #putUpDesktopMenu:].

	menu addLine! !

!PasteUpMorph methodsFor: 'menu & halo' stamp: 'jmv 12/1/2004 12:12'!
addWorldHaloMenuItemsTo: aMenu hand: aHandMorph
	"Add standard halo items to the menu, given that the receiver is a World"

	| unlockables |
	self addFillStyleMenuItems: aMenu hand: aHandMorph.
	self addLayoutMenuItems: aMenu hand: aHandMorph.

	aMenu addLine.
	self addWorldToggleItemsToHaloMenu: aMenu.
	aMenu addLine.
	self addCopyItemsTo: aMenu.
	self addExportMenuItems: aMenu hand: aHandMorph.
	self addMiscExtrasTo: aMenu.

	Preferences noviceMode ifFalse:
		[self addDebuggingItemsTo: aMenu hand: aHandMorph].

	aMenu addLine.
	aMenu defaultTarget: self.

	aMenu addLine.

	unlockables _ self submorphs select:
		[:m | m isLocked].
	unlockables size == 1 ifTrue:
		[aMenu add: ('unlock "{1}"' translated format:{unlockables first externalName})action: #unlockContents].
	unlockables size > 1 ifTrue:
		[aMenu add: 'unlock all contents' translated action: #unlockContents.
		aMenu add: 'unlock...' translated action: #unlockOneSubpart].

	aMenu defaultTarget: aHandMorph.
! !

!PasteUpMorph methodsFor: 'misc' stamp: 'jmv 12/28/2004 23:08'!
cartesianOrigin
	^ self bottomLeft! !

!PasteUpMorph methodsFor: 'misc' stamp: 'jmv 12/8/2004 12:14'!
prepareToBeSaved
	"Prepare for export via the ReferenceStream mechanism"

	| exportDict soundKeyList |
	super prepareToBeSaved.
	self isWorldMorph
		ifTrue: [soundKeyList _ Set new.
			soundKeyList removeAllFoundIn: SampledSound universalSoundKeys.
			soundKeyList
				removeAllSuchThat: [:aKey | (SampledSound soundLibrary includesKey: aKey) not].
			soundKeyList isEmpty
				ifFalse: [exportDict _ Dictionary new.
					soundKeyList
						do: [:aKey | exportDict
								add: (SampledSound soundLibrary associationAt: aKey)].
					self setProperty: #soundAdditions toValue: exportDict]]! !

!PasteUpMorph methodsFor: 'painting' stamp: 'jmv 12/1/2004 12:05'!
prepareToPaint: stopRunningScripts
	"We're about to start painting. Do a few preparations that make the system more responsive."
	self abandonAllHalos. "no more halos"! !

!PasteUpMorph methodsFor: 'world menu' stamp: 'jmv 12/19/2004 09:26'!
defaultDesktopCommandKeyTriplets
	"Answer a list of triplets of the form
		<key> <receiver> <selector>   [+ optional fourth element, a <description> for use in desktop-command-key-help]
that will provide the default desktop command key handlers.  If the selector takes an argument, that argument will be the command-key event"

	^ {
		{ $b.	Browser.						#openBrowser.							'Open a new System Browser'}.
		{ $k.	Workspace.						#open.									'Open a new, blank Workspace'}.
		{ $m.	self.							#putUpNewMorphMenu.					'Put up the "New Morph" menu'}.
		{ $r.	ActiveWorld.					#restoreMorphicDisplay.					'Redraw the screen'}.		
		{ $t.		self. 							#findATranscript:.						'Make a System Transcript visible'}.
		{ $w.	SystemWindow.					#closeTopWindow.						'Close the topmost window'}.

		{ $C.	self.							#findAChangeSorter:.					'Make a Change Sorter visible'}.

		{ $L.	self.							#findAFileList:.							'Make a File List visible'}.
		{ $R.	self. 							#openRecentSubmissionsBrowser:	.		'Make a Recent Submissions browser visible'}.

		{ $W.	self. 							#findAMessageNamesWindow:.			'Make a MessageNames tool visible'}.
		{ $Z.	ChangeList. 						#browseRecentLog.						'Browse recently-logged changes'}.

		{ $\.	SystemWindow. 					#sendTopWindowToBack.					'Send the top window to the back'}.}! !

!PasteUpMorph methodsFor: 'world menu' stamp: 'jmv 12/5/2004 16:58'!
findWindow: evt
	"Present a menu names of windows and naked morphs, and activate the one that gets chosen.  Collapsed windows appear below line, expand if chosen; naked morphs appear below second line; if any of them has been given an explicit name, that is what's shown, else the class-name of the morph shows; if a naked morph is chosen, bring it to front and have it don a halo."
	| menu expanded collapsed nakedMorphs |
	menu _ MenuMorph new.
	expanded _ SystemWindow windowsIn: self satisfying: [:w | w isCollapsed not].
	collapsed _ SystemWindow windowsIn: self satisfying: [:w | w isCollapsed].
	nakedMorphs _ self submorphsSatisfying:
		[:m | (m isSystemWindow not )].
	(expanded isEmpty & (collapsed isEmpty & nakedMorphs isEmpty)) ifTrue: [^ Beeper beep].
	(expanded asSortedCollection: [:w1 :w2 | w1 label caseInsensitiveLessOrEqual: w2 label]) do:
		[:w | menu add: w label target: w action: #activateAndForceLabelToShow.
			w model canDiscardEdits ifFalse: [menu lastItem color: Color red]].
	(expanded isEmpty | (collapsed isEmpty & nakedMorphs isEmpty)) ifFalse: [menu addLine].
	(collapsed asSortedCollection: [:w1 :w2 | w1 label caseInsensitiveLessOrEqual: w2 label]) do: 
		[:w | menu add: w label target: w action: #collapseOrExpand.
		w model canDiscardEdits ifFalse: [menu lastItem color: Color red]].
	nakedMorphs isEmpty ifFalse: [menu addLine].
	(nakedMorphs asSortedCollection: [:w1 :w2 | w1 nameForFindWindowFeature caseInsensitiveLessOrEqual: w2 nameForFindWindowFeature]) do:
		[:w | menu add: w nameForFindWindowFeature target: w action: #comeToFrontAndAddHalo].
	menu addTitle: 'find window' translated.
	
	menu popUpEvent: evt in: self.! !

!PasteUpMorph methodsFor: 'world menu' stamp: 'jmv 12/24/2004 14:54'!
invokeWorldMenu: evt
	"Put up the world menu, triggered by the passed-in event.
	Perhaps a good place to disable it if needed"

	self putUpWorldMenu: evt! !

!PasteUpMorph methodsFor: 'world menu' stamp: 'jmv 12/24/2004 14:54'!
keystrokeInWorld: evt
	"A keystroke was hit when no keyboard focus was in set, so it is sent here to the world instead."

	|  aChar isCmd ascii |
	aChar _ evt keyCharacter.
	(ascii _ aChar asciiValue) = 27 ifTrue: "escape key"
		[^ self putUpWorldMenuFromEscapeKey].
	(#(1 4 8 28 29 30 31 32) includes: ascii) ifTrue:  "home, end, backspace, arrow keys, space"
		[self keyboardNavigationHandler ifNotNilDo:
			[:aHandler | ^ aHandler navigateFromKeystroke: aChar]].

	isCmd _ evt commandKeyPressed and: [Preferences cmdKeysInText].
	(isCmd and: [Preferences honorDesktopCmdKeys]) ifTrue:
		[self dispatchCommandKeyInWorld: aChar event: evt]! !

!PasteUpMorph methodsFor: 'world menu' stamp: 'jmv 12/5/2004 17:00'!
makeNewDrawing: evt at: aPoint
	"make a new drawing, triggered by the given event, with the painting area centered around the given point"

	| w newSketch sketchEditor aPaintBox tfx rect ownerBeforeHack aWorld |
	w _ self world.
	w assureNotPaintingElse: [^ self].
	rect _ self paintingBoundsAround: aPoint.
	w prepareToPaint.

	newSketch _ self drawingClass new.
	newSketch nominalForm: (Form extent: rect extent depth: w assuredCanvas depth).
	newSketch bounds: rect.
	sketchEditor _ SketchEditorMorph new.
	w addMorphFront: sketchEditor.
	sketchEditor initializeFor: newSketch inBounds: rect pasteUpMorph: self.
	sketchEditor
		afterNewPicDo: [:aForm :aRect |
			newSketch form: aForm.
			tfx _ self transformFrom: w.
			newSketch position: (tfx globalPointToLocal: aRect origin).
			newSketch rotationStyle: sketchEditor rotationStyle.
			newSketch forwardDirection: sketchEditor forwardDirection.

			ownerBeforeHack _ newSketch owner.	"about to break the invariant!!!!"
			newSketch privateOwner: self. "temp for halo access"
			aWorld _ self world.
			(aPaintBox _ aWorld paintBox) ifNotNil:[aPaintBox delete].

			"Includes  newSketch rotationDegrees: sketchEditor forwardDirection."
			newSketch privateOwner: ownerBeforeHack. "probably nil, but let's be certain"

			self addMorphFront: newSketch.
			w startSteppingSubmorphsOf: newSketch]
		 ifNoBits:[
			aWorld _ self world.
			(aPaintBox _ aWorld paintBox) ifNotNil:[aPaintBox delete].
			]! !

!PasteUpMorph methodsFor: 'world menu' stamp: 'jmv 12/5/2004 16:50'!
putUpWorldMenu: evt
	"Put up a menu in response to a click on the desktop, triggered by evt."

	| menu |
	evt isMouse ifTrue:
		[evt yellowButtonPressed
			ifTrue: [^ self yellowButtonClickOnDesktopWithEvent: evt].
		evt shiftPressed ifTrue:[^ self findWindow: evt]].
	"put up screen menu"
	menu _ self buildWorldMenu: evt.
	menu addTitle: Preferences desktopMenuTitle translated.
	menu popUpEvent: evt in: self.
	^ menu! !

!PasteUpMorph methodsFor: 'world state' stamp: 'jmv 12/5/2004 16:51'!
allNonFlapRelatedSubmorphs
	"Answer all non-window submorphs that are not flap-related"

	^submorphs 
		select: [:m | (m isSystemWindow) not ]! !

!PasteUpMorph methodsFor: 'world state' stamp: 'jmv 12/28/2004 23:13'!
beWorldForProject: aProject

	self privateOwner: nil.
	worldState _ WorldState new.
	self addHand: HandMorph new.
	self setProperty: #optimumExtentFromAuthor toValue: Display extent.
	self startSteppingSubmorphsOf: self! !

!PasteUpMorph methodsFor: 'world state' stamp: 'jmv 12/1/2004 13:14'!
embeddedProjectDisplayMode

	"#naked - the embedded project/world is just a pasteup in the outer p/w
	#window - the embedded p/w is in a system window in the outer p/w
	#frame - the embedded p/w is in a green frame and clipped REMOVED jmv
	#scaled - the embedded p/w is in a green frame and scaled to fit"

	^#scaled
! !

!PasteUpMorph methodsFor: 'world state' stamp: 'jmv 12/28/2004 23:13'!
initForProject: aWorldState

	worldState _ aWorldState.
	bounds _ Display boundingBox.
	color _ (Color r:0.937 g: 0.937 b: 0.937).
	self addHand: HandMorph new.
	self setProperty: #optimumExtentFromAuthor toValue: Display extent.
	self borderWidth: 0.
	model _ nil.
! !

!PasteUpMorph methodsFor: 'world state' stamp: 'jmv 12/2/2004 23:07'!
install
	owner := nil.	"since we may have been inside another world previously"
	ActiveWorld := self.
	ActiveHand := self hands first.	"default"
	ActiveEvent := nil.
	submorphs do: [:ss | ss owner isNil ifTrue: [ss privateOwner: self]].
	"Transcript that was in outPointers and then got deleted."
	self viewBox: Display boundingBox.
	Sensor flushAllButDandDEvents.
	worldState handsDo: [:h | h initForEvents].
	self borderWidth: 0.	"default"
	(Preferences showSecurityStatus 
		and: [SecurityManager default isInRestrictedMode]) 
			ifTrue: 
				[self
					borderWidth: 2;
					borderColor: Color red].
	SystemWindow noteTopWindowIn: self.
	self displayWorldSafely! !

!PasteUpMorph methodsFor: 'world state' stamp: 'jmv 12/1/2004 13:13'!
installAsActiveSubprojectIn: enclosingWorld at: newBounds titled: aString 
	| window howToOpen tm boundsForWorld |
	howToOpen := self embeddedProjectDisplayMode.
	"#scaled may be the only one that works at the moment"
	submorphs do: [:ss | ss owner isNil ifTrue: [ss privateOwner: self]].
	"Transcript that was in outPointers and then got deleted."
	boundsForWorld := howToOpen == #naked ifTrue: [newBounds] ifFalse: [bounds].
	worldState canvas: nil.
	worldState viewBox: boundsForWorld.
	self bounds: boundsForWorld.

	"self viewBox: Display boundingBox."
	"worldState handsDo: [:h | h initForEvents]."

	"SystemWindow noteTopWindowIn: self."
	"self displayWorldSafely."
	howToOpen == #naked ifTrue: [enclosingWorld addMorphFront: self].
	howToOpen == #window 
		ifTrue: 
			[window := (NewWorldWindow labelled: aString) model: self.
			window addMorph: self frame: (0 @ 0 extent: 1.0 @ 1.0).
			window openInWorld: enclosingWorld].
	howToOpen == #scaled 
		ifTrue: 
			[self position: 0 @ 0.
			window := (EmbeddedWorldBorderMorph new)
						minWidth: 100;
						minHeight: 100;
						borderWidth: 8;
						borderColor: Color green;
						bounds: newBounds.
			tm := BOBTransformationMorph new.
			window addMorph: tm.
			tm addMorph: self.
			window openInWorld: enclosingWorld.
			tm changeWorldBoundsToShow: bounds.
			self arrangeToStartSteppingIn: enclosingWorld
			"tm scale: (tm width / self width min: tm height / self height) asFloat."]! !

!PasteUpMorph methodsFor: 'world state' stamp: 'jmv 12/20/2004 22:27'!
open
	"Open a view on this WorldMorph."
	self halt.
"	MorphWorldView openOn: self."! !

!PasteUpMorph methodsFor: 'world state' stamp: 'jmv 12/2/2004 23:02'!
paintBox
	"Return the painting controls widget (PaintBoxMorph) to be used for painting in this world. If there is not already a PaintBox morph, or if it has been deleted from this world, create a new one."

	| newPaintBox refPoint |
	self allMorphsDo: [:m | (m isKindOf: PaintBoxMorph) ifTrue: [^ m]].
	refPoint _ self topRight.
	newPaintBox _ PaintBoxMorph new.
	newPaintBox position: (refPoint - (newPaintBox width @ 0)). 
	self addMorph: newPaintBox.
	^ newPaintBox
! !

!PasteUpMorph methodsFor: 'world state' stamp: 'jmv 12/1/2004 13:11'!
restoreMorphicDisplay

	DisplayScreen startUp.
	self
		extent: Display extent;
		viewBox: Display boundingBox;
		handsDo: [:h | h visible: true; showTemporaryCursor: nil];
		fullRepaintNeeded.
	WorldState addDeferredUIMessage: [
		Cursor normal show.
	].
! !


!PasteUpMorph class methodsFor: 'project' stamp: 'jmv 12/6/2004 09:10'!
newWorldTesting

	| world ex |

	ex _ 500@500.
	world _ PasteUpMorph newWorldForProject: nil.
	world extent: ex; color: Color orange.
	world openInWorld.
	world viewBox: (0@0 extent: ex).
	EllipseMorph new openInWorld: world.

"-----

	| world window |
	world _ PasteUpMorph newWorldForProject: nil.
	world extent: 300@300; color: Color orange.
	world viewBox: (0@0 extent: 300@300).
	window _ (SystemWindow labelled: 'the new world') model: world.
	window color: Color orange.
	window addMorph: world frame: (0@0 extent: 1.0@1.0).
	window openInWorld.

---"
! !


!PianoRollScoreMorph methodsFor: 'menu' stamp: 'jmv 12/6/2004 20:27'!
addCustomMenuItems: aMenu hand: aHandMorph

	super addCustomMenuItems: aMenu hand: aHandMorph.
	aMenu add: 'expand time' translated action: #expandTime.
	aMenu add: 'contract time' translated action: #contractTime.
	aMenu addLine.
	(self valueOfProperty: #dragNDropEnabled) == true
		ifTrue: [aMenu add: 'close drag and drop' translated action: #disableDragNDrop]
		ifFalse: [aMenu add: 'open drag and drop' translated action: #enableDragNDrop].
! !


!PolygonMorph methodsFor: 'editing' stamp: 'jmv 12/8/2004 12:30'!
dragVertex: ix event: evt fromHandle: handle
	| p |
	p _ evt cursorPoint.
	handle position: p - (handle extent//2).
	self verticesAt: ix put: p.
! !


!CurveMorph class methodsFor: 'parts bin' stamp: 'jmv 12/6/2004 20:58'!
descriptionForPartsBin
	^ self partName:	'Curve'
		categories:		#('Graphics' ' Basic 1 ')
		documentation:	'A smooth wiggly curve, or a curved solid.  Shift-click to get handles and move the points.'! !


!Preference methodsFor: 'local to project' stamp: 'jmv 12/19/2004 09:28'!
toggleProjectLocalness
	"Toggle whether the preference should be held project-by-project or globally"

	localToProject _ localToProject not
! !


!Preferences class methodsFor: 'fonts' stamp: 'jmv 12/24/2004 15:02'!
fontConfigurationMenu
	| aMenu |
	aMenu := MenuMorph new defaultTarget: Preferences.
	aMenu addTitle: 'Standard System Fonts' translated.
	
	aMenu addStayUpIcons.
	
	aMenu add: 'default text font...' translated action: #chooseSystemFont.
	aMenu balloonTextForLastItem: 'Choose the default font to be used for code and  in workspaces, transcripts, etc.' translated.
	aMenu lastItem font: Preferences standardDefaultTextFont.
	
	aMenu add: 'list font...' translated action: #chooseListFont.
	aMenu lastItem font: Preferences standardListFont.
	aMenu balloonTextForLastItem: 'Choose the font to be used in list panes' translated.

	aMenu add: 'menu font...' translated action: #chooseMenuFont.
	aMenu lastItem font: Preferences standardMenuFont.
	aMenu balloonTextForLastItem: 'Choose the font to be used in menus' translated.
	
	aMenu add: 'window-title font...' translated action: #chooseWindowTitleFont.
	aMenu lastItem font: Preferences windowTitleFont emphasis: 1.
	aMenu balloonTextForLastItem: 'Choose the font to be used in window titles.' translated.

	aMenu add: 'balloon-help font...' translated action: #chooseBalloonHelpFont.
	aMenu lastItem font: Preferences standardBalloonHelpFont.
	aMenu balloonTextForLastItem: 'choose the font to be used when presenting balloon help.' translated.
	
	aMenu add: 'code font...' translated action: #chooseCodeFont. 
	aMenu lastItem font: Preferences standardCodeFont. 
	aMenu balloonTextForLastItem: 'Choose the font to be used in code panes.' translated.
	
	aMenu addLine.
	aMenu add: 'restore default font choices' translated action: #restoreDefaultFonts.
	aMenu balloonTextForLastItem: 'Use the standard system font defaults' translated.
	
	aMenu add: 'print default font choices' translated action: #printStandardSystemFonts.
	aMenu balloonTextForLastItem: 'Print the standard system font defaults to the Transcript' translated.

	^ aMenu! !

!Preferences class methodsFor: 'fonts' stamp: 'jmv 12/24/2004 15:02'!
presentMvcFontConfigurationMenu
	| aMenu result |
	aMenu _ CustomMenu new.
	aMenu title: 'Standard System Fonts'.
	aMenu add: 'default text font...' action: #chooseSystemFont.
	aMenu add: 'list font...' action: #chooseListFont.
	aMenu add: 'menu font...' action: #chooseMenuFont.
	aMenu add: 'window-title font...' action: #chooseWindowTitleFont.
	"aMenu add: 'code font...' action: #chooseCodeFont."
	aMenu addLine.
	aMenu add: 'restore default font choices' action: #restoreDefaultFonts.

	(result _ aMenu startUp) ifNotNil:
		[self perform: result]
! !

!Preferences class methodsFor: 'fonts' stamp: 'jmv 12/24/2004 14:59'!
printStandardSystemFonts
	"self printStandardSystemFonts"

	#(standardDefaultTextFont standardListFont 
	standardMenuFont windowTitleFont 
	standardBalloonHelpFont standardCodeFont standardButtonFont) do: [:selector |
		| font |
		font _ Preferences perform: selector.
		Transcript
			cr; show: selector;
			space; show: font familyName;
			show: ' points: ';
			show: font pointSize printString;
			show: ' height: ';
			show: font height printString]! !

!Preferences class methodsFor: 'fonts' stamp: 'jmv 12/24/2004 14:58'!
refreshFontSettings
	"Try to update all the current font settings to make things consistent."

	self
		setWindowTitleFontTo: (self windowTitleFont);
		setListFontTo: (self standardListFont);
		setMenuFontTo: (self standardMenuFont);
		setSystemFontTo: (TextStyle defaultFont);
		setCodeFontTo: (self standardCodeFont);
		setBalloonHelpFontTo: (BalloonMorph balloonFont).

	SystemWindow allSubInstancesDo: [ :s | | rawLabel |
		rawLabel := s getRawLabel.
		rawLabel owner vResizing: #spaceFill.
		rawLabel font: rawLabel font.
		s setLabel: s label.
		s replaceBoxes ].! !

!Preferences class methodsFor: 'fonts' stamp: 'jmv 12/24/2004 14:59'!
restoreDefaultFonts
	"Since this is called from menus, we can take the opportunity to prompt for missing font styles."
	"Preferences restoreDefaultFonts"

	self setDefaultFonts: #(
		(setSystemFontTo:		Accuny				10)
		(setListFontTo:			Accuny				10)
		(setMenuFontTo:			Accuny				10)
		(setWindowTitleFontTo:	BitstreamVeraSans	11)
		(setBalloonHelpFontTo:	Accujen				9)
		(setCodeFontTo:			Accuny				10)
		(setButtonFontTo:		Accujen				12)
	)! !

!Preferences class methodsFor: 'fonts' stamp: 'jmv 12/1/2004 13:26'!
setCodeFontTo: aFont
	"Not currently sent, but once protocols are sorted out so that we can discriminate on whether a text object being launched is for code or not, might deserve to be reincorporated"

	Parameters at: #standardCodeFont put: aFont! !

!Preferences class methodsFor: 'fonts' stamp: 'jmv 12/2/2004 22:31'!
setFlapsFontTo: aFont
	self toBeDeletedJMV! !

!Preferences class methodsFor: 'fonts' stamp: 'jmv 12/1/2004 13:27'!
setListFontTo: aFont
	"Set the list font as indicated"

	Parameters at: #standardListFont put: aFont.
	ListParagraph initialize! !

!Preferences class methodsFor: 'fonts' stamp: 'jmv 12/31/2004 15:53'!
setSystemFontTo: aFont
	"Establish the default text font and style"

	| aStyle newDefaultStyle |
	aFont ifNil: [^ self].
	aStyle _ aFont textStyle ifNil: [^ self].
	newDefaultStyle _ aStyle copy.
	newDefaultStyle defaultFontIndex: (aStyle fontIndexOf: aFont).
	TextConstants at: #DefaultTextStyle put: newDefaultStyle! !

!Preferences class methodsFor: 'fonts' stamp: 'jmv 12/1/2004 13:27'!
setWindowTitleFontTo: aFont
	"Set the window-title font to be as indicated"

	Parameters at: #windowTitleFont put: aFont.
	StandardSystemView setLabelStyle! !

!Preferences class methodsFor: 'halos' stamp: 'jmv 12/20/2004 21:28'!
classicHaloSpecs
	"Non-iconic halos with traditional placements"

	"Preferences installClassicHaloSpecs"
	"Preferences resetHaloSpecifications"  "  <-  will result in the standard default halos being reinstalled"
	"NB: listed below in clockwise order"

		^ #(
	"  	selector				horiz		vert			color info						icon key
		---------				------		-----------		-------------------------------		---------------"
	(addMenuHandle:		left			top				(red)							none)
	(addDismissHandle:		leftCenter	top				(red		muchLighter)			'Halo-Dismiss')
	(addGrabHandle:			center		top				(black)							none)
	(addDragHandle:			rightCenter	top				(brown)							none)
	(addDupHandle:			right		top				(green)							none)	
	(addDebugHandle:		right		topCenter		(blue	veryMuchLighter)		none)
	(addPoohHandle:			right		center			(white)							none)
	(addRepaintHandle:		right		center			(lightGray)						none)
	(addGrowHandle:		right		bottom			(yellow)						none)
	(addScaleHandle:		right		bottom			(lightOrange)					none)
	(addFontEmphHandle:	rightCenter	bottom			(lightBrown darker)				none)
	(addFontStyleHandle:		center		bottom			(lightRed)						none)
	(addFontSizeHandle:		leftCenter	bottom			(lightGreen)						none)

	(addRecolorHandle:		right		bottomCenter	(magenta darker)				none)

	(addRotateHandle:		left			bottom			(blue)							none))

! !

!Preferences class methodsFor: 'halos' stamp: 'jmv 12/20/2004 21:28'!
customHaloSpecs
	"Intended for you to modify to suit your personal preference.  What is implemented in the default here is just a skeleton; in comment at the bottom of this method are some useful lines you may wish to paste in to the main body here, possibly modifying positions, colors, etc..
	Note that in this example, we include:
			Dismiss handle, at top-left
			Menu handle, at top-right
			Resize handle, at bottom-right
			Rotate handle, at bottom-left
			Drag handle, at top-center
			Recolor handle, at left-center.  (this one is NOT part of the standard formulary --
											it is included here to illustrate how to
 											add non-standard halos)
			Note that the optional handles for specialized morphs, such as Sketch, Text, PasteUp, are also included"

	^ #(
	(addDismissHandle:		left			top				(red		muchLighter)			'Halo-Dismiss')
	(addMenuHandle:		right		top				(red)							'Halo-Menu')
	(addDragHandle:			center	top					(brown)							'Halo-Drag')
	(addGrowHandle:		right		bottom			(yellow)						'Halo-Scale')
	(addScaleHandle:		right		bottom			(lightOrange)					'Halo-Scale')

	(addRecolorHandle:		left			center			(green muchLighter lighter)		'Halo-Recolor')

	(addRepaintHandle:		right		center			(lightGray)						'Halo-Paint')
	(addFontSizeHandle:		leftCenter	bottom			(lightGreen)						'Halo-FontSize')
	(addFontStyleHandle:		center		bottom			(lightRed)						'Halo-FontStyle')
	(addFontEmphHandle:	rightCenter	bottom			(lightBrown darker)				'Halo-FontEmph')
	(addRotateHandle:		left			bottom			(blue)							'Halo-Rot')

	(addDebugHandle:		right		topCenter		(blue	veryMuchLighter)		'Halo-Debug')
	(addPoohHandle:			right		center			(white)							'Halo-Pooh')


			)

	"  Other useful handles...

  		selector				horiz		vert			color info						icon key
		---------				------		-----------		-------------------------------		---------------

	(addTileHandle:			left			bottomCenter	(lightBrown)					'Halo-Tile')
	(addViewHandle:			left			center			(cyan)							'Halo-View')
	(addGrabHandle:			center		top				(black)							'Halo-Grab')
	(addDragHandle:			rightCenter	top				(brown)							'Halo-Drag')
	(addDupHandle:			right		top				(green)							'Halo-Dup')	
	(addHelpHandle:			center		bottom			(lightBlue)						'Halo-Help')
	(addFewerHandlesHandle:	left		topCenter		(paleBuff)						'Halo-FewerHandles')
	(addPaintBgdHandle:		right		center			(lightGray)						'Halo-Paint')
	(addRepaintHandle:		right		center			(lightGray)						'Halo-Paint')
	"
! !

!Preferences class methodsFor: 'halos' stamp: 'jmv 12/20/2004 21:29'!
haloSpecificationsForWorld
	| desired |
	"Answer a list of HaloSpecs that describe which halos are to be used on a world halo, what they should look like, and where they should be situated"
	"Preferences resetHaloSpecifications"

	desired _ #(addDebugHandle: addMenuHandle: addHelpHandle:).
	^ self haloSpecifications select:
		[:spec | desired includes: spec addHandleSelector]! !

!Preferences class methodsFor: 'halos' stamp: 'jmv 12/20/2004 21:29'!
iconicHaloSpecifications
	"Answer an array that characterizes the locations, colors, icons, and selectors of the halo handles that may be used in the iconic halo scheme"

	"Preferences resetHaloSpecifications"

	^ #(
	"  	selector				horiz		vert			color info						icon key
		---------				------		-----------		-------------------------------		---------------"
	(addCollapseHandle:		left			topCenter		(tan)							'Halo-Collapse')
	(addPoohHandle:			right		center			(white)							'Halo-Pooh')
	(addDebugHandle:		right		topCenter		(blue	veryMuchLighter)		'Halo-Debug')
	(addDismissHandle:		left			top				(red		muchLighter)			'Halo-Dismiss')
	(addRotateHandle:		left			bottom			(blue)							'Halo-Rot')
	(addMenuHandle:		leftCenter	top				(red)							'Halo-Menu')
	(addGrabHandle:			center		top				(black)							'Halo-Grab')
	(addDragHandle:			rightCenter	top				(brown)							'Halo-Drag')
	(addDupHandle:			right		top				(green)							'Halo-Dup')	
	(addHelpHandle:			center		bottom			(lightBlue)						'Halo-Help')
	(addGrowHandle:		right		bottom			(yellow)						'Halo-Scale')
	(addScaleHandle:		right		bottom			(lightOrange)					'Halo-Scale')
	(addRepaintHandle:		right		center			(lightGray)						'Halo-Paint')
	(addFontSizeHandle:		leftCenter	bottom			(lightGreen)						'Halo-FontSize')
	(addFontStyleHandle:		center		bottom			(lightRed)						'Halo-FontStyle')
	(addFontEmphHandle:	rightCenter	bottom			(lightBrown darker)				'Halo-FontEmph')
	(addRecolorHandle:		right		bottomCenter	(magenta darker)				'Halo-Recolor')
	(addChooseGraphicHandle:	right	bottomCenter	(green muchLighter)			'Halo-ChooseGraphic')
		) ! !

!Preferences class methodsFor: 'halos' stamp: 'jmv 12/20/2004 21:29'!
simpleFullHaloSpecifications
	"This method gives the specs for the 'full' handles variant when simple halos are in effect"

	"Preferences resetHaloSpecifications"

	^ #(
	"  	selector				horiz		vert			color info						icon key
		---------				------		-----------		-------------------------------		---------------"
	(addDebugHandle:		right		topCenter		(blue	veryMuchLighter)		'Halo-Debug')
	(addPoohHandle:			right		center			(white)							'Halo-Pooh')
	(addDismissHandle:		left			top				(red		muchLighter)			'Halo-Dismiss')
	(addRotateHandle:		left			bottom			(blue)							'Halo-Rot')
	(addMenuHandle:		leftCenter	top				(red)							'Halo-Menu')
	(addGrabHandle:			center		top				(black)							'Halo-Grab')
	(addDragHandle:			rightCenter	top				(brown)							'Halo-Drag')
	(addDupHandle:			right		top				(green)							'Halo-Dup')	
	(addHelpHandle:			center		bottom			(lightBlue)						'Halo-Help')
	(addGrowHandle:		right		bottom			(yellow)						'Halo-Scale')
	(addScaleHandle:		right		bottom			(lightOrange)					'Halo-Scale')
	(addFewerHandlesHandle:	left		topCenter		(paleBuff)						'Halo-FewerHandles')
	(addRepaintHandle:		right		center			(lightGray)						'Halo-Paint')
	(addFontSizeHandle:		leftCenter	bottom			(lightGreen)						'Halo-FontSize')
	(addFontStyleHandle:		center		bottom			(lightRed)						'Halo-FontStyle')
	(addFontEmphHandle:	rightCenter	bottom			(lightBrown darker)		  'Halo-FontEmph')
	(addRecolorHandle:		right		bottomCenter	(magenta darker)				'Halo-Recolor')

		) ! !

!Preferences class methodsFor: 'misc' stamp: 'jmv 12/31/2004 15:48'!
defaultValueTableForCurrentRelease
	"Answer a table defining default values for all the preferences in the release.  Returns a list of (pref-symbol, boolean-symbol) pairs"

	^  #(
		(abbreviatedBrowserButtons false)
		(allowCelesteTell true)
		(alternativeBrowseIt false)
		(alternativeScrollbarLook true)
		(alternativeWindowLook true)
		(annotationPanes false)
		(areaFillsAreTolerant false)
		(areaFillsAreVeryTolerant false)
		(autoAccessors false)
		(automaticFlapLayout true)
		(automaticKeyGeneration false)
		(automaticPlatformSettings true)
		(automaticViewerPlacement true)
		(balloonHelpEnabled true)
		(balloonHelpInMessageLists false)
		(browseWithDragNDrop false)
		(browseWithPrettyPrint false)
		(browserShowsPackagePane false)
		(canRecordWhilePlaying false)
		(caseSensitiveFinds false)
		(cautionBeforeClosing false)
		(changeSetVersionNumbers true)
		(checkForSlips true)
		(checkForUnsavedProjects true)
		(classicNavigatorEnabled false)
		(classicNewMorphMenu false)
		(clickOnLabelToEdit false)
		(cmdDotEnabled true)
		(collapseWindowsInPlace false)
		(colorWhenPrettyPrinting false)
		(compactViewerFlaps false)
		(compressFlashImages false)
		(confirmFirstUseOfStyle true)
		(conversionMethodsAtFileOut false)
		(cpuWatcherEnabled false)
		(debugHaloHandle true)
		(debugPrintSpaceLog false)
		(debugShowDamage false)
		(decorateBrowserButtons true)
		(diffsInChangeList true)
		(diffsWithPrettyPrint false)
		(dismissAllOnOptionClose false)
		(dragNDropWithAnimation false)
		(enableLocalSave true)
		(extractFlashInHighQuality true)
		(extractFlashInHighestQuality false)
		(fastDragWindowForMorphic true)
		(fullScreenLeavesDeskMargins true)
		(haloTransitions false)
		(hiddenScrollBars false)
		(higherPerformance false)
		(honorDesktopCmdKeys true)
		(ignoreStyleIfOnlyBold true)
		(inboardScrollbars true)
		(includeSoundControlInNavigator false)
		(infiniteUndo false)
		(logDebuggerStackToFile true)
		(magicHalos false)
		(menuButtonInToolPane false)
		(menuColorFromWorld false)
		(menuKeyboardControl false)  
		(modalColorPickers true)
		(mouseOverForKeyboardFocus false)
		(mvcProjectsAllowed true)
		(navigatorOnLeftEdge true)
		(noviceMode false)
		(okToReinitializeFlaps true)
		(optionalButtons true)
		(passwordsOnPublish false)
		(personalizedWorldMenu true)
		(postscriptStoredAsEPS false)
		(preserveTrash true)
		(printAlternateSyntax false)
		(projectViewsInWindows true)
		(projectZoom true)
		(projectsSentToDisk false)
		(promptForUpdateServer true)
		(propertySheetFromHalo false)
		(readDocumentAtStartup true)
		(restartAlsoProceeds false)
		(reverseWindowStagger true)
		(roundedMenuCorners true)
		(roundedWindowCorners true)
		(scrollBarsNarrow false)
		(scrollBarsOnRight true)
		(scrollBarsWithoutMenuButton false)
		(securityChecksEnabled false)
		(selectiveHalos false)
		(showBoundsInHalo false)
		(showDirectionForSketches false)
		(showDirectionHandles false)
		(showFlapsWhenPublishing false)
		(showSecurityStatus true)
		(showSharedFlaps true)
		(signProjectFiles true)
		(simpleMenus false)
		(slideDismissalsToTrash true)
		(smartUpdating true)
		(soundQuickStart false)
		(soundStopWhenDone false)
		(soundsEnabled true)
		(startInUntrustedDirectory false)
		(systemWindowEmbedOK false)
		(thoroughSenders true)
		(timeStampsInMenuTitles true)
		(turnOffPowerManager false)
		(twentyFourHourFileStamps true)
		(twoSidedPoohTextures true)
		(uniqueNamesInHalos false)
		(unlimitedPaintArea false)
		(updateSavesFile false)
		(useButtonProprtiesToFire false)
		(useUndo true)
		(viewersInFlaps true)
		(warnAboutInsecureContent true)
		(warnIfNoChangesFile true)
		(warnIfNoSourcesFile true))


"
Preferences defaultValueTableForCurrentRelease do:
	[:pair | (Preferences preferenceAt: pair first ifAbsent: [nil]) ifNotNilDo:
			[:pref | pref defaultValue: (pair last == #true)]].
Preferences chooseInitialSettings.
"! !

!Preferences class methodsFor: 'personalization' stamp: 'jmv 12/1/2004 13:18'!
personalizeUserMenu: aMenu
	"The user has clicked on the morphic desktop with the yellow mouse button (option+click on the Mac); a menu is being constructed to present to the user in response; its default target is the current world.  In this method, you are invited to add items to the menu as per personal preferences.
	The default implementation, for illustrative purposes, sets the menu title to 'personal', and adds items for go-to-previous-project, show/hide flaps, and load code updates"
	
	aMenu addTitle: 'personal' translated.  "Remove or modify this as per personal choice"

	aMenu addStayUpItem.
	aMenu add: 'previous project' translated action: #goBack.
	aMenu add: 'load latest code updates' translated target: Utilities action: #updateFromServer.
	aMenu add: 'about this system...' translated target: Smalltalk action: #aboutThisSystem.
	Preferences isFlagship ifTrue:
		"For benefit of Alan"
		[aMenu addLine.
		aMenu add: 'start using vectors' translated target: ActiveWorld action: #installVectorVocabulary.
		aMenu add: 'stop using vectors' translated target: ActiveWorld action: #abandonVocabularyPreference]! !

!Preferences class methodsFor: 'preferences panel' stamp: 'jmv 12/19/2004 09:24'!
openPreferencesInspector
	"Open a window on the current set of preferences choices, allowing the user to view and change their settings"
	
	self inspectPreferences! !

!Preferences class methodsFor: 'reacting to change' stamp: 'jmv 12/28/2004 23:16'!
setNotificationParametersForStandardPreferences
	"Set up the notification parameters for the standard preferences that require need them.  When adding new Preferences that require use of the notification mechanism, users declare the notifcation info as part of the call that adds the preference, or afterwards -- the two relevant methods for doing that are:
 	Preferences.addPreference:categories:default:balloonHelp:projectLocal:changeInformee:changeSelector:   and
	Preference changeInformee:changeSelector:"

		"Preferences setNotificationParametersForStandardPreferences"

	| aPreference |
	#(	
		(annotationPanes		annotationPanesChanged)
		(optionalButtons			optionalButtonsChanged)
		(roundedWindowCorners	roundedWindowCornersChanged)
		(smartUpdating			smartUpdatingChanged)
	)  do:

			[:pair |
				aPreference _ self preferenceAt: pair first.
				aPreference changeInformee: self changeSelector: pair second]! !

!Preferences class methodsFor: 'themes' stamp: 'jmv 12/28/2004 23:16'!
brightSqueak
	"The classic bright Squeak look.  Windows have saturated colors and relatively low contrast; scroll-bars are of the flop-out variety and are on the left.  Many power-user features are enabled."

	self setPreferencesFrom:
	#(
		(alternativeScrollbarLook false)
		(alternativeWindowLook false)
		(annotationPanes true)
		(automaticFlapLayout true)
		(balloonHelpEnabled true)
		(balloonHelpInMessageLists false)
		(browseWithDragNDrop true)
		(browseWithPrettyPrint false)
		(browserShowsPackagePane false)
		(classicNavigatorEnabled false)
		(classicNewMorphMenu false)
		(clickOnLabelToEdit false)
		(cmdDotEnabled true)
		(collapseWindowsInPlace false)
		(colorWhenPrettyPrinting false)
		(debugHaloHandle true)
		(debugPrintSpaceLog false)
		(debugShowDamage false)
		(decorateBrowserButtons true)
		(diffsInChangeList true)
		(diffsWithPrettyPrint false)
		(dragNDropWithAnimation true)
		(fastDragWindowForMorphic true)
		(fullScreenLeavesDeskMargins true)
		(haloTransitions false)
		(hiddenScrollBars false)
		(ignoreStyleIfOnlyBold true)
		(inboardScrollbars false)
		(logDebuggerStackToFile true)
		(magicHalos false)
		(menuButtonInToolPane false)
		(menuColorFromWorld false)
		(menuKeyboardControl true)  
		(mouseOverForKeyboardFocus true)
		(navigatorOnLeftEdge true)
		(noviceMode false)
		(optionalButtons true)
		(personalizedWorldMenu true)
		(preserveTrash true)
		(printAlternateSyntax false)
		(projectViewsInWindows true)
		(projectZoom true)
		(propertySheetFromHalo false)
		(restartAlsoProceeds false)
		(reverseWindowStagger true)
		(roundedMenuCorners true)
		(roundedWindowCorners true)
		(scrollBarsNarrow false)
		(scrollBarsOnRight false)
		(scrollBarsWithoutMenuButton false)
		(selectiveHalos false)
		(showSharedFlaps true)
		(simpleMenus false)
		(smartUpdating true)
		(systemWindowEmbedOK false)
		(thoroughSenders true)
		(timeStampsInMenuTitles true)
		(unlimitedPaintArea false)
		(useButtonProprtiesToFire false)
		(useUndo true)
		(viewersInFlaps true)
		(warnIfNoChangesFile true)
		(warnIfNoSourcesFile true)).

	self installBrightWindowColors! !

!Preferences class methodsFor: 'themes' stamp: 'jmv 12/31/2004 15:48'!
paloAlto
	"Similar to the brightSqueak theme, but with a number of idiosyncratic personal settings.   Note that mouseOverForKeyboardFocus & caseSensitiveFinds are both true"


	self setPreferencesFrom:
	#(
		(abbreviatedBrowserButtons false)
		(accessOnlineModuleRepositories noOpinion)
		(allowCelesteTell noOpinion)
		(alternativeBrowseIt noOpinion)
		(alternativeScrollbarLook false)
		(alternativeWindowLook false)
		(annotationPanes true)
		(areaFillsAreTolerant true)
		(areaFillsAreVeryTolerant false)
		(autoAccessors false)
		(automaticFlapLayout true)
		(automaticKeyGeneration noOpinion)
		(automaticPlatformSettings noOpinion)
		(automaticViewerPlacement false)
		(balloonHelpEnabled true)
		(balloonHelpInMessageLists false)
		(browseWithDragNDrop false)
		(browseWithPrettyPrint false)
		(browserShowsPackagePane false)
		(canRecordWhilePlaying noOpinion)
		(caseSensitiveFinds true)
		(cautionBeforeClosing false)
		(changeSetVersionNumbers true)
		(checkForSlips true)
		(checkForUnsavedProjects noOpinion)
		(classicNavigatorEnabled false)
		(classicNewMorphMenu false)
		(clickOnLabelToEdit false)
		(cmdDotEnabled true)
		(collapseWindowsInPlace false)
		(colorWhenPrettyPrinting false)
		(compactViewerFlaps false)
		(compressFlashImages noOpinion)
		(confirmFirstUseOfStyle true)
		(conservativeModuleDeActivation noOpinion)
		(conversionMethodsAtFileOut true)
		(cpuWatcherEnabled noOpinion)
		(debugHaloHandle true)
		(debugPrintSpaceLog true)
		(debugShowDamage false)
		(decorateBrowserButtons true)
		(diffsInChangeList true)
		(diffsWithPrettyPrint false)
		(dismissAllOnOptionClose true)
		(dragNDropWithAnimation false)
		(duplicateControlAndAltKeys false)
		(enableLocalSave true)
		(extractFlashInHighQuality noOpinion)
		(extractFlashInHighestQuality noOpinion)
		(extraDebuggerButtons true)
		(fastDragWindowForMorphic true)
		(fullScreenLeavesDeskMargins true)
		(haloTransitions false)
		(hiddenScrollBars false)
		(higherPerformance noOpinion)
		(honorDesktopCmdKeys true)
		(ignoreStyleIfOnlyBold true)
		(inboardScrollbars false)
		(includeSoundControlInNavigator true)
		(infiniteUndo false)
		(lenientScopeForGlobals noOpinion)
		(logDebuggerStackToFile true)
		(magicHalos false)
		(menuButtonInToolPane false)
		(menuColorFromWorld false)
		(menuKeyboardControl true)  
		(modalColorPickers true)
		(modularClassDefinitions noOpinion)
		(mouseOverForKeyboardFocus true)
		(mvcProjectsAllowed true)
		(navigatorOnLeftEdge true)
		(noviceMode false)
		(okToReinitializeFlaps true)
		(optionalButtons true)
		(passwordsOnPublish noOpinion)
		(personalizedWorldMenu true)
		(postscriptStoredAsEPS noOpinion)
		(preserveTrash false)
		(projectsSentToDisk noOpinion)
		(projectViewsInWindows true)
		(projectZoom true)
		(promptForUpdateServer false)
		(printAlternateSyntax false)
		(propertySheetFromHalo false)
		(restartAlsoProceeds false)
		(reverseWindowStagger true)
		(roundedMenuCorners true)
		(roundedWindowCorners true)
		(scrollBarsNarrow false)
		(scrollBarsOnRight false)
		(scrollBarsWithoutMenuButton false)
		(securityChecksEnabled noOpinion)
		(selectiveHalos false)
		(showBoundsInHalo false)
		(showDirectionForSketches true)
		(showDirectionHandles false)
		(showFlapsWhenPublishing false)
		(showSecurityStatus noOpinion)
		(showSharedFlaps true)
		(signProjectFiles noOpinion)
		(simpleMenus false)
		(slideDismissalsToTrash true)
		(smartUpdating true)
		(soundQuickStart noOpinion)
		(soundsEnabled true)
		(soundStopWhenDone noOpinion)
		(startInUntrustedDirectory noOpinion)
		(strongModules noOpinion)
		(swapControlAndAltKeys noOpinion)
		(swapMouseButtons  noOpinion)
		(systemWindowEmbedOK false)
		(thoroughSenders true)
		(timeStampsInMenuTitles true)
		(turnOffPowerManager noOpinion)
		(twentyFourHourFileStamps false)
		(twoSidedPoohTextures noOpinion)
		(uniqueNamesInHalos false)
		(unlimitedPaintArea false)
		(updateSavesFile noOpinion)
		(useButtonProprtiesToFire false)
		(useUndo true)
		(viewersInFlaps true)
		(warnAboutInsecureContent noOpinion)
		(warnIfNoChangesFile true)
		(warnIfNoSourcesFile true)).

	self installBrightWindowColors! !

!Preferences class methodsFor: 'themes' stamp: 'jmv 12/28/2004 23:16'!
smalltalk80
	"A traditional monochrome Smalltalk-80 look and feel, clean and austere, and lacking many features added to Squeak in recent years. Caution: this theme removes the standard Squeak flaps, turns off the 'smartUpdating' feature that keeps multiple browsers in synch, and much more."

	self setPreferencesFrom:

	#(	
		(alternativeScrollbarLook false)
		(alternativeWindowLook false)
		(annotationPanes false)
		(autoAccessors false)
		(balloonHelpEnabled false)
		(balloonHelpInMessageLists false)
		(browseWithDragNDrop false)
		(browseWithPrettyPrint false)
		(browserShowsPackagePane false)
		(caseSensitiveFinds true)
		(checkForSlips false)
		(classicNavigatorEnabled false)
		(clickOnLabelToEdit true)
		(cmdDotEnabled true)
		(collapseWindowsInPlace false)
		(colorWhenPrettyPrinting false)
		(diffsInChangeList false)
		(diffsWithPrettyPrint false)
		(dragNDropWithAnimation false)
		(fastDragWindowForMorphic true)
		(honorDesktopCmdKeys false)
		(ignoreStyleIfOnlyBold true)
		(inboardScrollbars false)
		(menuColorFromWorld false)
		(menuKeyboardControl false)  
		(mouseOverForKeyboardFocus true)
		(mvcProjectsAllowed true)
		(noviceMode false)
		(okToReinitializeFlaps true)
		(optionalButtons false)
		(personalizedWorldMenu false)
		(printAlternateSyntax false)
		(projectViewsInWindows true)
		(projectZoom true)
		(restartAlsoProceeds false)
		(roundedMenuCorners false)
		(roundedWindowCorners false)
		(scrollBarsNarrow false)
		(scrollBarsOnRight false)
		(scrollBarsWithoutMenuButton false)
		(securityChecksEnabled noOpinion)
		(showSharedFlaps false)
		(simpleMenus false)
		(smartUpdating false)
		(thoroughSenders false)
		(timeStampsInMenuTitles false)).

	self installUniformWindowColors! !

!Preferences class methodsFor: 'themes' stamp: 'jmv 12/24/2004 14:55'!
westwood
	"Settings generally similar to those found in a standard browser-plug-in-based Squeak image"

	self setPreferencesFrom: #(
		(alternativeScrollbarLook true)
		(alternativeWindowLook true)
		(classicNavigatorEnabled true)
		(haloTransitions true)
		(honorDesktopCmdKeys false)
		(magicHalos true)
		(menuKeyboardControl false)
		(preserveTrash true)
		(propertySheetFromHalo true)
		(unlimitedPaintArea true))! !

!Preferences class methodsFor: 'window colors' stamp: 'jmv 12/20/2004 21:44'!
windowSpecificationPanel
	"Put up a panel for specifying window colors"

	"Preferences windowSpecificationPanel"
	| aPanel buttonRow aButton aRow aSwatch aColor aWindow aStringMorph |
	aPanel _ AlignmentMorph newColumn hResizing: #shrinkWrap; vResizing: #shrinkWrap;
		layoutInset: 0.

	aPanel addMorph: (buttonRow _ AlignmentMorph newRow color: (aColor _ Color tan lighter)).
	
	buttonRow addTransparentSpacerOfSize: 2@0.
	buttonRow addMorphBack: (SimpleButtonMorph new label: '?'; target: self; actionSelector: #windowColorHelp; setBalloonText: 'Click for an explanation of this panel'; color: Color veryVeryLightGray; yourself).
	buttonRow addTransparentSpacerOfSize: 8@0.
	#(	('Bright' 	installBrightWindowColors	yellow
					'Use standard bright colors for all windows.')
		('Pastel'		installPastelWindowColors	paleMagenta
					'Use standard pastel colors for all windows.')
		('White'	installUniformWindowColors		white
					'Use white backgrounds for all standard windows.')) do:

		[:quad |
			aButton _ (SimpleButtonMorph new target: self)
				label: quad first;
				actionSelector: quad second;
				color: (Color colorFrom: quad third);
				setBalloonText: quad fourth;
				yourself.
			buttonRow addMorphBack: aButton.
			buttonRow addTransparentSpacerOfSize: 10@0].

	self windowColorTable do:
		[:colorSpec | 
			aRow _ AlignmentMorph newRow color: aColor.
			self halt: 'jmv must replace ColorSwatch with something!!'.
			aSwatch _ "ColorSwatch" SimpleButtonMorph new
				target: self;
				getSelector: #windowColorFor:;
				putSelector: #setWindowColorFor:to:;
				argument: colorSpec classSymbol;
				extent: (40 @ 20);
				setBalloonText: 'Click here to change the standard color to be used for ', colorSpec wording, ' windows.';
				yourself.
			aRow addMorphFront: aSwatch.
			aRow addTransparentSpacerOfSize: (12 @ 1).
			aRow addMorphBack: (aStringMorph _ StringMorph contents: colorSpec wording font: TextStyle defaultFont).
			aStringMorph setBalloonText: colorSpec helpMessage.
			aPanel addMorphBack: aRow].

	 Smalltalk isMorphic
                ifTrue:
                        [aWindow _ aPanel wrappedInWindowWithTitle: 'Window Colors'.
					" don't allow the window to be picked up by clicking inside "
					aPanel on: #mouseDown send: #yourself to: aPanel.
					self currentWorld addMorphCentered: aWindow.
					aWindow activateAndForceLabelToShow ]
                ifFalse:
                        [self halt: 'removed (jmv)']! !


!ProcessBrowser class methodsFor: 'class initialization' stamp: 'jmv 12/1/2004 12:02'!
initialize
	"ProcessBrowser initialize"
	Browsers ifNil: [ Browsers _ WeakSet new ].
	SuspendedProcesses ifNil: [ SuspendedProcesses _ IdentityDictionary new ].
	Smalltalk addToStartUpList: self.
	Smalltalk addToShutDownList: self! !


!ProgressMorph methodsFor: 'private' stamp: 'jmv 12/24/2004 15:00'!
fontOfPointSize: size
	^ TextStyle default fontOfPointSize: size! !


!Project methodsFor: 'menu messages' stamp: 'jmv 12/28/2004 23:25'!
enter: returningFlag revert: revertFlag saveForRevert: saveForRevert
	"Install my ChangeSet, Transcript, and scheduled views as current globals. If returningFlag is true, we will return to the project from whence the current project was entered; don't change its previousProject link in this case.
	If saveForRevert is true, save the ImageSegment of the project being left.
	If revertFlag is true, make stubs for the world of the project being left.
	If revertWithoutAsking is true in the project being left, then always revert."

	| showZoom recorderOrNil old forceRevert response seg newProcess |

	(world isKindOf: StringMorph) ifTrue: [
		self inform: 'This project is not all here. Trouble.Try to understand!!'.
		^self
"		self inform: 'This project is not all here. I will try to load a complete version.'.
		^self loadFromServer: true"	"try to get a fresh copy"
	].
	self isCurrentProject ifTrue: [^ self].
	"Check the guards"
	guards ifNotNil:
		[guards _ guards reject: [:obj | obj isNil].
		guards do: [:obj | obj okayToEnterProject ifFalse: [^ self]]].
	CurrentProject world triggerEvent: #aboutToLeaveWorld.
	forceRevert _ false.
	CurrentProject rawParameters 
		ifNil: [revertFlag ifTrue: [^ self inform: 'nothing to revert to']]
		ifNotNil: [saveForRevert ifFalse: [
				forceRevert _ CurrentProject projectParameters 
								at: #revertWithoutAsking ifAbsent: [false]]].
	forceRevert not & revertFlag ifTrue: [
		response _ SelectionMenu confirm: 'Are you sure you want to destroy this Project\ and revert to an older version?\\(From the parent project, click on this project''s thumbnail.)' withCRs
			trueChoice: 'Revert to saved version' 
			falseChoice: 'Cancel'.
		response ifFalse: [^ self]].

	revertFlag | forceRevert 
		ifTrue: [seg _ CurrentProject projectParameters at: #revertToMe ifAbsent: [
					^ self inform: 'nothing to revert to']]
		ifFalse: [
			CurrentProject finalExitActions.
			CurrentProject makeThumbnail.
			returningFlag == #specialReturn
				ifTrue:
					[ProjectHistory forget: CurrentProject.		"this guy is irrelevant"
					Project forget: CurrentProject]
				ifFalse:
					[ProjectHistory remember: CurrentProject]].

	(revertFlag | saveForRevert | forceRevert) ifFalse:
		[(Preferences valueOfFlag: #projectsSentToDisk) ifTrue:
			[self storeToMakeRoom]].

	CurrentProject abortResourceLoading.

	CurrentProject saveProjectPreferences.

	"Update the display depth and make a thumbnail of the current project"
	CurrentProject displayDepth: Display depth.
	old _ CurrentProject.		"for later"

	"Show the project transition.
	Note: The project zoom is run in the context of the old project,
		so that eventual errors can be handled accordingly"
	displayDepth == nil ifTrue: [displayDepth _ Display depth].
	self installNewDisplay: Display extent depth: displayDepth.
	(showZoom _ self showZoom) ifTrue: [
		self displayZoom: CurrentProject parent ~~ self].

	(world isMorph and: [world hasProperty: #letTheMusicPlay])
		ifTrue: [world removeProperty: #letTheMusicPlay]
		ifFalse: [Smalltalk at: #ScorePlayer ifPresentAndInMemory:
					[:playerClass | playerClass allSubInstancesDo:
						[:player | player pause]]].

	returningFlag == #specialReturn ifTrue: [
		old removeChangeSetIfPossible.	"keep this stuff from accumulating"
		nextProject _ nil
	] ifFalse: [
		returningFlag
			ifTrue: [nextProject _ CurrentProject]
			ifFalse: [previousProject _ CurrentProject].
	].

	CurrentProject saveState.
	CurrentProject isolationHead == self isolationHead ifFalse:
		[self invokeFrom: CurrentProject].
	CurrentProject _ self.
	self installProjectPreferences.
	ChangeSet  newChanges: changeSet.
	TranscriptStream newTranscript: transcript.
	Sensor flushKeyboard.
	Smalltalk isMorphic ifTrue: [recorderOrNil _ World pauseEventRecorder].

	ProjectHistory remember: CurrentProject.

	world isMorph
		ifTrue:
			[World _ world.  "Signifies Morphic"
			world install.
			"(revertFlag | saveForRevert | forceRevert) ifFalse: [
				(Preferences valueOfFlag: #projectsSentToDisk) ifTrue: [
					self storeSomeSegment]]."
			recorderOrNil ifNotNil: [recorderOrNil resumeIn: world]]
		ifFalse:
			[World _ nil.  "Signifies MVC"
			Smalltalk at: #ScheduledControllers put: world].

	saveForRevert ifTrue: [
		Smalltalk garbageCollect.	"let go of pointers"
		old storeSegment.
		"result _" old world isInMemory 
			ifTrue: ['Can''t seem to write the project.']
			ifFalse: [old projectParameters at: #revertToMe put: 
					old world xxxSegment clone].
				'Project written.'].
			"original is for coming back in and continuing."

	revertFlag | forceRevert ifTrue: [
		seg clone revert].	"non-cloned one is for reverting again later"
	self removeParameter: #exportState.

	"Complete the enter: by launching a new process"
	world isMorph ifTrue: [
		self finalEnterActions.
		world repairEmbeddedWorlds.
		world triggerEvent: #aboutToEnterWorld.
		Project spawnNewProcessAndTerminateOld: true
	] ifFalse: [
		SystemWindow clearTopWindow.	"break external ref to this project"
		newProcess _ [	
			ScheduledControllers resetActiveController.	"in case of walkback in #restore"
			showZoom ifFalse: [ScheduledControllers restore].
			ScheduledControllers searchForActiveController
		] fixTemps newProcess priority: Processor userSchedulingPriority.
		newProcess resume.		"lose the current process and its referenced morphs"
		Processor terminateActive.
	]! !

!Project methodsFor: 'menu messages' stamp: 'jmv 12/24/2004 15:31'!
enterAsActiveSubprojectWithin: enclosingWorld

	"Install my ChangeSet, Transcript, and scheduled views as current globals. 

	If returningFlag is true, we will return to the project from whence the current project was entered; don't change its previousProject link in this case.
	If saveForRevert is true, save the ImageSegment of the project being left.
	If revertFlag is true, make stubs for the world of the project being left.
	If revertWithoutAsking is true in the project being left, then always revert."

	"Experimental mods for initial multi-project work:
		1. assume in morphic (this eliminated need for <showZoom>)
		2. assume <saveForRevert> is false (usual case) - removed <old>
		3. assume <revertFlag> is false
		4. assume <revertWithoutAsking> is false - <forceRevert> now auto false <seg> n.u.
		5. no zooming
		6. assume <projectsSentToDisk> false - could be dangerous here
		7. assume no isolation problems (isolationHead ==)
		8. no closing scripts
	"

	self isCurrentProject ifTrue: [^ self].

	guards ifNotNil: [
		guards _ guards reject: [:obj | obj isNil].
		guards do: [:obj | obj okayToEnterProject ifFalse: [^ self]]
	].

		"CurrentProject makeThumbnail."
		"--> Display bestGuessOfCurrentWorld triggerClosingScripts."
	CurrentProject displayDepth: Display depth.

	displayDepth == nil ifTrue: [displayDepth _ Display depth].
		"Display newDepthNoRestore: displayDepth."

		"(world hasProperty: #letTheMusicPlay)
			ifTrue: [world removeProperty: #letTheMusicPlay]
			ifFalse: [Smalltalk at: #ScorePlayer ifPresent: [:playerClass | 
						playerClass allSubInstancesDo: [:player | player pause]]]."

		"returningFlag
			ifTrue: [nextProject _ CurrentProject]
			ifFalse: [previousProject _ CurrentProject]."

		"CurrentProject saveState."
		"CurrentProject _ self."
		"Smalltalk newChanges: changeSet."
		"TranscriptStream newTranscript: transcript."
		"Sensor flushKeyboard."
		"recorderOrNil _ Display pauseMorphicEventRecorder."

		"Display changeMorphicWorldTo: world."  "Signifies Morphic"
	world 
		installAsActiveSubprojectIn: enclosingWorld 
		titled: self name.

		"recorderOrNil ifNotNil: [recorderOrNil resumeIn: world]."
	self removeParameter: #exportState.
		"self spawnNewProcessAndTerminateOld: true"! !

!Project methodsFor: 'menu messages' stamp: 'jmv 12/24/2004 15:31'!
enterForEmergencyRecovery
	"This version of enter invokes an absolute minimum of mechanism.
	An unrecoverable error has been detected in an isolated project.
	It is assumed that the old changeSet has already been revoked.
	No new process gets spawned here.  This will happen in the debugger."

	self isCurrentProject ifTrue: [^ self].
	CurrentProject saveState.
	CurrentProject _ self.
	Display newDepthNoRestore: displayDepth.
	ChangeSet  newChanges: changeSet.
	TranscriptStream newTranscript: transcript.
	World pauseEventRecorder.

	world isMorph
		ifTrue:
			["Entering a Morphic project"
			World _ world.
			world install]
		ifFalse:
			["Entering an MVC project"
			World _ nil.
			Smalltalk at: #ScheduledControllers put: world.
			ScheduledControllers restore].
	UIProcess _ Processor activeProcess.
! !

!Project methodsFor: 'menu messages' stamp: 'jmv 12/2/2004 23:10'!
finalEnterActions
	"Perform the final actions necessary as the receiver project is entered"

	| armsLengthCmd thingsToUnhibernate |

	self projectParameters 
		at: #projectsToBeDeleted 
		ifPresent: [ :projectsToBeDeleted |
			self removeParameter: #projectsToBeDeleted.
			projectsToBeDeleted do: [ :each | 
				Project deletingProject: each.
				each removeChangeSetIfPossible]].

	thingsToUnhibernate _ world valueOfProperty: #thingsToUnhibernate ifAbsent: [#()].
	thingsToUnhibernate do: [:each | each unhibernate].
	world removeProperty: #thingsToUnhibernate.

	armsLengthCmd _ self parameterAt: #armsLengthCmd ifAbsent: [nil].
	armsLengthCmd notNil ifTrue:
		[
		armsLengthCmd openInWorld: world].
	Smalltalk isMorphic ifTrue:
		[world reformulateUpdatingMenus].

	WorldState addDeferredUIMessage: [self startResourceLoading].! !

!Project methodsFor: 'menu messages' stamp: 'jmv 12/8/2004 12:54'!
finalExitActions


	world isMorph ifTrue: [
	].
! !

!Project methodsFor: 'menu messages' stamp: 'jmv 12/6/2004 20:50'!
makeThumbnail
	"Make a thumbnail image of this project from the Display."

	world isMorph ifTrue: [world displayWorldSafely]. "clean pending damage"
	viewSize ifNil: [viewSize _ Display extent // 8].
	thumbnail _ Form extent: viewSize depth: Display depth.
	(WarpBlt current toForm: thumbnail)
			sourceForm: Display;
			cellSize: 2;  "installs a colormap"
			combinationRule: Form over;
			copyQuad: (Display boundingBox) innerCorners
			toRect: (0@0 extent: viewSize).
	^thumbnail
! !

!Project methodsFor: 'menu messages' stamp: 'jmv 12/6/2004 20:49'!
validateProjectNameIfOK: aBlock

	| details |

	details _ world valueOfProperty: #ProjectDetails.
	details ifNotNil: ["ensure project info matches real project name"
		details at: 'projectname' put: self name.
	].
	self doWeWantToRename ifFalse: [^aBlock value].
"
	EToyProjectDetailsMorph
		getFullInfoFor: self 
		ifValid: [
			World displayWorldSafely.
			aBlock value.
		] fixTemps
		expandedFormat: false
"
"jmv - ok?"
			World displayWorldSafely.
			aBlock value.! !

!Project methodsFor: 'release' stamp: 'jmv 12/25/2004 14:17'!
okToChange
	"Answer whether the window in which the project is housed can be dismissed -- which is destructive. We never clobber a project without confirmation"

	| ok is list |
	self subProjects size  >0 ifTrue:
		[self inform: 
('The project {1}
contains sub-projects.  You must remove these
explicitly before removing their parent.' translated format:{self name}).
		^ false].
	ok _ world isMorph not and: [world scheduledControllers size <= 1].
	ok ifFalse: [self isMorphic ifTrue:
		[self parent == CurrentProject 
			ifFalse: [^ true]]].  "view from elsewhere.  just delete it."
	ok _ (self confirm:
('Really delete the project
{1}
and all its windows?' translated format:{self name})).
		
	ok ifFalse: [^ false].

	world isMorph ifTrue:
		[
			"Remove Player classes and metaclasses owned by project"
			is _ ImageSegment new arrayOfRoots: (Array with: self).
			(list _ is rootsIncludingPlayers) ifNotNil:
				[list do: [:playerCls | 
					(playerCls respondsTo: #isMeta) ifTrue:
						[playerCls isMeta ifFalse:
							[playerCls removeFromSystemUnlogged]]]]].

	self removeChangeSetIfPossible.
	"do this last since it will render project inaccessible to #allProjects and their ilk"
	ProjectHistory forget: self.
	Project deletingProject: self.
	^ true
! !

!Project methodsFor: 'file in/out' stamp: 'jmv 12/6/2004 09:56'!
exportSegmentWithCatagories: catList classes: classList fileName: aFileName directory: aDirectory
	"Store my project out on the disk as an *exported* ImageSegment.  All outPointers will be in a form that can be resolved in the target image.  Name it <project name>.extSeg.  What do we do about subProjects, especially if they are out as local image segments?  Force them to come in?
	Player classes are included automatically."

	| is str ans revertSeg roots holder |
self halt.  "unused"
	"world == World ifTrue: [^ false]."
		"self inform: 'Can''t send the current world out'."
	world isMorph ifFalse: [
		self projectParameters at: #isMVC put: true.
		^ false].	"Only Morphic projects for now"
	world ifNil: [^ false].  world presenter ifNil: [^ false].

	world currentHand pasteBuffer: nil.	  "don't write the paste buffer."
	world currentHand mouseOverHandler initialize.	  "forget about any references here"
		"Display checkCurrentHandForObjectToPaste."
	world clearCommandHistory.
	world fullReleaseCachedState. 
	world cleanseStepList.
	holder _ Project allProjects.	"force them in to outPointers, where DiskProxys are made"

	"Just export me, not my previous version"
	revertSeg _ self projectParameters at: #revertToMe ifAbsent: [nil].
	self projectParameters removeKey: #revertToMe ifAbsent: [].

	roots _ OrderedCollection new.
	roots add: self; add: world; add: transcript; add: changeSet; add: thumbnail.
	roots add: world activeHand; addAll: classList; addAll: (classList collect: [:cls | cls class]).

	roots _ roots reject: [ :x | x isNil].	"early saves may not have active hand or thumbnail"

	catList do: [:sysCat | 
		(SystemOrganization listAtCategoryNamed: sysCat asSymbol) do: [:symb |
			roots add: (Smalltalk at: symb); add: (Smalltalk at: symb) class]].

	is _ ImageSegment new copySmartRootsExport: roots asArray.
		"old way was (is _ ImageSegment new copyFromRootsForExport: roots asArray)"

	is state = #tooBig ifTrue: [^ false].

	str _ ''.
	"considered legal to save a project that has never been entered"
	(is outPointers includes: world) ifTrue: [
		str _ str, '\Project''s own world is not in the segment.' withCRs].
	str isEmpty ifFalse: [
		ans _ (PopUpMenu labels: 'Do not write file
	Write file anyway
	Debug') startUpWithCaption: str.
		ans = 1 ifTrue: [
			revertSeg ifNotNil: [projectParameters at: #revertToMe put: revertSeg].
			^ false].
		ans = 3 ifTrue: [self halt: 'Segment not written']].

	is writeForExportWithSources: aFileName inDirectory: aDirectory.
	revertSeg ifNotNil: [projectParameters at: #revertToMe put: revertSeg].
	holder.
	^ true
! !

!Project methodsFor: 'file in/out' stamp: 'jmv 12/6/2004 20:30'!
exportSegmentWithChangeSet: aChangeSetOrNil fileName: aFileName directory: aDirectory
	"Store my project out on the disk as an *exported* ImageSegment.  All outPointers will be in a form that can be resolved in the target image.  Name it <project name>.extSeg.  What do we do about subProjects, especially if they are out as local image segments?  Force them to come in?
	Player classes are included automatically."

	| is str ans revertSeg roots holder collector fd mgr |

	"An experimental version to fileout a changeSet first so that a project can contain its own classes"
world isMorph ifFalse: [
	self projectParameters at: #isMVC put: true.
	^ false].	"Only Morphic projects for now"
world ifNil: [^ false].  world presenter ifNil: [^ false].

world currentHand pasteBuffer: nil.	  "don't write the paste buffer."
world currentHand mouseOverHandler initialize.	  "forget about any references here"
	"Display checkCurrentHandForObjectToPaste."
world clearCommandHistory.
world fullReleaseCachedState. 
world cleanseStepList.
holder _ Project allProjects.	"force them in to outPointers, where DiskProxys are made"

"Just export me, not my previous version"
revertSeg _ self projectParameters at: #revertToMe ifAbsent: [nil].
self projectParameters removeKey: #revertToMe ifAbsent: [].

roots _ OrderedCollection new.
roots add: self; add: world; add: transcript; add: changeSet; add: thumbnail.
roots add: world activeHand.

	"; addAll: classList; addAll: (classList collect: [:cls | cls class])"

roots _ roots reject: [ :x | x isNil].	"early saves may not have active hand or thumbnail"

	fd _ aDirectory directoryNamed: self resourceDirectoryName.
	fd assureExistence.
	"Clean up resource references before writing out"
	mgr _ self resourceManager.
	self resourceManager: nil.
	ResourceCollector current: ResourceCollector new.
	ResourceCollector current localDirectory: fd.
	ResourceCollector current baseUrl: self resourceUrl.
	ResourceCollector current initializeFrom: mgr.
	ProgressNotification signal: '2:findingResources' extra: '(collecting resources...)'.
	"Must activate old world because this is run at #armsLength.
	Otherwise references to ActiveWorld, ActiveHand, or ActiveEvent 
	will not be captured correctly if referenced from blocks or user code."
	world becomeActiveDuring:[
		is _ ImageSegment new copySmartRootsExport: roots asArray.
		"old way was (is _ ImageSegment new copyFromRootsForExport: roots asArray)"
	].
	self resourceManager: mgr.
	collector _ ResourceCollector current.
	ResourceCollector current: nil.
	ProgressNotification signal: '2:foundResources' extra: ''.
	is state = #tooBig ifTrue: [
		collector replaceAll.
		^ false].

str _ ''.
"considered legal to save a project that has never been entered"
(is outPointers includes: world) ifTrue: [
	str _ str, '\Project''s own world is not in the segment.' withCRs].
str isEmpty ifFalse: [
	ans _ (PopUpMenu labels: 'Do not write file
Write file anyway
Debug') startUpWithCaption: str.
	ans = 1 ifTrue: [
		revertSeg ifNotNil: [projectParameters at: #revertToMe put: revertSeg].
		collector replaceAll.
		^ false].
	ans = 3 ifTrue: [
		collector replaceAll.
		self halt: 'Segment not written']].
	is 
		writeForExportWithSources: aFileName 
		inDirectory: fd
		changeSet: aChangeSetOrNil.
	SecurityManager default signFile: aFileName directory: fd.
	"Compress all files and update check sums"
	collector forgetObsolete.
	self storeResourceList: collector in: fd.
	self storeHtmlPageIn: fd.
	self compressFilesIn: fd to: aFileName in: aDirectory resources: collector.
			"also deletes the resource directory"
	"Now update everything that we know about"
	mgr updateResourcesFrom: collector.

revertSeg ifNotNil: [projectParameters at: #revertToMe put: revertSeg].
holder.

collector replaceAll.

^ true
! !

!Project methodsFor: 'file in/out' stamp: 'jmv 12/6/2004 21:46'!
findAFolderToStoreProjectIn
	^PluggableFileList getFolderDialog openLabel: 'Select a folder on a server:'! !

!Project methodsFor: 'file in/out' stamp: 'jmv 12/6/2004 09:56'!
storeSegment
	"Store my project out on the disk as an ImageSegment.  Keep the outPointers in memory.  Name it <project name>.seg.  *** Caller must be holding (Project alInstances) to keep subprojects from going out. ***"

| is sizeHint |
(World == world) ifTrue: [^ false]. 
	"self inform: 'Can''t send the current world out'."
world isInMemory ifFalse: [^ false].  "already done"
world isMorph ifFalse: [
	self projectParameters at: #isMVC put: true.
	^ false].	"Only Morphic projects for now"
world ifNil: [^ false].  world presenter ifNil: [^ false].

World checkCurrentHandForObjectToPaste.
sizeHint _ self projectParameters at: #segmentSize ifAbsent: [0].

is _ ImageSegment new copyFromRootsLocalFileFor: 
			(Array with: world presenter with: world)	"world, and all Players"
		 sizeHint: sizeHint.

is state = #tooBig ifTrue: [^ false].
is segment size < 2000 ifTrue: ["debugging" 
	Transcript show: self name, ' only ', is segment size printString, 
		'bytes in Segment.'; cr].
self projectParameters at: #segmentSize put: is segment size.
is extract; writeToFile: self name.
^ true
! !

!Project methodsFor: 'file in/out' stamp: 'jmv 12/6/2004 09:57'!
storeSegmentNoFile
	"For testing.  Make an ImageSegment.  Keep the outPointers in memory.  Also useful if you want to enumerate the objects in the segment afterwards (allObjectsDo:)"

| is str |
(World == world) ifTrue: [^ self].		" inform: 'Can''t send the current world out'."
world isInMemory ifFalse: [^ self].  "already done"
world isMorph ifFalse: [
	self projectParameters at: #isMVC put: true.
	^ self].	"Only Morphic projects for now"
world ifNil: [^ self].  world presenter ifNil: [^ self].

"Do this on project enter"
World checkCurrentHandForObjectToPaste2.

is _ ImageSegment new copyFromRootsLocalFileFor: 
		(Array with: world presenter with: world)	"world, and all Players"
	sizeHint: 0.

is segment size < 800 ifTrue: ["debugging" 
	Transcript show: self name, ' did not get enough objects'; cr.  ^ Beeper beep].
false ifTrue: [
	str _ String streamContents: [:strm |
		strm nextPutAll: 'Only a tiny part of the project got into the segment'.
		strm nextPutAll: '\These are pointed to from the outside:' withCRs.
		is outPointers do: [:out |
			(is arrayOfRoots includes: out class) ifTrue: [strm cr. out printOn: strm.
				self systemNavigation
					browseAllObjectReferencesTo: out
					except: (Array with: is outPointers)
					ifNone: [:obj | ]]]].
	self inform: str.
	^ is inspect].

is extract.
"is instVarAt: 2 put: is segment clone."		"different memory"
! !

!Project methodsFor: 'project parameters' stamp: 'jmv 12/1/2004 13:28'!
initializeProjectPreferences
	"Initialize the project's preferences from currently-prevailing preferences that are currently being held in projects in this system"
	
	projectPreferenceFlagDictionary _ Project current projectPreferenceFlagDictionary deepCopy.    "Project overrides in the new project start out being the same set of overrides in the calling project"

	Preferences allPreferenceObjects do:  "in case we missed some"
		[:aPreference |
			aPreference localToProject ifTrue:
				[(projectPreferenceFlagDictionary includesKey: aPreference name) ifFalse:
			[projectPreferenceFlagDictionary at: aPreference name put: aPreference preferenceValue]]]
! !


!ProjectLauncher methodsFor: 'running' stamp: 'jmv 12/5/2004 15:52'!
startUp
	World ifNotNil: [World install].
	Utilities authorName: ''.
	^self startUpAfterLogin! !

!ProjectLauncher methodsFor: 'running' stamp: 'jmv 1/5/2005 16:09'!
startUpAfterLogin
	| scriptName loader isUrl |
	Preferences readDocumentAtStartup ifTrue: [
		HTTPClient isRunningInBrowser ifTrue:[
			self setupFromParameters.
			scriptName _ self parameterAt: 'src'.
			CodeLoader defaultBaseURL: (self parameterAt: 'Base').
		] ifFalse:[
			scriptName _ (SmalltalkImage current getSystemAttribute: 2) ifNil:[''].
			scriptName isEmpty ifFalse:[
				"figure out if script name is a URL by itself"
				isUrl _ (scriptName asLowercase beginsWith:'http://') or:[
						(scriptName asLowercase beginsWith:'file://') or:[
						(scriptName asLowercase beginsWith:'ftp://')]].
				isUrl ifFalse:[scriptName _ 'file:',scriptName]].
		]. ]
	ifFalse: [ scriptName := '' ].

	scriptName isEmptyOrNil
		ifTrue:[^self].
	
	loader _ CodeLoader new.
	loader loadSourceFiles: (Array with: scriptName).
	(scriptName asLowercase endsWith: '.pr') 
		ifTrue:[self installProjectFrom: loader]
		ifFalse:[loader installSourceFiles].
! !


!ProjectLoading class methodsFor: 'as yet unclassified' stamp: 'jmv 12/20/2004 21:24'!
openName: aFileName stream: preStream fromDirectory: aDirectoryOrNil withProjectView: existingView
	"Reconstitute a Morph from the selected file, presumed to be represent a Morph saved via the SmartRefStream mechanism, and open it in an appropriate Morphic world."
	
 	| morphOrList proj trusted localDir projStream archive mgr projectsToBeDeleted baseChangeSet enterRestricted |
	(preStream isNil or: [preStream size = 0]) ifTrue: [
		ProgressNotification  signal: '9999 about to enter project'.		"the hard part is over"
		^self inform: 
'It looks like a problem occurred while
getting this project. It may be temporary,
so you may want to try again,' translated
	].
	ProgressNotification signal: '2:fileSizeDetermined ',preStream size printString.
	preStream isZipArchive 
		ifTrue:[	archive _ ZipArchive new readFrom: preStream.
				projStream _ self projectStreamFromArchive: archive]
		ifFalse:[projStream _ preStream].
	trusted _ SecurityManager default positionToSecureContentsOf: projStream.
	trusted ifFalse:
		[enterRestricted := (preStream isTypeHTTP or: [aFileName isNil])
			ifTrue: [Preferences securityChecksEnabled]
			ifFalse: [Preferences standaloneSecurityChecksEnabled].
		enterRestricted 
			ifTrue: [SecurityManager default enterRestrictedMode
				ifFalse:
					[preStream close.
					^ self]]].

	localDir _ Project squeakletDirectory.
	aFileName ifNotNil: [
		(aDirectoryOrNil isNil or: [aDirectoryOrNil pathName ~= localDir pathName]) ifTrue: [
			localDir deleteFileNamed: aFileName.
			(localDir fileNamed: aFileName) 
				nextPutAll: preStream contents;
				close.
		].
	].
	morphOrList _ projStream asUnZippedStream.
	preStream sleep.		"if ftp, let the connection close"
	ProgressNotification  signal: '3:unzipped'.
	ResourceCollector current: ResourceCollector new.
	baseChangeSet _ ChangeSet current.
	self useTempChangeSet.		"named zzTemp"
	"The actual reading happens here"
	[morphOrList _ morphOrList fileInObjectAndCode] ensure: [
				ChangeSet  newChanges: baseChangeSet].
	mgr _ ResourceManager new initializeFrom: ResourceCollector current.
	mgr registerUnloadedResources.
	archive ifNotNil:[mgr preLoadFromArchive: archive cacheName: aFileName].
	(preStream respondsTo: #close) ifTrue:[preStream close].
	ResourceCollector current: nil.
	ProgressNotification  signal: '4:filedIn'.
	ProgressNotification  signal: '9999 about to enter project'.		"the hard part is over"
	(morphOrList isKindOf: ImageSegment) ifTrue: [
		proj _ morphOrList arrayOfRoots 
			detect: [:mm | mm isKindOf: Project] 
			ifNone: [^self inform: 'No project found in this file'].
		proj resourceManager: mgr.
		"proj versionFrom: preStream."
		proj lastDirectory: aDirectoryOrNil.
		CurrentProjectRefactoring currentBeParentTo: proj.
		projectsToBeDeleted _ OrderedCollection new.
		existingView ifNil: [
			Smalltalk isMorphic ifTrue: [
				proj createViewIfAppropriate.
			] ifFalse: [
				ChangeSorter allChangeSets add: proj changeSet.
				ProjectView openAndEnter: proj.
				"Note: in MVC we get no further than the above"
			].
		] ifNotNil: [
			(existingView project isKindOf: DiskProxy) ifFalse: [
				existingView project changeSet name: ChangeSet defaultName.
				projectsToBeDeleted add: existingView project.
			].
			(existingView owner isSystemWindow) ifTrue: [
				existingView owner model: proj
			].
			existingView project: proj.
		].
		ChangeSorter allChangeSets add: proj changeSet.
		Project current projectParameters 
			at: #deleteWhenEnteringNewProject 
			ifPresent: [ :ignored | 
				projectsToBeDeleted add: Project current.
				Project current removeParameter: #deleteWhenEnteringNewProject.
			].
		projectsToBeDeleted isEmpty ifFalse: [
			proj projectParameters 
				at: #projectsToBeDeleted 
				put: projectsToBeDeleted.
		].
	
		proj world ifNotNil:
			[(proj world valueOfProperty: #soundAdditions) ifNotNilDo:
				[:additions | SampledSound assimilateSoundsFrom: additions]].

		^ ProjectEntryNotification signal: proj
	].

	(morphOrList isKindOf: PasteUpMorph) ifFalse:
		[^ self inform: 'This is not a PasteUpMorph or exported Project.' translated].
	(Project newMorphicOn: morphOrList) enter
! !


!ProjectViewMorph methodsFor: 'events' stamp: 'jmv 12/6/2004 21:43'!
showMenuForProjectView
	| menu selection |
	(menu _ CustomMenu new)
		add: 'enter this project'
		action: [^ self enter];
		
		add: 'ENTER ACTIVE'
		action: [self setProperty: #wasOpenedAsSubproject toValue: true.
			^ self enterAsActiveSubproject];
		
		add: 'PUBLISH (also saves a local copy)'
		action: [^ project storeOnServerShowProgressOn: self forgetURL: false];
		
		add: 'PUBLISH to a different server'
		action: [project forgetExistingURL.
			^ project storeOnServerShowProgressOn: self forgetURL: true];

		addLine;
		add: 'expunge this project'
		action: [^ self expungeProject].

	selection _ menu build startUpCenteredWithCaption: 'Project Named
' , '"' , project name , '"'.
	selection
		ifNil: [^ self].
	selection value! !


!RealEstateAgent class methodsFor: 'as yet unclassified' stamp: 'jmv 12/2/2004 22:44'!
assignCollapseFrameFor: aSSView 
	"Offer up a location along the left edge of the screen for a collapsed SSView. Make sure it doesn't overlap any other collapsed frames."

	| grid otherFrames topLeft viewBox collapsedFrame extent newFrame verticalBorderDistance top |
	grid _ 8.
	verticalBorderDistance _ 8.
	aSSView isMorph
		ifTrue: [otherFrames _ (SystemWindow windowsIn: aSSView world satisfying: [:w | w ~= aSSView])
						collect: [:w | w collapsedFrame]
						thenSelect: [:rect | rect notNil].
				viewBox _ aSSView world viewBox]
		ifFalse: [otherFrames _ ScheduledControllers scheduledWindowControllers
						collect: [:aController | aController view ~= aSSView ifTrue: [aController view collapsedFrame]]
						thenSelect: [:rect | rect notNil].
				viewBox _ Display boundingBox].
	collapsedFrame _ aSSView collapsedFrame.
	extent _ collapsedFrame notNil
				ifTrue: [collapsedFrame extent]
				ifFalse: [aSSView isMorph
					ifTrue: [aSSView getRawLabel width + aSSView labelWidgetAllowance @ (aSSView labelHeight + 2)]
					ifFalse: [(aSSView labelText extent x + 70) @ aSSView labelHeight
							min: aSSView labelDisplayBox extent]].
	collapsedFrame notNil
		ifTrue: [(otherFrames anySatisfy: [:f | collapsedFrame intersects: f])
				ifFalse: ["non overlapping"
					^ collapsedFrame]].
	top _ viewBox top + verticalBorderDistance.
	[topLeft _ viewBox left @ top.
	newFrame _ topLeft extent: extent.
	newFrame bottom <= (viewBox height - verticalBorderDistance)]
		whileTrue: 
			[(otherFrames anySatisfy: [:w | newFrame intersects: w])
				ifFalse: ["no overlap"
					^ newFrame].
			top _ top + grid].
	"If all else fails... (really to many wins here)"
	^ 0 @ 0 extent: extent! !

!RealEstateAgent class methodsFor: 'as yet unclassified' stamp: 'jmv 12/2/2004 22:44'!
assignCollapsePointFor: aSSView
	"Offer up a location along the left edge of the screen for a collapsed SSView.
	Make sure it doesn't overlap any other collapsed frames."

	| grid otherFrames y free topLeft viewBox |
	grid _ 24.  "should be mult of 8, since manual move is gridded by 8"
	aSSView isMorph
		ifTrue: [otherFrames _ (SystemWindow windowsIn: aSSView world satisfying: [:w | true])
					collect: [:w | w collapsedFrame]
					thenSelect: [:rect | rect notNil].
				viewBox _ aSSView world viewBox]
		ifFalse: [otherFrames _ ScheduledControllers scheduledWindowControllers
					collect: [:aController | aController view collapsedFrame]
					thenSelect: [:rect | rect notNil].
				viewBox _ Display boundingBox].
	y _ viewBox top.
	[(y _ y + grid) <= (viewBox height - grid)]
		whileTrue:
		[topLeft _ viewBox left@y.
		free _ true.
		otherFrames do: [:w | free _ free & (topLeft ~= w topLeft)].
		free ifTrue: [^ topLeft]].
	"If all else fails..."
	^ 0 @ 0! !

!RealEstateAgent class methodsFor: 'as yet unclassified' stamp: 'jmv 12/2/2004 22:44'!
strictlyStaggeredInitialFrameFor: aStandardSystemView initialExtent: initialExtent world: aWorld
	"This method implements a staggered window placement policy that I (di) like.
	Basically it provides for up to 4 windows, staggered from each of the 4 corners.
	The windows are staggered so that there will always be a corner visible."

	| allowedArea grid initialFrame otherFrames cornerSel corner delta putativeCorner free maxLevel |

	allowedArea _(self maximumUsableAreaInWorld: aWorld)
		insetBy: (self scrollBarSetback @ self screenTopSetback extent: 0@0).
	"Number to be staggered at each corner (less on small screens)"
	maxLevel _ allowedArea area > 300000 ifTrue: [3] ifFalse: [2].
	"Amount by which to stagger (less on small screens)"
	grid _ allowedArea area > 500000 ifTrue: [40] ifFalse: [20].
	initialFrame _ 0@0 extent: ((initialExtent
							"min: (allowedArea extent - (grid*(maxLevel+1*2) + (grid//2))))
							min: 600@400")).
	otherFrames _ Smalltalk isMorphic
		ifTrue: [(SystemWindow windowsIn: aWorld satisfying: [:w | w isCollapsed not])
					collect: [:w | w bounds]]
		ifFalse: [ScheduledControllers scheduledWindowControllers
				select: [:aController | aController view ~~ nil]
				thenCollect: [:aController | aController view isCollapsed
								ifTrue: [aController view expandedFrame]
								ifFalse: [aController view displayBox]]].
	0 to: maxLevel do:
		[:level | 
		1 to: 4 do:
			[:ci | cornerSel _ #(topLeft topRight bottomRight bottomLeft) at: ci.
			corner _ allowedArea perform: cornerSel.
			"The extra grid//2 in delta helps to keep title tabs distinct"
			delta _ (maxLevel-level*grid+(grid//2)) @ (level*grid).
			1 to: ci-1 do: [:i | delta _ delta rotateBy: #right centerAt: 0@0]. "slow way"
			putativeCorner _ corner + delta.
			free _ true.
			otherFrames do:
				[:w |
				free _ free & ((w perform: cornerSel) ~= putativeCorner)].
			free ifTrue:
				[^ (initialFrame align: (initialFrame perform: cornerSel)
								with: putativeCorner)
						 translatedAndSquishedToBeWithin: allowedArea]]].
	"If all else fails..."
	^ (self scrollBarSetback @ self screenTopSetback extent: initialFrame extent)
		translatedAndSquishedToBeWithin: allowedArea! !


!RecordingControlsMorph methodsFor: 'button commands' stamp: 'jmv 12/9/2004 22:23'!
done

	recorder stopRecording.
	self delete.
! !

!RecordingControlsMorph methodsFor: 'initialization' stamp: 'jmv 12/9/2004 22:23'!
addButtonRows

	| r |
	r _ AlignmentMorph newRow vResizing: #shrinkWrap.


	r addMorphBack: (self buttonName: 'Morph' translated action: #makeSoundMorph).
	r addMorphBack: (Morph new extent: 4@1; color: Color transparent).
	r addMorphBack: (self buttonName: 'Trim' translated action: #trim).
	r addMorphBack: (Morph new extent: 4@1; color: Color transparent).
	r addMorphBack: (self buttonName: 'Show' translated action: #show).
	self addMorphBack: r.

	r _ AlignmentMorph newRow vResizing: #shrinkWrap.
	r addMorphBack: (self buttonName: 'Record' translated action: #record).
	r addMorphBack: (Morph new extent: 4@1; color: Color transparent).
	r addMorphBack: (self buttonName: 'Stop' translated action: #stop).
	r addMorphBack: (Morph new extent: 4@1; color: Color transparent).
	r addMorphBack: (self buttonName: 'Play' translated action: #playback).
	r addMorphBack: self makeStatusLight.
	self addMorphBack: r.
! !


!ScreenController methodsFor: 'nested menus' stamp: 'jmv 12/1/2004 18:18'!
helpMenu 
	"Answer the help menu to be put up as a screen submenu"

	^ SelectionMenu labelList:
		#(	'keep this menu up'

			'about this system...'
			'update code from server'
			'preferences...'

			'command-key help'
			'font size summary'
			'useful expressions'
			'view graphical imports'
			'standard graphics library'),

			(Array with: (Preferences soundsEnabled
							ifFalse: ['turn sound on']
							ifTrue: ['turn sound off'])) ,

		#(	
			'set author initials...'
			'vm statistics'
			'space left')
		lines: #(1 4 6 11)
		selections: #(durableHelpMenu aboutThisSystem absorbUpdatesFromServer
editPreferences  openCommandKeyHelp fontSizeSummary openStandardWorkspace viewImageImports
standardGraphicsLibrary soundOnOrOff setAuthorInitials vmStatistics garbageCollect)
"
ScreenController new helpMenu startUp
"! !

!ScreenController methodsFor: 'nested menus' stamp: 'jmv 12/20/2004 21:35'!
openMenu
	^ SelectionMenu labelList:
		#(	'keep this menu up'

			'browser'
			'package browser'
			'method finder'
			'workspace'
			'file list'
			'file...'
			'transcript'

			'simple change sorter'
			'dual change sorter'

			'mvc project'
			'morphic project'
			)
		lines: #(1 9 11)
		selections: #(durableOpenMenu
openBrowser openPackageBrowser openSelectorBrowser openWorkspace openFileList openFile openTranscript
openSimpleChangeSorter openChangeManager
openProject  openMorphicProject  )
"
ScreenController  new openMenu startUp
"! !


!ServerDirectory class methodsFor: 'available servers' stamp: 'jmv 12/24/2004 15:08'!
resetLocalProjectDirectories
	LocalProjectDirectories _ nil! !

!ServerDirectory class methodsFor: 'server prefs' stamp: 'jmv 12/24/2004 15:09'!
fetchExternalSettingsIn: aDirectory
	"Scan for server configuration files"
	"ServerDirectory fetchExternalSettingsIn: (FileDirectory default directoryNamed: 'prefs')"

	| serverConfDir stream |
	(aDirectory directoryExists: self serverConfDirectoryName)
		ifFalse: [^self].
	self resetLocalProjectDirectories.
	serverConfDir _ aDirectory directoryNamed: self serverConfDirectoryName.
	serverConfDir fileNames do: [:fileName |
		stream _ serverConfDir readOnlyFileNamed: fileName.
		stream
			ifNotNil: [
				[self parseServerEntryFrom: stream] ifError: [:err :rcvr | ].
				stream close]]! !

!ServerDirectory class methodsFor: 'server prefs' stamp: 'jmv 12/24/2004 15:04'!
parseServerEntryFrom: stream
	
	| server type directory entries serverName |

	entries _ ExternalSettings parseServerEntryArgsFrom: stream.

	serverName _ entries at: 'name' ifAbsent: [^nil].
	directory _ entries at: 'directory' ifAbsent: [^nil].
	type _ entries at: 'type' ifAbsent: [^nil].
	type = 'file'
		ifTrue: [
			server _ self determineLocalServerDirectory: directory.
			^self addLocalProjectDirectory: server].
	type = 'bss'
		ifTrue: [server _ SuperSwikiServer new type: #http].
	type = 'http'
		ifTrue: [server _ HTTPServerDirectory new type: #ftp].
	type = 'ftp'
		ifTrue: [server _ ServerDirectory new type: #ftp].

	server directory: directory.
	entries at: 'server' ifPresent: [:value | server server: value].
	entries at: 'user' ifPresent: [:value | server user: value].
	entries at: 'group' ifPresent: [:value | server groupName: value].
	entries at: 'passwdseq' ifPresent: [:value | server passwordSequence: value asNumber].
	entries at: 'url' ifPresent: [:value | server altUrl: value].
	entries at: 'loaderUrl' ifPresent: [:value | server loaderUrl: value].
	entries at: 'acceptsUploads' ifPresent: [:value | server acceptsUploads: value asLowercase = 'true'].
	ServerDirectory addServer: server named: serverName.
! !

!ServerDirectory class methodsFor: 'server prefs' stamp: 'jmv 12/24/2004 15:09'!
releaseExternalSettings
	"Release for server configurations"
	"ServerDirectory releaseExternalSettings"

	Preferences externalServerDefsOnly
		ifTrue: [
			self resetLocalProjectDirectories.
			Servers _ Dictionary new]! !


!SimpleButtonMorph methodsFor: 'menu' stamp: 'jmv 12/6/2004 20:32'!
addCustomMenuItems: aCustomMenu hand: aHandMorph

	super addCustomMenuItems: aCustomMenu hand: aHandMorph.
	self addLabelItemsTo: aCustomMenu hand: aHandMorph.
			aCustomMenu add: 'change action selector' translated action: #setActionSelector.
			aCustomMenu add: 'change arguments' translated action: #setArguments.
			aCustomMenu add: 'change when to act' translated action: #setActWhen.
			aCustomMenu add: 'change target' action: #setTarget.
			((self world rootMorphsAt: aHandMorph targetOffset) size > 1) ifTrue:
				[aCustomMenu add: 'set target' translated action: #setTarget:].
! !


!SketchEditorMorph methodsFor: 'initialization' stamp: 'jmv 12/5/2004 17:00'!
initializeFor: aSketchMorph inBounds: boundsToUse pasteUpMorph: aPasteUpMorph
	| aPaintBox newPaintBoxBounds worldBounds requiredWidth newOrigin aPosition paintBoxFullBounds |

	aPaintBox _ self world paintBox.
	worldBounds _ self world bounds.
	requiredWidth _ aPaintBox width.

	aPosition _ boundsToUse topRight.

	newOrigin _ ((aPosition x  + requiredWidth <= worldBounds right) or: [Preferences unlimitedPaintArea])
			ifTrue:  "will fit to right of aPasteUpMorph"
				[aPosition]
			ifFalse:  "won't fit to right, try left"
				[boundsToUse topLeft - (requiredWidth @ 0)].
	paintBoxFullBounds _ aPaintBox maxBounds.
	paintBoxFullBounds _ (newOrigin - aPaintBox offsetFromMaxBounds) extent: 
					paintBoxFullBounds extent.
	newPaintBoxBounds _ paintBoxFullBounds translatedToBeWithin: worldBounds.
	

	self initializeFor: aSketchMorph inBounds: boundsToUse 
		pasteUpMorph: aPasteUpMorph 
		paintBoxPosition: newPaintBoxBounds origin + aPaintBox offsetFromMaxBounds.! !


!SketchMorph methodsFor: 'menu' stamp: 'jmv 12/2/2004 23:11'!
editDrawingIn: aPasteUpMorph forBackground: forBackground 
	| w bnds sketchEditor aWorld aPaintBox tfx |
	self world assureNotPaintingElse: [^self].
	w := aPasteUpMorph world.
	w prepareToPaint.
	w displayWorld.
	self visible: false.
	bnds := forBackground 
				ifTrue: [aPasteUpMorph boundsInWorld]
				ifFalse: 
					[bnds := self boundsInWorld expandBy: 60 @ 60.
					(aPasteUpMorph paintingBoundsAround: bnds center) merge: bnds]. 
	sketchEditor := SketchEditorMorph new.
	forBackground 
		ifTrue: [sketchEditor setProperty: #background toValue: true].
	w addMorphFront: sketchEditor.
	sketchEditor 
		initializeFor: self
		inBounds: bnds
		pasteUpMorph: aPasteUpMorph.
	sketchEditor afterNewPicDo: 
			[:aForm :aRect | 
			self visible: true.
			self form: aForm.
			tfx := aPasteUpMorph transformFrom: aPasteUpMorph world.
			self topRendererOrSelf position: (tfx globalPointToLocal: aRect origin).
			self rotationStyle: sketchEditor rotationStyle.
			self forwardDirection: sketchEditor forwardDirection.
			aWorld := self world.
			(aPaintBox := aWorld paintBox) ifNotNil: [aPaintBox delete].
			forBackground ifTrue: [self goBehind	"shouldn't be necessary"]]
		ifNoBits: 
			["If no bits drawn.  Must keep old pic.  Can't have no picture"

			self visible: true.
			aWorld := self currentWorld.
			"sometimes by now I'm no longer in a world myself, but we still need
				 to get ahold of the world so that we can deal with the palette"

				(aPaintBox := aWorld paintBox) ifNotNil: [aPaintBox delete]]! !


!SmalltalkImage methodsFor: 'image cleanup' stamp: 'jmv 12/31/2004 15:32'!
prepareReleaseImage
	"Perform various image cleanups in preparation for making a Squeak gamma release candidate image."
	"SmalltalkImage current prepareReleaseImage"
	
	| projectChangeSetNames |
	(self confirm: 'Are you sure you want to prepare a release image?
This will perform several irreversible cleanups on this image.')
		ifFalse: [^ self].

	Undeclared removeUnreferencedKeys.
	StandardScriptingSystem initialize.
	Preferences initialize.
	Preferences chooseInitialSettings.
	(Object classPool at: #DependentsFields) size > 1 ifTrue: [self error:'Still have dependents'].
	Undeclared isEmpty ifFalse: [self error:'Please clean out Undeclared'].

	Browser initialize.
	ScriptingSystem deletePrivateGraphics.  "?"
	
	"Delete all changesets except those currently used by existing projects."
	projectChangeSetNames _ Project allSubInstances collect: [:proj | proj changeSet name].
	ChangeSorter removeChangeSetsNamedSuchThat:
		[:cs | (projectChangeSetNames includes: cs) not].
	ChangeSet current clear.
	ChangeSet current name: 'Unnamed1'.
	Smalltalk garbageCollect.
	"Reinitialize DataStream; it may hold on to some zapped entitities"
	DataStream initialize.

	Smalltalk garbageCollect.
	ScheduledControllers _ nil.
	Smalltalk garbageCollect.
	
"	SMSqueakMap default purge."
	
	Behavior flushObsoleteSubclasses.
	Smalltalk garbageCollect; garbageCollect.
	Smalltalk obsoleteBehaviors isEmpty ifFalse:[self error:'Still have obsolete behaviors'].

	DataStream initialize.
	self fixObsoleteReferences.
	Smalltalk forgetDoIts.  "?"
	Smalltalk flushClassNameCache.  "?"
	3 timesRepeat: [
		Smalltalk garbageCollect.
		Symbol compactSymbolTable.
	].
! !


!SmartRefStream methodsFor: 'read write' stamp: 'jmv 12/2/2004 23:18'!
restoreClassInstVars
	"Install the values of the class instance variables of UniClasses
(i.e. scripts slotInfo).  classInstVars is ((#Player25 scripts slotInfo)
...).  Thank you Mark Wai for the bug fix."

	| normal aName newName newCls rList start |

	self flag: #bobconv.	


	self moreObjects ifFalse: [^ self]. 	"are no UniClasses with class inst vars"
	classInstVars _ super next.	"Array of arrays"
	normal _ Object class instSize.	"might give trouble if Player class superclass changes size"
	classInstVars do: [:list |
		aName _ (list at: 1) asSymbol.
		rList _ list.
		newName _ renamed at: aName ifAbsent: [aName].
		newCls _ Smalltalk at: newName
				ifAbsent: [self error: 'UniClass definition missing'].
		start _ list second = 'Update to read classPool' ifTrue: [4] ifFalse: [2].
		newCls class instSize = (normal + (rList size) - start + 1) ifFalse:
			[self error: 'UniClass superclass class has changed size'].
			"Need to install a conversion method mechanism"
		start = 4 ifTrue: [newCls instVarAt: normal - 1 "classPool" put: (list at: 3)].
		start to: rList size do: [:ii |
			newCls instVarAt: normal + ii - start + 1 put: (rList at: ii)]].
! !


!StandardScriptingSystem methodsFor: 'utilities' stamp: 'jmv 12/2/2004 23:18'!
spaceReclaimed
	"Reclaim space from the EToy system, and return the number of bytes reclaimed"
	"ScriptingSystem spaceReclaimed"

	| oldFree  |
	oldFree _ Smalltalk garbageCollect.
	ThumbnailMorph recursionReset.
	Smalltalk cleanOutUndeclared.
	Smalltalk reclaimDependents.
	^ Smalltalk garbageCollect - oldFree.! !


!StandardScriptingSystem class methodsFor: 'class initialization' stamp: 'jmv 12/1/2004 12:02'!
initialize
	"Initialize the scripting system.  Sometimes this method is vacuously changed just to get it in a changeset so that its invocation will occur as part of an update"

	(self environment at: #ScriptingSystem ifAbsent: [nil]) ifNil:
		[self environment at: #ScriptingSystem put: self new].

	ScriptingSystem
		initializeHelpStrings.

"StandardScriptingSystem initialize"! !


!StandardSystemView methodsFor: 'framing' stamp: 'jmv 12/20/2004 22:27'!
collapse
	"If the receiver is not already collapsed, change its view to be that of its 
	label only."

	self isCollapsed ifFalse:
			[model modelSleep.
			expandedViewport _ self viewport.
			savedSubViews _ subViews.
			self resetSubViews.
			labelText isNil ifTrue: [self label: nil.  bitsValid _ false.].
			self window: (self inverseDisplayTransform:
					((self labelDisplayBox topLeft extent: (labelText extent x + 70) @ self labelHeight)
						 intersect: self labelDisplayBox))]! !


!CodeHolder methodsFor: 'controls' stamp: 'jmv 12/8/2004 08:48'!
contentsSymbolQuints
	"Answer a list of quintuplets representing information on the alternative views available in the code pane
		first element:	the contentsSymbol used
		second element:	the selector to call when this item is chosen.
		third element:	the selector to call to obtain the wording of the menu item.
		fourth element:	the wording to represent this view
		fifth element:	balloon help
	A hypen indicates a need for a seperator line in a menu of such choices"

	^ #(
(source			togglePlainSource 			showingPlainSourceString	'source'		'the textual source code as writen')
(documentation	toggleShowDocumentation	showingDocumentationString	'documentation'		'the first comment in the method')
-
(prettyPrint		togglePrettyPrint 			prettyPrintString			'prettyPrint'			'the method source presented in a standard text format')
(colorPrint		toggleColorPrint				colorPrintString				'colorPrint'			'the method source in a standard text format with colors to distinguish structural parts') 
(altSyntax		toggleAltSyntax				showingAltSyntaxString		'altSyntax'			'alternative syntax')
-
(showDiffs		toggleRegularDiffing		showingRegularDiffsString	'showDiffs'				'the textual source diffed from its prior version')
(prettyDiffs		togglePrettyDiffing			showingPrettyDiffsString	'prettyDiffs'		'formatted textual source diffed from formatted form of prior version')
-
(decompile		toggleDecompile				showingDecompileString		'decompile'			'source code decompiled from byteCodes')
(byteCodes		toggleShowingByteCodes		showingByteCodesString		'byteCodes'			'the bytecodes that comprise the compiled method'))! !

!CodeHolder methodsFor: 'diffs' stamp: 'jmv 12/8/2004 08:52'!
toggleColorPrint
	"Toggle whether color-print is in effect in the code pane"

	self okToChange ifTrue:
		[self showingColorPrint
			ifTrue:
				[contentsSymbol _ #source]
			ifFalse:
				[contentsSymbol _ #colorPrint].
		self setContentsToForceRefetch.
		self contentsChanged]

! !

!CodeHolder methodsFor: 'diffs' stamp: 'jmv 12/8/2004 08:52'!
toggleDiffing
	"Toggle whether diffs should be shown in the code pane.  If any kind of diffs were being shown, stop showing diffs.  If no kind of diffs were being shown, start showing whatever kind of diffs are called for by default."

	| wasShowingDiffs |
	self okToChange ifTrue:
		[wasShowingDiffs _ self showingAnyKindOfDiffs.
		self showDiffs: wasShowingDiffs not.
		self setContentsToForceRefetch.
		self contentsChanged]

! !

!CodeHolder methodsFor: 'diffs' stamp: 'jmv 12/8/2004 08:53'!
togglePlainSource
	"Toggle whether plain source shown in the code pane"
	
	| wasShowingPlainSource |
	self okToChange ifTrue:
		[wasShowingPlainSource _ self showingPlainSource.
		wasShowingPlainSource
			ifTrue:
				[self showDocumentation: true]
			ifFalse:
				[contentsSymbol _ #source].
		self setContentsToForceRefetch.
		self changed: #contents]

! !

!CodeHolder methodsFor: 'diffs' stamp: 'jmv 12/8/2004 08:53'!
togglePrettyDiffing
	"Toggle whether pretty-diffing should be shown in the code pane"

	| wasShowingDiffs |
	self okToChange ifTrue:
		[wasShowingDiffs _ self showingPrettyDiffs.
		self showPrettyDiffs: wasShowingDiffs not.
		self setContentsToForceRefetch.
		self contentsChanged]

! !

!CodeHolder methodsFor: 'diffs' stamp: 'jmv 12/8/2004 08:53'!
togglePrettyPrint
	"Toggle whether pretty-print is in effectin the code pane"

	self okToChange ifTrue:
		[self showingPrettyPrint
			ifTrue:
				[contentsSymbol _ #source]
			ifFalse:
				[contentsSymbol _ #prettyPrint].
		self setContentsToForceRefetch.
		self contentsChanged]

! !

!CodeHolder methodsFor: 'diffs' stamp: 'jmv 12/8/2004 08:53'!
toggleRegularDiffing
	"Toggle whether regular-diffing should be shown in the code pane"

	| wasShowingDiffs |
	self okToChange ifTrue:
		[wasShowingDiffs _ self showingRegularDiffs.
		self showRegularDiffs: wasShowingDiffs not.
		self setContentsToForceRefetch.
		self contentsChanged]

! !

!CodeHolder methodsFor: 'misc' stamp: 'jmv 12/9/2004 22:27'!
refusesToAcceptCode
	"Answer whether receiver, given its current contentsSymbol, could accept code happily if asked to"

	^ (#(byteCodes documentation altSyntax) includes: self contentsSymbol)! !

!CodeHolder methodsFor: 'what to show' stamp: 'jmv 12/8/2004 08:52'!
toggleAltSyntax
	"Toggle the setting of the showingAltSyntax flag, unless there are unsubmitted edits that the user declines to discard"

	| wasShowing |
	self okToChange ifTrue:
		[wasShowing _ self showingAltSyntax.
		self showAltSyntax: wasShowing not.
		self setContentsToForceRefetch.
		self contentsChanged]

! !

!CodeHolder methodsFor: 'what to show' stamp: 'jmv 12/8/2004 08:52'!
toggleDecompile
	"Toggle the setting of the showingDecompile flag, unless there are unsubmitted edits that the user declines to discard"

	| wasShowing |
	self okToChange ifTrue:
		[wasShowing _ self showingDecompile.
		self showDecompile: wasShowing not.
		self setContentsToForceRefetch.
		self contentsChanged]

! !

!CodeHolder methodsFor: 'what to show' stamp: 'jmv 12/8/2004 08:53'!
toggleShowDocumentation
	"Toggle the setting of the showingDocumentation flag, unless there are unsubmitted edits that the user declines to discard"

	| wasShowing |
	self okToChange ifTrue:
		[wasShowing _ self showingDocumentation.
		self showDocumentation: wasShowing not.
		self setContentsToForceRefetch.
		self contentsChanged]

! !

!CodeHolder methodsFor: 'what to show' stamp: 'jmv 12/8/2004 08:53'!
toggleShowingByteCodes
	"Toggle whether the receiver is showing bytecodes"

	self showByteCodes: self showingByteCodes not.
	self setContentsToForceRefetch.
	self contentsChanged! !


!Browser methodsFor: 'class functions' stamp: 'jmv 12/5/2004 16:03'!
shiftedClassListMenu: aMenu
	"Set up the menu to apply to the receiver's class list when the shift key is down"

	^ aMenu addList: #(
			-
			('unsent methods'			browseUnusedMethods	'browse all methods defined by this class that have no senders')
			('unreferenced inst vars'	showUnreferencedInstVars	'show a list of all instance variables that are not referenced in methods')
			('unreferenced class vars'	showUnreferencedClassVars	'show a list of all class variables that are not referenced in methods')
			('subclass template'			makeNewSubclass		'put a template into the code pane for defining of a subclass of this class')
			-
			('sample instance'			makeSampleInstance		'give me a sample instance of this class, if possible')
			('inspect instances'			inspectInstances			'open an inspector on all the extant instances of this class')
			('inspect subinstances'		inspectSubInstances		'open an inspector on all the extant instances of this class and of all of its subclasses')
			-
			('add all meths to current chgs'		addAllMethodsToCurrentChangeSet
																'place all the methods defined by this class into the current change set')
			('create inst var accessors'	createInstVarAccessors	'compile instance-variable access methods for any instance variables that do not yet have them')
			-
			('more...'					offerUnshiftedClassListMenu	'return to the standard class-list menu'))! !

!Browser methodsFor: 'message functions' stamp: 'jmv 12/6/2004 09:28'!
messageListMenu: aMenu shifted: shifted
	"Answer the message-list menu"
	"Changed by emm to include menu-item for breakpoints"

	shifted ifTrue: [^ self shiftedMessageListMenu: aMenu].

	aMenu addList:#(
			('what to show...'			offerWhatToShowMenu)
                	('toggle break on entry'		toggleBreakOnEntry)
            		-
			('browse full (b)' 			browseMethodFull)
			('browse hierarchy (h)'			classHierarchy)
			('browse method (O)'			openSingleMessageBrowser)
			('browse protocol (p)'			browseFullProtocol)
			-
			('fileOut'				fileOutMessage)
			('printOut'				printOutMessage)
			-
			('senders of... (n)'			browseSendersOfMessages)
			('implementors of... (m)'		browseMessages)
			('inheritance (i)'			methodHierarchy)
			('versions (v)'				browseVersions)
			-
			('inst var refs...'			browseInstVarRefs)
			('inst var defs...'			browseInstVarDefs)
			('class var refs...'			browseClassVarRefs)
			('class variables'			browseClassVariables)
			('class refs (N)'			browseClassRefs)
			-
			('remove method (x)'			removeMessage)
			-
			('more...'				shiftedYellowButtonActivity)).
	^ aMenu
! !

!Browser methodsFor: 'message functions' stamp: 'jmv 12/6/2004 20:39'!
shiftedMessageListMenu: aMenu
	"Fill aMenu with the items appropriate when the shift key is held down"

	Smalltalk isMorphic ifTrue: [aMenu addStayUpItem].
	aMenu addList: #(
		('toggle diffing (D)'						toggleDiffing)
		('implementors of sent messages'			browseAllMessages)
		-
		('local senders of...'						browseLocalSendersOfMessages)
		('local implementors of...'				browseLocalImplementors)
		-
		('spawn sub-protocol'					spawnProtocol)
		('spawn full protocol'					spawnFullProtocol)
		-
		('sample instance'						makeSampleInstance)
		('inspect instances'						inspectInstances)
		('inspect subinstances'					inspectSubInstances)).

	self addExtraShiftedItemsTo: aMenu.
	aMenu addList: #(
		-
		('change category...'					changeCategory)).

	self canShowMultipleMessageCategories ifTrue: [aMenu addList:
		 #(('show category (C)'						showHomeCategory))].
	aMenu addList: #(
		-
		('change sets with this method'			findMethodInChangeSets)
		('revert to previous version'				revertToPreviousVersion)
		('remove from current change set'		removeFromCurrentChanges)
		('revert & remove from changes'		revertAndForget)
		('add to current change set'				adoptMessageInCurrentChangeset)
		('copy up or copy down...'				copyUpOrCopyDown)
		-
		('more...' 								unshiftedYellowButtonActivity)).
	^ aMenu
! !


!Browser class methodsFor: 'class initialization' stamp: 'jmv 12/1/2004 12:01'!
initialize
	"Browser initialize"

	RecentClasses := OrderedCollection new.! !


!ChangeSorter methodsFor: 'message list' stamp: 'jmv 12/6/2004 20:39'!
shiftedMessageMenu: aMenu
	"Arm the menu so that it holds items appropriate to the message-list while the shift key is down.  Answer the menu."

	^ aMenu addList: #(
		-
		('toggle diffing (D)'					toggleDiffing)
		('implementors of sent messages'		browseAllMessages)
		('change category...'				changeCategory)
			-
		('sample instance'					makeSampleInstance)
		('inspect instances'					inspectInstances)
		('inspect subinstances'				inspectSubInstances)
		-
		('change sets with this method'		findMethodInChangeSets)
		('revert to previous version'			revertToPreviousVersion)
		('revert & remove from changes'	revertAndForget)
		-
		('more...'							unshiftedYellowButtonActivity))! !


!ChangeSorter class methodsFor: 'class initialization' stamp: 'jmv 12/1/2004 12:01'!
initialize
	"Initialize the class variables"

	AllChangeSets == nil ifTrue:
		[AllChangeSets _ OrderedCollection new].
	self gatherChangeSets.
	ChangeSetCategories ifNil:
		[self initializeChangeSetCategories].
	RecentUpdateMarker _ 0.

	"ChangeSorter initialize"

	FileList registerFileReader: self.
! !

!ChangeSorter class methodsFor: 'class initialization' stamp: 'jmv 12/2/2004 22:34'!
unload
	"Unload the receiver from global registries"

	self environment at: #FileList ifPresent: [:cl |
	cl unregisterFileReader: self]! !


!Debugger methodsFor: 'initialize' stamp: 'jmv 12/24/2004 14:53'!
preDebugButtonQuads

	^
	 #(('Proceed'		proceed 	blue 	'continue execution' )
		('Abandon'		abandon 	black 	'abandon this execution by closing this window')
		('Debug'		debug 		red 		'bring up a debugger'))! !

!Debugger methodsFor: 'initialize' stamp: 'jmv 12/24/2004 14:53'!
preDebugNotifierContentsFrom: messageString
	^ messageString! !

!Debugger methodsFor: 'context stack menu' stamp: 'jmv 12/24/2004 14:53'!
buildMorphicNotifierLabelled: label message: messageString
	| notifyPane window contentTop extentToUse |
	self expandStack.
	window _ (PreDebugWindow labelled: label) model: self.

	contentTop _ 0.2.
	extentToUse _ 450 @ 156. "nice and wide to show plenty of the error msg"
	window addMorph: (self buttonRowForPreDebugWindow: window)
				frame: (0@0 corner: 1 @ contentTop).

	messageString notNil
		ifFalse:
			[notifyPane _ PluggableListMorph on: self list: #contextStackList
				selected: #contextStackIndex changeSelected: #debugAt:
				menu: nil keystroke: nil]
		ifTrue:
			[notifyPane _ PluggableTextMorph on: self text: nil accept: nil
				readSelection: nil menu: #debugProceedMenu:.
			notifyPane editString: (self preDebugNotifierContentsFrom: messageString);
				askBeforeDiscardingEdits: false].

	window addMorph: notifyPane frame: (0@contentTop corner: 1@1).
	"window deleteCloseBox.
		chickened out by commenting the above line out, sw 8/14/2000 12:54"
	window setBalloonTextForCloseBox.

	^ window openInWorldExtent: extentToUse! !


!FileList2 methodsFor: 'volume list and pattern' stamp: 'jmv 12/24/2004 14:50'!
listForPattern: pat
	"Make the list be those file names which match the pattern."

	| sizePad newList entries |
	directory ifNil: [^#()].
	entries _ directory entries.
	(fileSelectionBlock isKindOf: MessageSend) ifTrue: [
		fileSelectionBlock arguments: {entries}.
		newList _ fileSelectionBlock value.
		fileSelectionBlock arguments: #().
	] ifFalse: [
		newList _ entries select: [:entry | fileSelectionBlock value: entry value: pat].
	].
	newList _ newList asSortedCollection: self sortBlock.
	sizePad _ (newList inject: 0 into: [:mx :entry | mx max: (entry at: 5)])
					asStringWithCommas size - 1.
	newList _ newList collect: [ :e | self fileNameFormattedFrom: e sizePad: sizePad ].
	^ newList asArray! !


!FileList2 class methodsFor: 'preferences' stamp: 'jmv 12/2/2004 22:38'!
useFileList2preferenceChanged
	self toBeDeletedJMV! !


!Inspector methodsFor: 'menu commands' stamp: 'jmv 12/1/2004 12:25'!
fieldListMenu: aMenu
	"Arm the supplied menu with items for the field-list of the receiver"

	Smalltalk isMorphic ifTrue:
		[aMenu addStayUpItemSpecial].

	aMenu addList: #(
		('inspect (i)'						inspectSelection)
		('explore (I)'						exploreSelection)).

	self addCollectionItemsTo: aMenu.

	aMenu addList: #(
		-
		('method refs to this inst var'		referencesToSelection)
		('methods storing into this inst var'	defsOfSelection)
		('objects pointing to this value'		objectReferencesToSelection)
		('chase pointers'					chasePointers)
		-
		('browse full (b)'					browseMethodFull)
		('browse class'						browseClass)
		('browse hierarchy (h)'				classHierarchy)
		('browse protocol (p)'				browseFullProtocol)
		-
		('inst var refs...'					browseInstVarRefs)
		('inst var defs...'					browseInstVarDefs)
		('class var refs...'					classVarRefs)
		('class variables'					browseClassVariables)
		('class refs (N)'						browseClassRefs)
		-
		('copy name (c)'					copyName)		
		('basic inspect'						inspectBasic)).

	^ aMenu! !

!Inspector methodsFor: 'menu commands' stamp: 'jmv 12/1/2004 12:26'!
inspectorKey: aChar from: view
	"Respond to a Command key issued while the cursor is over my field list"

	aChar == $i ifTrue: [^ self selection inspect].
	aChar == $I ifTrue: [^ self selection explore].
	aChar == $b ifTrue:	[^ self browseMethodFull].
	aChar == $h ifTrue:	[^ self classHierarchy].
	aChar == $c ifTrue: [^ self copyName].
	aChar == $p ifTrue: [^ self browseFullProtocol].
	aChar == $N ifTrue: [^ self browseClassRefs].

	^ self arrowKey: aChar from: view! !


!Lexicon methodsFor: 'control buttons' stamp: 'jmv 12/9/2004 22:28'!
customButtonSpecs
	"Answer a triplet defining buttons, in the format:

			button label
			selector to send
			help message"

	^ #(
	('follow'			seeAlso							'view a method I implement that is called by this method')
	('find'				obtainNewSearchString			'find methods by name search')
	('sent...'			setSendersSearch				'view the methods I implement that send a given message')

	('<'					navigateToPreviousMethod 		'view the previous active method')
	('>'					navigateToNextMethod 			'view the next active method')
	('-'					removeFromSelectorsVisited		'remove this method from my active list'))! !


!InstanceBrowser methodsFor: 'menu commands' stamp: 'jmv 12/1/2004 12:37'!
offerMenu
	"Offer a menu to the user, in response to the hitting of the menu button on the tool pane"

	| aMenu |
	aMenu _ MenuMorph new defaultTarget: self.
	aMenu title: 'Messages of ', objectViewed nameForViewer.
	aMenu addStayUpItem.
	aMenu addList: #(
		('vocabulary...' 			chooseVocabulary)
		('what to show...'			offerWhatToShowMenu)
		-
		('inst var refs (here)'		setLocalInstVarRefs)
		('inst var defs (here)'		setLocalInstVarDefs)
		('class var refs (here)'		setLocalClassVarRefs)
		-

		('navigate to a sender...' 	navigateToASender)
		('recent...' 					navigateToRecentMethod)
		('show methods in current change set'
									showMethodsInCurrentChangeSet)
		('show methods with initials...'
									showMethodsWithInitials)
		-
		"('toggle search pane' 		toggleSearch)"

		-
		-
		('browse full (b)' 			browseMethodFull)
		('browse hierarchy (h)'		classHierarchy)
		('browse method (O)'		openSingleMessageBrowser)
		('browse protocol (p)'		browseFullProtocol)
		-
		('fileOut'					fileOutMessage)
		('printOut'					printOutMessage)
		-
		('senders of... (n)'			browseSendersOfMessages)
		('implementors of... (m)'		browseMessages)
		('versions (v)' 				browseVersions)
		('inheritance (i)'			methodHierarchy)
		-
		('inst var refs' 				browseInstVarRefs)
		('inst var defs' 				browseInstVarDefs)
		('class var refs' 			browseClassVarRefs)
		-
		('more...'					shiftedYellowButtonActivity)).

	aMenu popUpInWorld: ActiveWorld! !


!MessageNames class methodsFor: 'class initialization' stamp: 'jmv 12/2/2004 22:34'!
unload
	"Unload the receiver from global registries"

	self environment at: #FileList ifPresent: [:cl |
	cl unregisterFileReader: self]! !


!MethodHolder methodsFor: 'menu' stamp: 'jmv 12/6/2004 20:35'!
doItReceiver
	"If there is an instance associated with me, answer it, for true mapping of self.  If not, then do what other code-bearing tools do, viz. give access to the class vars."

	^ self selectedClass ifNil: [FakeClassPool new]! !


!SystemDictionary methodsFor: 'shrinking' stamp: 'jmv 12/2/2004 22:45'!
discardMorphic
	"Discard Morphic.
Updated for 2.8 TPR"

   "Smalltalk discardMorphic"

	| subs |
	"Check that we are in an MVC Project and that there are no Morphic Projects
		or WorldMorphViews."
	Smalltalk discardFlash.
	Smalltalk discardTrueType.
	subs _ OrderedCollection new.
	Morph allSubclassesWithLevelDo: [:c :i | subs addFirst: c]
		startingLevel: 0.
	subs do: [:c | c removeFromSystem].
	Smalltalk removeClassNamed: #CornerRounder.
	Smalltalk removeKey: #BalloonEngineConstants ifAbsent: [].
	SystemOrganization removeCategoriesMatching: 'Balloon-*'.
	SystemOrganization removeCategoriesMatching: 'Morphic-*'.
	SystemOrganization removeSystemCategory: 'Graphics-Transformations'.
	SystemOrganization removeSystemCategory: 'ST80-Morphic'.
	ScriptingSystem _ nil.
! !

!SystemDictionary methodsFor: 'shrinking' stamp: 'jmv 12/6/2004 09:54'!
discardSoundSynthesis
	"Discard the sound synthesis facilities, and the methods and classes that use it. This also discards MIDI."

	Smalltalk discardMIDI.
	Smalltalk discardSpeech.
	SystemOrganization removeCategoriesMatching: 'Sound-Interface'.
	Smalltalk at: #GraphMorph ifPresent: [:graphMorph |
		#(playOnce readDataFromFile)
			do: [:sel | graphMorph removeSelector: sel]].
	SystemOrganization removeCategoriesMatching: 'Sound-Synthesis'.
	SystemOrganization removeCategoriesMatching: 'Sound-Scores'.
! !

!SystemDictionary methodsFor: 'shrinking' stamp: 'jmv 12/31/2004 15:32'!
removeNormalCruft 
	"Remove various graphics, uniclasses, references.   Caution: see comment at bottom of method"

	"Smalltalk removeNormalCruft"
	
	ScriptingSystem stripGraphicsForExternalRelease.
	ScriptingSystem spaceReclaimed.
	Smalltalk classNames do:
		[:cName | #( 'Player' 'CardPlayer' 'Component' 'WonderlandActor' 'MorphicModel' 'PlayWithMe') do:
			[:superName | ((cName ~= superName and: [cName beginsWith: superName])
				and: [(cName allButFirst: superName size) allSatisfy: [:ch | ch isDigit]])
				ifTrue: [Smalltalk removeClassNamed: cName]]].
	Smalltalk at: #Wonderland ifPresent:[:cls | cls removeActorPrototypesFromSystem].
	ChangeSet current clear

"Caution: if any worlds in the image happen to have uniclass players associated with them, running this method would likely compromise their functioning and could cause errors, especially if the uniclass player of the current world had any scripts set to ticking.  If that happens to you somehow, you will probably want to find a way to reset the offending world's player to be an UnscriptedCardPlayer, or perhaps nil"
! !


!SystemNavigation methodsFor: 'query' stamp: 'jmv 12/20/2004 22:16'!
unimplemented
	"Answer an Array of each message that is sent by an expression in a method but is not implemented by any object in the system."

	| all unimplemented entry |
	all _ IdentitySet new: Symbol instanceCount * 2.
	Cursor wait showWhile: 
		[self allBehaviorsDo: [:cl | cl selectorsDo: [:aSelector | all add: aSelector]]].

	unimplemented _ IdentityDictionary new.
	Cursor execute showWhile: [
		self allBehaviorsDo: [:cl |
			 cl selectorsDo: [:sel |
				(cl compiledMethodAt: sel) messages do: [:m |
					(all includes: m) ifFalse: [
						entry _ unimplemented at: m ifAbsent: [Array new].
						entry _ entry copyWith: (cl name, '>', sel).
						unimplemented at: m put: entry]]]]].

	"remove some clutter from the result:"
	#(DoItIn: primitiveFail diffedVersionContents uniformWindowColors macOptionKeyAllowed)
		do: [:sel | unimplemented removeKey: sel ifAbsent: []].

	"these messages are not sent when running on the Zaurus:"
	#(channelData defaultAALevel: from:title: fromWaveFileNamed: imageFormOfSize:forFrame:
invokeAt:in: loadedFrames originalSamplingRate printInstructionsOn: processFile
readFrom:mergeIfStereo:skipDataChunk: samples samples:samplingRate: samplesRemaining
storeAIFFSamples:samplingRate:on:)
		do: [:sel | unimplemented removeKey: sel ifAbsent: []].

	^ unimplemented
! !


!SystemWindow methodsFor: 'menu' stamp: 'jmv 12/2/2004 22:46'!
fullScreen
	"Zoom Window to Full World size with possible DeskMargins"
		"SystemWindow fullScreen"
	
	| left right possibleBounds |
	left _ right _ 0.
	self paneMorphs
		do: [:pane | ((pane isKindOf: ScrollPane)
					and: [pane retractableScrollBar])
				ifTrue: [pane scrollBarOnLeft
						ifTrue: [left _ left max: pane scrollBarThickness]
						ifFalse: [right _ right max: pane scrollBarThickness]]].
	possibleBounds _ (RealEstateAgent maximumUsableAreaInWorld: self world)
				insetBy: (left @ 0 corner: right @ 0).
	Preferences fullScreenLeavesDeskMargins
		ifTrue: [possibleBounds _ possibleBounds insetBy: 22].
	self bounds: possibleBounds! !

!SystemWindow methodsFor: 'menu' stamp: 'jmv 12/2/2004 22:46'!
fullScreenMaximumExtent
	"Zoom Window to Full World size with possible DeskMargins
	obey the maximum extent rules"
	
	| left right possibleBounds |
	left _ right _ 0.
	self paneMorphs
		do: [:pane | ((pane isKindOf: ScrollPane)
					and: [pane retractableScrollBar])
				ifTrue: [pane scrollBarOnLeft
						ifTrue: [left _ left max: pane scrollBarThickness]
						ifFalse: [right _ right max: pane scrollBarThickness]]].
	possibleBounds _ self worldBounds
				insetBy: (left @ 0 corner: right @ 0).

	self maximumExtent ifNotNil:
		[possibleBounds _ possibleBounds origin extent: ( self maximumExtent min: ( possibleBounds extent ))].
	Preferences fullScreenLeavesDeskMargins
		ifTrue: [possibleBounds _ possibleBounds insetBy: 22].
	self bounds: possibleBounds! !

!SystemWindow methodsFor: 'open/close' stamp: 'jmv 12/20/2004 21:40'!
openInWorldExtent: extent
	"This msg and its callees result in the window being activeOnlyOnTop"

	Smalltalk isMorphic ifFalse: [^ self halt openInMVCExtent: extent].
	self openInWorld: self currentWorld extent: extent! !


!ArchiveViewer class methodsFor: 'parts bin' stamp: 'jmv 12/6/2004 20:57'!
descriptionForPartsBin

	^ self partName: 'Zip Tool'
		categories: #(Tools)
		documentation: 'A viewer and editor for Zip archive files'! !


!TTSampleFontMorph methodsFor: 'initialization' stamp: 'jmv 12/20/2004 21:38'!
openInWorld
	Smalltalk isMorphic ifFalse: [^ self halt openInMVC].
	HandMorph attach: self! !

!TTSampleFontMorph methodsFor: 'initialize' stamp: 'jmv 12/20/2004 21:37'!
open
	Smalltalk isMorphic 
		ifTrue:[self openInWorld]
		ifFalse:[self halt openInMVC]! !


!TestRunner class methodsFor: 'class initialization' stamp: 'jmv 12/1/2004 12:02'!
initialize
	"TestRunner initialize"
	(Preferences windowColorFor: #TestRunner) = Color white
		ifTrue: [ Preferences setWindowColorFor: #TestRunner to: (Color colorFrom: self windowColorSpecification pastelColor) ].
	(TheWorldMenu respondsTo: #registerOpenCommand:) ifTrue: [
		TheWorldMenu unregisterOpenCommand: 'Test Runner'.
		TheWorldMenu registerOpenCommand: {'SUnit Test Runner'. {self. #open}}].
! !

!TestRunner class methodsFor: 'class initialization' stamp: 'jmv 12/2/2004 22:35'!
unload
	 (TheWorldMenu respondsTo: #registerOpenCommand:)
         ifTrue: [TheWorldMenu unregisterOpenCommand: 'SUnit Test Runner']
! !


!TextMorph methodsFor: 'event handling' stamp: 'jmv 12/8/2004 09:44'!
wouldAcceptKeyboardFocusUponTab
	"Answer whether the receiver might accept keyboard focus if tab were hit in some container playfield"

	^ self isLocked not! !

!TextMorph methodsFor: 'events-processing' stamp: 'jmv 12/5/2004 16:15'!
handleKeystroke: anEvent
	"System level event handling."

	| pasteUp |
	anEvent wasHandled ifTrue:[^self].
	(self handlesKeyboard: anEvent) ifFalse:	[^ self].
	anEvent wasHandled: true.
	anEvent keyCharacter = Character tab ifTrue:
		["Allow passing through text morph inside pasteups"
		(self wouldAcceptKeyboardFocusUponTab and:
				[(pasteUp _ self pasteUpMorphHandlingTabAmongFields) notNil])
			ifTrue:["^ pasteUp tabHitWithEvent: anEvent"]].
	self keyStroke: anEvent! !

!TextMorph methodsFor: 'menu' stamp: 'jmv 12/19/2004 09:36'!
addCustomMenuItems: aCustomMenu hand: aHandMorph
	"Add text-related menu items to the menu"

	| outer |
	super addCustomMenuItems: aCustomMenu hand: aHandMorph.
	aCustomMenu addUpdating: #autoFitString target: self action: #autoFitOnOff.
	aCustomMenu addUpdating: #wrapString target: self action: #wrapOnOff.
	aCustomMenu add: 'text margins...' translated action: #changeMargins:.
	aCustomMenu add: 'add predecessor' translated action: #addPredecessor:.
	aCustomMenu add: 'add successor' translated action: #addSuccessor:.
	(Preferences noviceMode or: [Preferences simpleMenus])
		ifFalse:
			[aCustomMenu add: 'code pane menu...' translated action: #yellowButtonActivity.
			aCustomMenu add: 'code pane shift menu....' translated action: #shiftedYellowButtonActivity].

	outer _ self owner.
	((outer isKindOf: PolygonMorph) and: [outer isOpen])
		ifTrue:
			[container isNil
				ifTrue: [aCustomMenu add: 'follow owner''s curve' translated action: #followCurve]
				ifFalse: [aCustomMenu add: 'reverse direction' translated action: #reverseCurveDirection.
						aCustomMenu add: 'set baseline' translated action: #setCurveBaseline:]]
		ifFalse:
			[(container isNil or: [container fillsOwner not])
				ifTrue: [aCustomMenu add: 'fill owner''s shape' translated action: #fillingOnOff]
				ifFalse: [aCustomMenu add: 'rectangular bounds' translated action: #fillingOnOff].
			(container isNil or: [container avoidsOcclusions not])
				ifTrue: [aCustomMenu add: 'avoid occlusions' translated action: #occlusionsOnOff]
				ifFalse: [aCustomMenu add: 'ignore occlusions' translated action: #occlusionsOnOff]]

! !

!TextMorph methodsFor: 'menu' stamp: 'jmv 12/2/2004 23:27'!
changeMargins: evt
	| handle origin aHand newMargin |
	aHand _ evt ifNil: [self primaryHand] ifNotNil: [evt hand].
	origin _ aHand position.
	handle _ HandleMorph new
		forEachPointDo:
			[:newPoint | handle removeAllMorphs.
			handle addMorph:
				(LineMorph from: origin to: newPoint color: Color black width: 1).
			newMargin _ (newPoint - origin max: 0@0) // 5.
			self margins: newMargin]
		lastPointDo:
			[:newPoint | handle deleteBalloon.
			self halo ifNotNilDo: [:halo | halo addHandles].
			].
	aHand attachMorph: handle.
	handle setProperty: #helpAtCenter toValue: true.
	handle showBalloon:
'Move cursor down and to the right
to increase margin inset.
Click when done.' hand: evt hand.
	handle startStepping! !


!TextMorph class methodsFor: 'class initialization' stamp: 'jmv 12/1/2004 12:03'!
initialize	"TextMorph initialize"
	
	"Initialize constants shared by classes associated with text display."

	CaretForm _ (ColorForm extent: 16@5
					fromArray: #(2r001100e26 2r001100e26 2r011110e26 2r111111e26 2r110011e26)
					offset: -2@0)
					colors: (Array with: Color transparent with: Preferences textHighlightColor).
! !


!ClipboardMorph class methodsFor: 'parts bin' stamp: 'jmv 12/6/2004 20:57'!
descriptionForPartsBin
	^ self partName:	'Clipboard'
		categories:		#('Useful')
		documentation:	'This object will always show whatever is on the text clipboard'! !


!TextMorphEditor methodsFor: 'accessing' stamp: 'jmv 12/6/2004 20:31'!
setSearch: aString
	"Set the FindText and ChangeText to seek aString; except if already seeking aString, leave ChangeText alone so again will repeat last replacement."

	FindText string = aString
		ifFalse: [FindText _ ChangeText _ aString asText]! !

!TextMorphEditor methodsFor: 'private' stamp: 'jmv 12/6/2004 20:31'!
againOrSame: bool 
	super againOrSame: bool.
	(morph respondsTo: #editView) 
		ifTrue: [morph editView selectionInterval: self selectionInterval]! !


!TextSqkPageLink methodsFor: 'as yet unclassified' stamp: 'jmv 12/6/2004 09:48'!
actOnClickFor: textMorph
	"I represent a link to either a SqueakPage in a BookMorph, or a regular url"

	| |
	((url endsWith: '.bo') or: [url endsWith: '.sp']) ifFalse: [
		^ super actOnClickFor: textMorph].
	^ true! !


!TheWorldMenu methodsFor: 'commands' stamp: 'jmv 12/5/2004 16:42'!
worldMenuHelp
	| aList aMenu cnts explanation |
	"self currentWorld primaryHand worldMenuHelp"

	aList _ OrderedCollection new.
	#(helpMenu changesMenu openMenu debugMenu projectMenu windowsMenu appearanceMenu) 
		with:
	#('help' 'changes' 'open' 'debug' 'projects' 'windows' 'appearance' ) do:
		[:sel :title | aMenu _ self perform: sel.
			aMenu items do:
				[:it | (((cnts _ it contents) = 'keep this menu up') or: [cnts isEmpty])
					ifFalse: [aList add: (cnts, ' - ', title translated)]]].
	aList _ aList asSortedCollection: [:a :b | a asLowercase < b asLowercase].

	explanation _ String streamContents: [:aStream | aList do:
		[:anItem | aStream nextPutAll: anItem; cr]].

	(StringHolder new contents: explanation)
		openLabel: 'Where in the world menu is...' translated! !

!TheWorldMenu methodsFor: 'construction' stamp: 'jmv 12/19/2004 09:25'!
appearanceMenu
	"Build the appearance menu for the world."
	| screenCtrl |

	screenCtrl _ ScreenController new.
	^self fillIn: (self menu: 'appearance...') from: {

		{'window colors...' . { Preferences . #windowSpecificationPanel} . 'Lets you specify colors for standard system windows.'}.
		{'system fonts...' . { self . #standardFontDo} . 'Choose the standard fonts to use for code, lists, menus, window titles, etc.'}.
		{'text highlight color...' . { Preferences . #chooseTextHighlightColor} . 'Choose which color should be used for text highlighting in Morphic.'}.
		{'insertion point color...' . { Preferences . #chooseInsertionPointColor} . 'Choose which color to use for the text insertion point in Morphic.'}.
		{'keyboard focus color' . { Preferences . #chooseKeyboardFocusColor} . 'Choose which color to use for highlighting which pane has the keyboard focus'}.
		nil.
		{#menuColorString . { Preferences . #toggleMenuColorPolicy} . 'Governs whether menu colors should be derived from the desktop color.'}.
		{#roundedCornersString . { Preferences . #toggleRoundedCorners} . 'Governs whether morphic windows and menus should have rounded corners.'}.
		nil.
		{'full screen on' . { screenCtrl . #fullScreenOn} . 'puts you in full-screen mode, if not already there.'}.
		{'full screen off' . { screenCtrl . #fullScreenOff} . 'if in full-screen mode, takes you out of it.'}.
		nil.
		{'set display depth...' . {self. #setDisplayDepth} . 'choose how many bits per pixel.'}.
		{'set desktop color...' . {self. #changeBackgroundColor} . 'choose a uniform color to use as desktop background.'}.
		{'set gradient color...' . {self. #setGradientColor} . 'choose second color to use as gradient for desktop background.'}.
		{'use texture background' . { #myWorld . #setStandardTexture} . 'apply a graph-paper-like texture background to the desktop.'}.
	}! !

!TheWorldMenu methodsFor: 'construction' stamp: 'jmv 12/6/2004 20:37'!
buildWorldMenu
	"Build the menu that is put up when the screen-desktop is clicked on"

	| menu |
	menu _ MenuMorph new defaultTarget: self.
	menu commandKeyHandler: self.
	self colorForDebugging: menu.
	menu addStayUpItem.
	self fillIn: menu from: {
		{'previous project' . { #myWorld . #goBack }. 'return to the most-recently-visited project'}.
		{'jump to project...' . { #myWorld . #jumpToProject }. 'put up a list of all projects, letting me choose one to go to' }.
		{'save project on file...' . { #myWorld  . #saveOnFile }. 'save this project on a file' }.
		{'load project from file...' . { self  . #loadProject }. 'load a project from a file' }.
		nil}.

		self fillIn: menu from: {
		{'restore display (r)' . { World . #restoreMorphicDisplay }. 'repaint the screen -- useful for removing unwanted display artifacts, lingering cursors, etc.' }.
		nil}.
	Preferences simpleMenus ifFalse:
		[self fillIn: menu from: { 
			{'open...' . { self  . #openWindow } }.
			{'windows...' . { self  . #windowsDo } }.
			{'changes...' . { self  . #changesDo } }}].
	self fillIn: menu from: { 
		{'help...' . { self  . #helpDo }.  'puts up a menu of useful items for updating the system, determining what version you are running, and much else'}.
		{'appearance...' . { self  . #appearanceDo }. 'put up a menu offering many controls over appearance.' }}.

	Preferences simpleMenus ifFalse:
		[self fillIn: menu from: {
			{'do...' . { Utilities . #offerCommonRequests} . 'put up an editible list of convenient expressions, and evaluate the one selected.' }}].

	self fillIn: menu from: { 
		nil.
		{'new morph...' . { self  . #newMorph }. 'Offers a variety of ways to create new objects'}.
		nil.
		{'projects...' . { self  . #projectDo }. 'A menu of commands relating to use of projects' }}.
	Preferences simpleMenus ifFalse:
		[self fillIn: menu from: { 
			{'debug...' . { self  . #debugDo } . 'a menu of debugging items' }}].
	self fillIn: menu from: { 
		nil.
		{'save' . { SmalltalkImage current  . #saveSession } . 'save the current version of the image on disk' }.
		{'save as...' . { SmalltalkImage current . #saveAs }. 'save the current version of the image on disk under a new name.'}.
		{'save as new version' . { SmalltalkImage current . #saveAsNewVersion }. 'give the current image a new version-stamped name and save it under that name on disk.' }.
		{'save and quit' . { self  . #saveAndQuit } . 'save the current image on disk, and quit out of Squeak.'}.
		{'quit' . { self  . #quitSession } . 'quit out of Squeak.' }}.

	^ menu! !

!TheWorldMenu methodsFor: 'construction' stamp: 'jmv 12/1/2004 18:18'!
helpMenu
        "Build the help menu for the world."
        |  menu |

  	menu := self menu: 'help...' translated.

        self fillIn: menu from:
        {
                {'about this system...'. {Smalltalk. #aboutThisSystem}. 'current version information.'}.
                {'update code from server'. {Utilities. #updateFromServer}. 'load latest code updates via the internet'}.
                {'preferences...'. {Preferences. #openPreferencesInspector}. 'view and change various options.'}.
			 {'set language...' . {Project. #chooseNaturalLanguage}. 'choose the language in which tiles should be displayed.'} .
                nil.
               {'command-key help'. { Utilities . #openCommandKeyHelp}. 'summary of keyboard shortcuts.'}
	}.

	self addGestureHelpItemsTo: menu.

	self fillIn: menu from:
	{
                {'world menu help'. { self . #worldMenuHelp}. 'helps find menu items buried in submenus.'}.
                        "{'info about flaps' . { Utilities . #explainFlaps}. 'describes how to enable and use flaps.'}."
                {'font size summary' . { TextStyle . #fontSizeSummary}.  'summary of names and sizes of available fonts.'}.
                {'useful expressions' . { Utilities . #openStandardWorkspace}. 'a window full of useful expressions.'}.
			 {'annotation setup...' . { Preferences . #editAnnotations}. 'Click here to get a little window that will allow you to specify which types of annotations, in which order, you wish to see in the annotation panes of browsers and other tools'}.
			nil.
                {'graphical imports' . { Imports default . #viewImages}.  'view the global repository called ImageImports; you can easily import external graphics into ImageImports via the FileList'}.
                {'standard graphics library' . { ScriptingSystem . #inspectFormDictionary}.  'lets you view and change the system''s standard library of graphics.'}.
                nil.
                {#soundEnablingString . { Preferences . #toggleSoundEnabling}. 'turning sound off will completely disable Squeak''s use of sound.'}.
                nil.

                {'set author initials...' . { Utilities . #setAuthorInitials }. 'supply initials to be used to identify the author of code and other content.'}.
                {'vm statistics' . { self . #vmStatistics}.  'obtain some intriguing data about the vm.'}.
			  nil.
                {'space left' . { self . #garbageCollect}. 'perform a full garbage-collection and report how many bytes of space remain in the image.'}.
        }.

	^menu

! !

!TheWorldMenu methodsFor: 'construction' stamp: 'jmv 12/6/2004 21:43'!
projectMenu
	"Build the project menu for the world."
	| menu |

	self flag: #bob0302.

	menu _ self menu: 'projects...'.
	self fillIn: menu from: { 
		{ 'save on server (also makes a local copy)' . { #myProject . #storeOnServer } }.
		{ 'save to a different server' . { #myProject . #saveAs } }.
		{ 'save project on local file only' . { #myWorld . #saveOnFile } }.
		{ 'load project from file...' . { self . #loadProject } }.
		nil.
	}.

	self fillIn: menu from:
		{{'show project hierarchy'. {Project. #showProjectHierarchyInWindow}. 'Opens a window that shows names and relationships of all the projects in your system.'}.
		nil}.

	self mvcProjectsAllowed ifTrue: [
		self fillIn: menu from: {
			{ 'create new mvc project'. { self . #openMVCProject } }.
		}
	].
	self fillIn: menu from: { 
		{ 'create new morphic project' . { self . #openMorphicProject } }.
		nil.
		{ 'go to previous project' . { Project . #returnToPreviousProject } }.
		{ 'go to next project' . { Project . #advanceToNextProject } }.
		{ 'jump to project...' . { #myWorld . #jumpToProject } }.
	}.
	Preferences simpleMenus ifFalse: [
		self fillIn: menu from: { 
			nil.
			{ 'save for future revert' . { #myProject . #saveForRevert } }.
			{ 'revert to saved copy' . { #myProject . #revert } }.
		}.
	].

	^ menu! !


!ThumbnailMorph methodsFor: 'testing' stamp: 'jmv 12/6/2004 08:52'!
stepTime 
	"Adjust my step time to the time it takes drawing my referent"
	drawTime ifNil:[^ 250].
	^(20 * drawTime) max: 250.! !

!ThumbnailMorph methodsFor: 'what to view' stamp: 'jmv 12/2/2004 23:19'!
actualViewee
	"Return the actual morph to be viewed, or nil if there isn't an appropriate morph to view."

	| aMorph actualViewee |
	aMorph _ self morphToView ifNil: [^ nil]. 
	aMorph isInWorld ifFalse: [^ nil].
	actualViewee _ viewSelector ifNil: [aMorph] ifNotNil: [objectToView perform: viewSelector].
	actualViewee == 0 ifTrue: [^ nil].  "valueAtCursor result for an empty HolderMorph"
	actualViewee ifNil: [actualViewee _ objectToView].
	(actualViewee isMorph and: 
		[actualViewee isFlexMorph and: [actualViewee submorphs size = 1]])
			ifTrue: [actualViewee _ actualViewee firstSubmorph].
	^ actualViewee! !

!ThumbnailMorph methodsFor: 'what to view' stamp: 'jmv 12/2/2004 23:19'!
formOrMorphToView
	"Answer the form to be viewed, or the morph to be viewed, or nil"

	| actualViewee |
	(objectToView isForm) ifTrue: [^objectToView].
	actualViewee := viewSelector ifNil: [objectToView]
				ifNotNil: [objectToView perform: viewSelector].
	^actualViewee == 0 
		ifTrue: [nil	"valueAtCursor result for an empty HolderMorph"]
		ifFalse: 
			[actualViewee]! !

!ThumbnailMorph methodsFor: 'what to view' stamp: 'jmv 12/2/2004 23:19'!
morphToView
	"If the receiver is viewing some object, answer a morph can be thought of as being viewed;  A gesture is made toward generalizing this beyond the morph/player regime, in that a plain blue rectangle is returned rather than simply failing if the referent is not itself displayable."

	objectToView ifNil: [^ nil].
	^ objectToView isMorph
		ifTrue:
			[objectToView]
		ifFalse:
			[RectangleMorph new color: Color blue]
! !


!TransformationMorph methodsFor: 'private' stamp: 'jmv 12/1/2004 17:54'!
adjustAfter: changeBlock 
	"Cause this morph to remain cetered where it was before, and
	choose appropriate smoothing, after a change of scale or rotation."
	| oldRefPos |
	oldRefPos _ self referencePosition.
	changeBlock value.
	self chooseSmoothing.
	self position: self position + (oldRefPos - self referencePosition).
	self layoutChanged.
	owner ifNotNil: [owner invalidRect: bounds]
! !


!TranslucentProgessMorph methodsFor: 'drawing' stamp: 'jmv 12/24/2004 15:01'!
drawOn: aCanvas

	| revealPercentage revealingStyle revealingColor revealingBounds revealToggle x baseColor revealTimes secondsRemaining stringToDraw where fontToUse innerBounds |
	
	innerBounds _ bounds.
	opaqueBackgroundColor ifNotNil: [
		aCanvas 
			frameAndFillRectangle: bounds
			fillColor: opaqueBackgroundColor
			borderWidth: 8
			borderColor: Color blue.
		innerBounds _ innerBounds insetBy: 8.
	].
	revealTimes _ (self valueOfProperty: #revealTimes) ifNil: [^self].
	revealPercentage _ (revealTimes first / revealTimes second) asFloat.
	revealingStyle _ self revealingStyle.
	x _ self valueOfProperty: #progressStageNumber ifAbsent: [1].
	baseColor _ Color perform: (#(red blue green magenta cyan yellow) atPin: x).
	revealingColor _ baseColor alpha: 0.2.
	revealingStyle = 3 ifTrue: [	"wrap and change color"
		revealPercentage > 1.0 ifTrue: [
			revealingColor _ baseColor alpha: (0.2 + (revealingStyle / 10) min: 0.5).
		].
		revealPercentage _ revealPercentage fractionPart.
	].
	revealingStyle = 2 ifTrue: [	"peg at 75 and blink"
		revealPercentage > 0.75 ifTrue: [
			revealToggle _ self valueOfProperty: #revealToggle ifAbsent: [true].
			self setProperty: #revealToggle toValue: revealToggle not.
			revealToggle ifTrue: [revealingColor _ baseColor alpha: 0.8.].
		].
		revealPercentage _ revealPercentage min: 0.75.
	].
	revealingBounds _ innerBounds withLeft: innerBounds left + (innerBounds width * revealPercentage) truncated.
	aCanvas 
		fillRectangle: revealingBounds
		color: revealingColor.
	secondsRemaining _ (revealTimes second - revealTimes first / 1000) rounded.
	secondsRemaining > 0 ifTrue: [
		fontToUse _ StrikeFont familyName: Preferences standardDefaultTextFont familyName size: 24.
		stringToDraw _ secondsRemaining printString.
		where _ innerBounds corner - ((fontToUse widthOfString: stringToDraw) @ fontToUse height).
		aCanvas 
			drawString: stringToDraw 
			in: (where corner: innerBounds corner)
			font: fontToUse
			color: Color black.
		aCanvas
			drawString: stringToDraw 
			in: (where - (1@1) corner: innerBounds corner)
			font: fontToUse
			color: Color white.
	]. 


! !


!UpdatingStringMorph methodsFor: 'accessing' stamp: 'jmv 12/2/2004 23:19'!
decimalPlaces: aNumber
	"Set the receiver's number of decimal places to be shown.  If my target is a morph or a player, tell it about the change, in case it wants to remember it."

	self setProperty: #decimalPlaces toValue: aNumber.
	self pvtFloatPrecision: (Utilities floatPrecisionForDecimalPlaces: aNumber).
	(target isKindOf: Morph) ifTrue:
		[target noteDecimalPlaces: aNumber forGetter: getSelector]! !

!UpdatingStringMorph methodsFor: 'editing' stamp: 'jmv 12/6/2004 20:50'!
acceptValue: aValue

	self updateContentsFrom: (self acceptValueFromTarget: aValue).
! !


!Utilities class methodsFor: 'class initialization' stamp: 'jmv 12/1/2004 12:03'!
initialize
	"Initialize the class variables.  5/16/96 sw"
	self initializeCommonRequestStrings.
	RecentSubmissions _ OrderedCollection new! !

!Utilities class methodsFor: 'common requests' stamp: 'jmv 12/5/2004 15:55'!
initializeCommonRequestStrings
	"Initialize the common request strings, a directly-editable list of expressions that can be evaluated from the 'do...' menu."

	CommonRequestStrings _ StringHolder new contents: 
'Utilities emergencyCollapse.
Utilities closeAllDebuggers.
-
Sensor keyboard.
ParagraphEditor abandonChangeText.
Cursor normal show.
-
CommandHistory resetAllHistory.
Project allInstancesDo: [:p | p displayDepth: 16].
Form fromUser bitEdit.
Display border: (0@0 extent: 640@480) width: 2.
-
Undeclared inspect.
Undeclared removeUnreferencedKeys; inspect.
Transcript clear.
Utilities grabScreenAndSaveOnDisk.
FrameRateMorph new openInHand.
-
Utilities reconstructTextWindowsFromFileNamed: ''TW''.
Utilities storeTextWindowContentsToFileNamed: ''TW''.
ChangeSorter removeEmptyUnnamedChangeSets.
ChangeSorter reorderChangeSets.
-
ActiveWorld installVectorVocabulary.
ActiveWorld abandonVocabularyPreference.
Smalltalk saveAsNewVersion'

"Utilities initializeCommonRequestStrings"! !

!Utilities class methodsFor: 'durable menus' stamp: 'jmv 12/20/2004 22:23'!
windowMenuWithLabels: labelList colorPattern: colorPattern  targets: targetList selections: selectionList title: aTitle
	"removed - jmv"! !

!Utilities class methodsFor: 'durable menus' stamp: 'jmv 12/20/2004 22:23'!
windowMenuWithLabels: labelList colorPattern: colorPattern  targets: targetList selections: selectionList wordingSelectors: wordingList title: aTitle
	"removed - jmv"! !


!Vocabulary class methodsFor: 'class initialization' stamp: 'jmv 12/1/2004 13:10'!
assureNaturalLanguageTranslationsInActiveWorld
	"Assure that the currently-designated natural language is reflected in the tile scripting elements in the active world."

	| languageSymbol |
	languageSymbol _ ActiveWorld currentNaturalLanguage.
	self assureTranslationsAvailableFor: languageSymbol.

	"Vocabulary assureNaturalLanguageTranslationsInActiveWorld"! !

!Vocabulary class methodsFor: 'class initialization' stamp: 'jmv 12/24/2004 15:33'!
initializeStandardVocabularies
	"Initialize a few standard vocabularies and place them in the AllStandardVocabularies list."

	AllStandardVocabularies _ nil.
	self allStandardVocabularies.

	self addStandardVocabulary: self newPublicVocabulary.
	self addStandardVocabulary: FullVocabulary new.

	self addStandardVocabulary: self newQuadVocabulary.

	self addStandardVocabulary: ColorType new.
	self addStandardVocabulary: BooleanType new.
	self addStandardVocabulary: GraphicType new.
	self addStandardVocabulary: SoundType new.
	self addStandardVocabulary: StringType new.
	self addStandardVocabulary: MenuType new.
	self addStandardVocabulary: UnknownType new.

	self addStandardVocabulary: (SymbolListType new symbols: #(simple raised inset complexFramed complexRaised complexInset complexAltFramed complexAltRaised complexAltInset); vocabularyName: #BorderStyle; yourself).
	self addStandardVocabulary: (SymbolListType new symbols: #(lines arrows arrowheads dots); vocabularyName: #TrailStyle; yourself).
	self addStandardVocabulary: (SymbolListType new symbols: #(leftToRight rightToLeft topToBottom bottomToTop); vocabularyName: #ListDirection; yourself).

	self addStandardVocabulary: (SymbolListType new symbols: #(topLeft bottomRight center justified); vocabularyName: #ListCentering; yourself).

	self addStandardVocabulary: (SymbolListType new symbols: #(buttonDown whilePressed buttonUp); vocabularyName: #ButtonPhase; yourself).

	self addStandardVocabulary: (SymbolListType new symbols: #(rigid spaceFill shrinkWrap); vocabularyName: #Resizing; yourself).

	self addStandardVocabulary: self newSystemVocabulary.  "A custom vocabulary for Smalltalk -- still under development)"

	self numberVocabulary.  		"creates and adds it"
	self vocabularyForClass: Time.   "creates and adds it"

	"Vocabulary initialize"! !

!Vocabulary class methodsFor: 'class initialization' stamp: 'jmv 12/19/2004 09:56'!
removeObsoletes
	| keysToRemove |
	AllStandardVocabularies isNil ifTrue: [^self].
	keysToRemove := Set new.
	AllStandardVocabularies keysAndValuesDo: [ :k :v |
		v class isObsolete ifTrue: [ keysToRemove add: k ] ].
	keysToRemove do: [ :k |
		AllStandardVocabularies removeKey: k ].! !

!Vocabulary class methodsFor: 'queries' stamp: 'jmv 12/2/2004 23:19'!
instanceWhoRespondsTo: aSelector 
	"Find the most likely class that responds to aSelector. Return an instance 
	of it. Look in vocabularies to match the selector."
	"Most eToy selectors are for Players"
	| mthRefs |
	"Numbers are a problem"
	((self vocabularyNamed: #Number)
			includesSelector: aSelector)
		ifTrue: [^ 1].
	"Is a Float any different?"
	"String Point Time Date"
	#()
		do: [:nn | ((self vocabularyNamed: nn)
					includesSelector: aSelector)
				ifTrue: ["Ask Scott how to get a prototypical instance"
					^ (Smalltalk at: nn) new]].
	mthRefs _ self systemNavigation allImplementorsOf: aSelector.
	"every one who implements the selector"
	mthRefs
		sortBlock: [:a :b | (Smalltalk at: a classSymbol) allSuperclasses size < (Smalltalk at: b classSymbol) allSuperclasses size].
	mthRefs size > 0
		ifTrue: [^ (Smalltalk at: mthRefs first classSymbol) new].
	^ Error new! !


!WorldState methodsFor: 'canvas' stamp: 'jmv 12/28/2004 23:27'!
assuredCanvas
	(canvas isNil or: [(canvas extent ~= viewBox extent) or: [canvas form depth ~= Display depth]])
		ifTrue:
			["allocate a new offscreen canvas the size of the window"
			self canvas: (Display defaultCanvasClass extent: viewBox extent)].
	^ self canvas! !

!WorldState methodsFor: 'update cycle' stamp: 'jmv 12/28/2004 23:27'!
forceDamageToScreen: allDamage
	Display forceDamageToScreen: allDamage! !

WorldState removeSelector: #activeHand:!
WorldState removeSelector: #addRemoteCanvas:!
WorldState removeSelector: #assuredRemoteCanvas!
WorldState removeSelector: #clearCommandHistory!
WorldState removeSelector: #commandHistory!
WorldState removeSelector: #convertToCurrentVersion:refStream:!
WorldState removeSelector: #doOneCycleInBackground!
WorldState removeSelector: #releaseRemoteServer!
WorldState removeSelector: #remoteCanvasesDo:!
WorldState removeSelector: #remoteServer!
WorldState removeSelector: #remoteServer:!
WorldState removeSelector: #removeRemoteCanvas:!
WorldState removeSelector: #startBackgroundProcess!
WorldState removeSelector: #stepListSummary!
Object subclass: #WorldState
	instanceVariableNames: 'hands viewBox canvas damageRecorder stepList lastStepTime lastStepMessage lastCycleTime alarms lastAlarmTime remoteServer'
	classVariableNames: 'CanSurrenderToOS DeferredUIMessages DisableDeferredUpdates LastCycleTime MinCycleLapse'
	poolDictionaries: ''
	category: 'Morphic-Worlds'!

!WorldState reorganize!
('alarms' addAlarm:withArguments:for:at: adjustAlarmTimes: alarmSortBlock alarms removeAlarm:for: triggerAlarmsBefore:)
('canvas' assuredCanvas canvas canvas: doFullRepaint recordDamagedRect: resetDamageRecorder viewBox viewBox:)
('hands' activeHand addHand: hands handsDo: handsReverseDo: removeHand: selectHandsToDrawForDamage:)
('initialization' initialize stepListSize stepListSortBlock)
('object fileIn' convertAlarms convertStepList)
('stepping' adjustWakeupTimes: adjustWakeupTimesIfNecessary cleanseStepListForWorld: isStepping: isStepping:selector: listOfSteppingMorphs runLocalStepMethodsIn: runStepMethodsIn: startStepping:at:selector:arguments:stepTime: stopStepping: stopStepping:selector:)
('update cycle' checkIfUpdateNeeded displayWorld:submorphs: displayWorldAsTwoTone:submorphs:color: displayWorldSafely: doDeferredUpdatingFor: doOneCycleFor: doOneCycleNowFor: doOneSubCycleFor: drawWorld:submorphs:invalidAreasOn: forceDamageToScreen: handleFatalDrawingError: interCyclePause:)
!

Workspace class removeSelector: #initialize!
Workspace class removeSelector: #registerInFlapsRegistry!
Workspace class removeSelector: #unload!
Workspace removeSelector: #convertToCurrentVersion:refStream:!
PortugueseLexiconServer class removeSelector: #openScamperOn:!
WordNet class removeSelector: #openScamperOn:!
WeakMessageSend removeSelector: #asTilesIn:!
WeakMessageSend removeSelector: #asTilesIn:globalNames:!
WeakMessageSend removeSelector: #stringFor:!
Vocabulary class removeSelector: #addEToyVectorVocabulary!
Vocabulary class removeSelector: #addEToyVocabulary!
Vocabulary class removeSelector: #changeMadeToViewerAdditions!
Vocabulary class removeSelector: #eToyVocabulary!
Vocabulary class removeSelector: #newWonderlandVocabulary!
Vocabulary class removeSelector: #wonderlandVocabulary!
UnknownType removeSelector: #affordsCoercionToBoolean!
UnknownType removeSelector: #wantsArrowsOnTiles!

!UnknownType reorganize!
('initialization' initialize)
('queries' representsAType)
!

ScriptNameType removeSelector: #choices!
ScriptNameType removeSelector: #defaultArgumentTile!
ScriptNameType removeSelector: #newReadoutTile!

!ScriptNameType reorganize!
('initialization' initialize)
!

SymbolListType removeSelector: #affordsCoercionToBoolean!
SymbolListType removeSelector: #defaultArgumentTile!
SymbolListType removeSelector: #newReadoutTile!
StringType removeSelector: #defaultArgumentTile!
StringType removeSelector: #setFormatForDisplayer:!
StringType removeSelector: #wantsArrowsOnTiles!

!StringType reorganize!
('initial value' initialValueForASlotFor:)
('initialization' initialize)
('color' typeColor)
!

SoundType removeSelector: #defaultArgumentTile!
SoundType removeSelector: #newReadoutTile!
SoundType removeSelector: #setFormatForDisplayer:!
PlayerType removeSelector: #addExtraItemsToMenu:forSlotSymbol:!
PlayerType removeSelector: #defaultArgumentTile!
PlayerType removeSelector: #updatingTileForTarget:partName:getter:setter:!
PlayerType removeSelector: #wantsArrowsOnTiles!

!PlayerType reorganize!
('initial value' initialValueForASlotFor:)
('initialization' initialize)
('color' typeColor)
!

NumberType removeSelector: #addExtraItemsToMenu:forSlotSymbol:!
NumberType removeSelector: #addUserSlotItemsTo:slotSymbol:!
NumberType removeSelector: #addWatcherItemsToMenu:forGetter:!
NumberType removeSelector: #comparatorForSampleBoolean!
NumberType removeSelector: #defaultArgumentTile!
NumberType removeSelector: #newReadoutTile!
NumberType removeSelector: #wantsAssignmentTileVariants!
NumberType removeSelector: #wantsSuffixArrow!

!NumberType reorganize!
('initial value' initialValueForASlotFor:)
('initialization' initialize)
('color' typeColor)
!

MenuType removeSelector: #defaultArgumentTile!

!MenuType reorganize!
('initialization' initialize)
('color' typeColor)
!

GraphicType removeSelector: #defaultArgumentTile!
GraphicType removeSelector: #updatingTileForTarget:partName:getter:setter:!

!GraphicType reorganize!
('initial value' initialValueForASlotFor:)
('initialization' initialize)
('color' typeColor)
!

ColorType removeSelector: #defaultArgumentTile!
ColorType removeSelector: #updatingTileForTarget:partName:getter:setter:!

!ColorType reorganize!
('initial value' initialValueForASlotFor:)
('initialization' initialize)
('color' typeColor)
!

BooleanType removeSelector: #defaultArgumentTile!

!BooleanType reorganize!
('initial value' initialValueForASlotFor:)
('initialization' initialize)
('color' typeColor)
!

DataType removeSelector: #addExtraItemsToMenu:forSlotSymbol:!
DataType removeSelector: #addUserSlotItemsTo:slotSymbol:!
DataType removeSelector: #addWatcherItemsToMenu:forGetter:!
DataType removeSelector: #affordsCoercionToBoolean!
DataType removeSelector: #comparatorForSampleBoolean!
DataType removeSelector: #defaultArgumentTile!
DataType removeSelector: #newReadoutTile!
DataType removeSelector: #setFormatForDisplayer:!
DataType removeSelector: #updatingTileForTarget:partName:getter:setter:!
DataType removeSelector: #wantsArrowsOnTiles!
DataType removeSelector: #wantsAssignmentTileVariants!
DataType removeSelector: #wantsSuffixArrow!

!DataType reorganize!
('initial value' initialValueForASlotFor:)
('initialization')
('color' subduedColorFromTriplet:)
('queries' representsAType)
!

Vocabulary removeSelector: #tileWordingForSelector:!
TempVariableNode removeSelector: #asMorphicSyntaxIn:!
TempVariableNode removeSelector: #explanation!
VariableNode removeSelector: #asMorphicSyntaxIn:!
VariableNode removeSelector: #explanation!
Utilities class removeSelector: #addToTrash:!
Utilities class removeSelector: #emptyScrapsBook!
Utilities class removeSelector: #globalFlapTabOrDummy:!
Utilities initialize!
Utilities class removeSelector: #lookUpDefinition!
Utilities class removeSelector: #maybeEmptyTrash!
Utilities class removeSelector: #registerInFlapsRegistry!
Utilities class removeSelector: #scrapsBook!
Utilities class removeSelector: #trashTitle!
Utilities class removeSelector: #unload!

!Utilities class reorganize!
('class initialization' initialize startUp)
('common requests' appendToCommonRequests: closeAllDebuggers commonRequestStrings: editCommonRequestStrings eval: evaluate:in:to: initializeCommonRequestStrings offerCommonRequests offerCommonRequestsInMorphic)
('debugging' doesNotUnderstand: inspectCollection:notifying:)
('durable menus' windowFromMenu:target:title: windowFromMenu:target:title:colorPattern: windowMenuWithLabels:colorPattern:targets:selections:title: windowMenuWithLabels:colorPattern:targets:selections:wordingSelectors:title:)
('fetching updates' applyUpdatesFromDisk applyUpdatesFromDiskToUpdateNumber:stopIfGap: broadcastUpdatesFrom:to:except: chooseUpdateList extractThisVersion: fileInFromUpdatesFolder: getUpdateDirectoryOrNil lastUpdateNum: newUpdatesOn:special:throughNumber: objectStrmFromUpdates: parseListContents: position:atVersion: readNextUpdateFromServer readNextUpdatesFromDisk: readServer:special:updatesThrough:saveLocally:updateImage: readServerUpdatesSaveLocally:updateImage: readServerUpdatesThrough:saveLocally:updateImage: retrieveUrls:ontoQueue:withWaitSema: saveUpdate:onFile: serverUrls setUpdateServer: summariesForUpdates:through: updateComment updateFromServer updateFromServerThroughUpdateNumber: updateUrlLists writeList:toStream: zapUpdateDownloader)
('deprecated' fileOutChangeSetsNamed: fileOutChanges hierarchyOfClassesSurrounding: hierarchyOfImplementorsOf:forClass: methodHierarchyBrowserForClass:selector: spawnHierarchyForClass:selector: stripMethods:messageCode:)
('graphical support' grabScreenAndSaveOnDisk showFormsAcrossTopOfScreen: showFormsDictAcrossTopOfScreen:)
('identification' authorInitials authorInitialsPerSe authorName authorName: authorNamePerSe browseUncommentedMethodsWithInitials: changeStamp changeStampPerSe copyrightNotice dateStamp dateTimeSuffix fixStamp: methodsWithInitials: monthDayTime24StringFrom: monthDayTimeStringFrom: setAuthorInitials setAuthorInitials: setAuthorName)
('investigations' inspectGlobals reportSenderCountsFor:)
('miscellaneous' addSampleWindowsTo: awaitMouseUpIn:repeating:ifSucceed: awaitMouseUpIn:whileMouseDownDo:whileMouseDownInsideDo:ifSucceed: cleanseOtherworldlySteppers convertCRtoLF: createPageTestWorkspace decimalPlacesForFloatPrecision: decommissionTheAllCategory doesMethod:forClass:bearInitials: emergencyCollapse fixUpProblemsWithAllCategory floatPrecisionForDecimalPlaces: garbageCollectAndReport getterSelectorFor: inherentSelectorForGetter: instanceComparisonsBetween:and: isObject:memberOfOneOf: keyLike:satisfying: keyLike:withTrailing:satisfying: methodDiffFor:class:selector:prettyDiffs: nextClockwiseSideAfter: openScratchWorkspaceLabeled:contents: oppositeCornerFrom: oppositeModeTo: oppositeSideTo: reconstructTextWindowsFromFileNamed: setClassAndSelectorFrom:in: setterSelectorFor: simpleSetterFor: steplistToolsWorkspace storeTextWindowContentsToFileNamed: timeStampForMethod:)
('recent method submissions' assureMostRecentSubmissionExists browseRecentSubmissions dumpAnyOldStyleRecentSubmissions event: mostRecentlySubmittedMessage noteMethodSubmission:forClass: numberOfRecentSubmissionsToStore numberOfRecentSubmissionsToStore: openRecentSubmissionsBrowser purgeFromRecentSubmissions: purgeRecentSubmissionsOfMissingMethods recentMethodSubmissions recentSubmissionsWindow revertLastMethodSubmission)
('summer97 additions' browseVersionsForClass:selector: chooseFileWithSuffix: chooseFileWithSuffixFromList:withCaption: classCategoriesStartingWith: classFromPattern:withCaption: graphicsFileSuffixes inviolateInstanceVariableNames isLegalInstVarName: wellFormedInstanceVariableNameFrom:)
('support windows' commandKeyMappings openCommandKeyHelp openStandardWorkspace standardWorkspaceContents)
('user interface' informUser:during: informUserDuring:)
('vm statistics' vmStatisticsReportString vmStatisticsShortString)
!

MouseMoveEvent removeSelector: #decodeFromStringArray:!
MouseMoveEvent removeSelector: #encodedAsStringArray!
MouseButtonEvent removeSelector: #decodeFromStringArray:!
MouseButtonEvent removeSelector: #encodedAsStringArray!
KeyboardEvent removeSelector: #decodeFromStringArray:!
KeyboardEvent removeSelector: #encodedAsStringArray!
UserInputEvent removeSelector: #encodedAsStringArray!
UpdatingStringMorph removeSelector: #couldHoldSeparateDataForEachInstance!
UpdatingStringMorph removeSelector: #currentDataValue!
UpdatingStringMorph removeSelector: #hasStructureOfComplexWatcher!
UpdatingStringMorph removeSelector: #putOnBackground!
UpdatingStringMorph removeSelector: #setNewContentsFrom:!
UpdatingStringMorph removeSelector: #variableDocks!
UpdatingMenuItemMorph removeSelector: #adaptToWorld:!
UndefinedObject removeSelector: #newTileMorphRepresentative!
TranslucentColor removeSelector: #convertToCurrentVersion:refStream:!
TransformationMorph removeSelector: #heading:!
TransferMorph removeSelector: #undoGrabCommand!
TranscriptStream class removeSelector: #initialize!
TranscriptStream class removeSelector: #registerInFlapsRegistry!
TranscriptStream class removeSelector: #unload!
TinyPaint removeSelector: #handlesMouseDown:!
ThumbnailMorph removeSelector: #installAsWonderlandTextureOn:!
ThumbnailMorph removeSelector: #tearOffTile!
ThreePhaseButtonMorph removeSelector: #adaptToWorld:!
ThreePhaseButtonMorph removeSelector: #updateReferencesUsing:!
TheWorldMenu class removeSelector: #registerStandardInternetApps!
TheWorldMenu removeSelector: #adaptedToWorld:!
TheWorldMenu removeSelector: #createStandardPartsBin!
TheWorldMenu removeSelector: #flapsDo!
TheWorldMenu removeSelector: #flapsMenu!
TheWorldMenu removeSelector: #formulateFlapsMenu:!
TheWorldMenu removeSelector: #globalFlapsEnabled!
TheWorldMenu removeSelector: #launchCustomPartsBin!
TheWorldMenu removeSelector: #playfieldDo!
TheWorldMenu removeSelector: #playfieldMenu!
TheWorldMenu removeSelector: #printWorldOnFile!
TheWorldMenu removeSelector: #remoteDo!
TheWorldMenu removeSelector: #remoteMenu!
TheWorldMenu removeSelector: #scriptingDo!
TheWorldMenu removeSelector: #scriptingMenu!
TheWorldMenu removeSelector: #uniTilesClassicString!
TextMorphForEditView removeSelector: #convertToCurrentVersion:refStream:!
TextMorphEditor removeSelector: #recognizeCharacters!
TextMorphEditor removeSelector: #recognizeCharactersWhileMouseIn:!
TextMorph class removeSelector: #additionsToViewerCategories!
TextMorph class removeSelector: #exampleBackgroundField!
TextMorph class removeSelector: #fancyPrototype!
TextMorph initialize!
TextMorph class removeSelector: #registerInFlapsRegistry!
TextMorph class removeSelector: #supplementaryPartsDescriptions!
TextMorph class removeSelector: #unload!
TextMorph removeSelector: #changeTextColor!
TextMorph removeSelector: #configureForKids!
TextMorph removeSelector: #convertToCurrentVersion:refStream:!
TextMorph removeSelector: #couldHoldSeparateDataForEachInstance!
TextMorph removeSelector: #currentDataValue!
TextMorph removeSelector: #elementCount!
TextMorph removeSelector: #getCharacters!
TextMorph removeSelector: #holderForCharacters!
TextMorph removeSelector: #newContents:fromCard:!
TextMorph removeSelector: #setAllButFirstCharacter:!
TextMorph removeSelector: #setCharacters:!
TextMorph removeSelector: #setFirstCharacter:!
TextMorph removeSelector: #setNewContentsFrom:!
TextMorph removeSelector: #setNumericValue:!
TextMorph removeSelector: #updateReferencesUsing:!
TextMorph removeSelector: #variableDocks!
TextFieldMorph class removeSelector: #exampleBackgroundField!
TextFieldMorph class removeSelector: #initialize!
TextFieldMorph class removeSelector: #registerInFlapsRegistry!
TextFieldMorph class removeSelector: #unload!
TextFieldMorph removeSelector: #couldHoldSeparateDataForEachInstance!
TextFieldMorph removeSelector: #currentDataValue!
TextFieldMorph removeSelector: #setNewContentsFrom:!
TextFieldMorph removeSelector: #variableDocks!
TestRunner initialize!
TestRunner class removeSelector: #registerInFlapsRegistry!
TTCFont removeSelector: #convertToCurrentVersion:refStream:!
SystemWindow removeSelector: #convertToCurrentVersion:refStream:!
SystemWindow removeSelector: #isCandidateForAutomaticViewing!
SystemWindow removeSelector: #openInMVC!
SystemWindow removeSelector: #openInMVCExtent:!
SystemWindow removeSelector: #wantsHalo!
SystemShrinker class removeSelector: #cleanUpEtoys!
SystemDictionary removeSelector: #assureUniClass!
SystemDictionary removeSelector: #cleanUpUndoCommands!
SystemDictionary removeSelector: #discardDiscards!
SystemDictionary removeSelector: #majorShrink!
SystemDictionary removeSelector: #makeSqueaklandRelease!
SystemDictionary removeSelector: #vocabularyDemanded!
Symbol class removeSelector: #compareTiming!
Symbol removeSelector: #isSymbol!
StringButtonMorph removeSelector: #adaptToWorld:!
StringButtonMorph removeSelector: #updateReferencesUsing:!
MenuItemMorph class removeSelector: #additionsToViewerCategories!
MenuItemMorph removeSelector: #adaptToWorld:!
StringMorph removeSelector: #getCharacters!
SelectorBrowser class removeSelector: #initialize!
SelectorBrowser class removeSelector: #registerInFlapsRegistry!
SelectorBrowser class removeSelector: #unload!
PackagePaneBrowser class removeSelector: #initialize!
PackagePaneBrowser class removeSelector: #registerInFlapsRegistry!
PackagePaneBrowser class removeSelector: #unload!
MethodHolder class removeSelector: #isolatedCodePaneForClass:selector:!
MethodHolder class removeSelector: #makeIsolatedCodePaneForClass:selector:!
MethodHolder removeSelector: #addModelMenuItemsTo:forMorph:hand:!
MethodHolder removeSelector: #identifyScript!
MessageNames class removeSelector: #initialize!
MessageNames class removeSelector: #registerInFlapsRegistry!
InstanceBrowser removeSelector: #viewViewee!
Lexicon removeSelector: #acceptTiles!
Lexicon removeSelector: #installTilesForSelection!
Lexicon removeSelector: #tilesMenu!
Lexicon removeSelector: #varTilesMenu!
Inspector removeSelector: #convertToCurrentVersion:refStream:!
Inspector removeSelector: #tearOffTile!
Inspector removeSelector: #viewerForValue!
FillInTheBlank removeSelector: #convertToCurrentVersion:refStream:!
FileList2 class removeSelector: #blueButtonText:textColor:inWindow:!
FileList2 class removeSelector: #blueRamp1!
FileList2 class removeSelector: #blueRamp3!
FileList2 class removeSelector: #enableTypeButtons:info:forDir:!
FileList2 class removeSelector: #modalFolderSelectorForProject:!
FileList2 class removeSelector: #modalFolderSelectorForProjectLoad!
FileList2 class removeSelector: #morphicViewGeneralLoaderInWorld:!
FileList2 class removeSelector: #morphicViewProjectLoader2InWorld:!
FileList2 class removeSelector: #morphicViewProjectLoader2InWorld:reallyLoad:!
FileList2 class removeSelector: #morphicViewProjectLoader2InWorld:reallyLoad:dirFilterType:!
FileList2 class removeSelector: #morphicViewProjectSaverFor:!
FileList class removeSelector: #registerInFlapsRegistry!
FileList class removeSelector: #unload!
Debugger removeSelector: #createSyntaxMorph!
ChangeSorter initialize!
ChangeSorter class removeSelector: #registerInFlapsRegistry!
Browser initialize!
Browser class removeSelector: #registerInFlapsRegistry!
Browser class removeSelector: #unload!
Browser removeSelector: #fetchClassDocPane!
CodeHolder removeSelector: #installTextualCodingPane!
CodeHolder removeSelector: #installTilesForSelection!
CodeHolder removeSelector: #restoreTextualCodingPane!
CodeHolder removeSelector: #showTiles:!
CodeHolder removeSelector: #showingTiles!
CodeHolder removeSelector: #showingTilesString!
CodeHolder removeSelector: #toggleShowingTiles!

!CodeHolder reorganize!
('annotation' addOptionalAnnotationsTo:at:plus: addPriorVersionsCountForSelector:ofClass:to: annotation annotationForClassCommentFor: annotationForClassDefinitionFor: annotationForHierarchyFor: annotationForSelector:ofClass: annotationPaneMenu:shifted: annotationRequests annotationSeparator defaultAnnotationPaneHeight defaultButtonPaneHeight)
('categories' categoryFromUserWithPrompt:for: categoryOfCurrentMethod changeCategory letUserReclassify:in: methodCategoryChanged selectedMessageCategoryName)
('contents' commentContents contents contentsChanged contentsSymbol contentsSymbol:)
('commands' abbreviatedWordingFor: adoptMessageInCurrentChangeset browseImplementors browseSenders copyUpOrCopyDown makeSampleInstance offerMenu offerShiftedClassListMenu offerUnshiftedClassListMenu removeClass shiftedYellowButtonActivity showUnreferencedClassVars showUnreferencedInstVars spawn: spawnFullProtocol spawnHierarchy spawnProtocol spawnToClass: spawnToCollidingClass: unshiftedYellowButtonActivity)
('construction' addLowerPanesTo:at:with: buildClassBrowserEditString: buildMorphicCodePaneWith:)
('controls' addOptionalButtonsTo:at:plus: buttonWithSelector: codePaneProvenanceButton codePaneProvenanceString contentsSymbolQuints decorateButtons decorateForInheritance inheritanceButton optionalButtonPairs optionalButtonRow sourceAndDiffsQuintsOnly)
('diffs' defaultDiffsSymbol diffButton diffFromPriorSourceFor: prettyDiffButton regularDiffButton showDiffs showDiffs: showPrettyDiffs: showRegularDiffs: showingAnyKindOfDiffs showingDiffsString showingPrettyDiffs showingPrettyDiffsString showingRegularDiffs showingRegularDiffsString toggleColorPrint toggleDiff toggleDiffing togglePlainSource togglePrettyDiffing togglePrettyPrint toggleRegularDiffing wantsDiffFeedback)
('misc' getSelectorAndSendQuery:to: getSelectorAndSendQuery:to:with: isThereAnOverride isThisAnOverride menuButton modelWakeUpIn: okayToAccept priorSourceOrNil refreshAnnotation refusesToAcceptCode releaseCachedState sampleInstanceOfSelectedClass sendQuery:to: setClassAndSelectorIn: suggestCategoryToSpawnedBrowser: useSelector:orGetSelectorAndSendQuery:to:)
('self-updating' didCodeChangeElsewhere stepIn: updateCodePaneIfNeeded updateListsAndCodeIn: wantsStepsIn:)
('what to show' addContentsTogglesTo: addModelItemsToWindowMenu: colorPrintString offerWhatToShowMenu prettyPrintString setContentsToForceRefetch showAltSyntax: showByteCodes: showComment showDecompile: showDocumentation: showingAltSyntax showingAltSyntaxString showingByteCodes showingByteCodesString showingColorPrint showingDecompile showingDecompileString showingDocumentation showingDocumentationString showingPlainSource showingPlainSourceString showingPrettyPrint showingSource toggleAltSyntax toggleDecompile toggleShowDocumentation toggleShowingByteCodes)
('categories & search pane' listPaneWithSelector: newSearchPane searchPane textPaneWithSelector:)
('message list' decompiledSourceIntoContents decompiledSourceIntoContentsWithTempNames: selectedBytecodes selectedMessage sourceStringPrettifiedAndDiffed validateMessageSource:forSelector:)
('message list menu' messageListKey:from:)
('message category functions' canShowMultipleMessageCategories)
!

StringHolder removeSelector: #fetchDocPane!
StringHolder removeSelector: #makeIsolatedCodePane!
StringHolder removeSelector: #openSyntaxView!
String removeSelector: #asPostscript!
String removeSelector: #newTileMorphRepresentative!
StarMorph class removeSelector: #initialize!
StarMorph class removeSelector: #registerInFlapsRegistry!
StarMorph class removeSelector: #unload!
StandardSystemView removeSelector: #convertToCurrentVersion:refStream:!
StandardScriptingSystem initialize!
StandardScriptingSystem class removeSelector: #noteCompilationOf:meta:!
StandardScriptingSystem class removeSelector: #registerInFlapsRegistry!
StandardScriptingSystem class removeSelector: #unload!
StandardScriptingSystem removeSelector: #acceptableSlotNameFrom:forSlotCurrentlyNamed:asSlotNameIn:world:!
StandardScriptingSystem removeSelector: #allKnownClassVariableNames!
StandardScriptingSystem removeSelector: #anyButtonPressedTiles!
StandardScriptingSystem removeSelector: #arithmeticalOperatorsAndHelpStrings!
StandardScriptingSystem removeSelector: #cleanupsForRelease!
StandardScriptingSystem removeSelector: #colorBehindTiles!
StandardScriptingSystem removeSelector: #colorForType:!
StandardScriptingSystem removeSelector: #customizeForEToyUsers:!
StandardScriptingSystem removeSelector: #doesOperatorWantArrows:!
StandardScriptingSystem removeSelector: #fontForNameEditingInScriptor!
StandardScriptingSystem removeSelector: #fontForTiles!
StandardScriptingSystem removeSelector: #goButton!
StandardScriptingSystem removeSelector: #goUp:with:!
StandardScriptingSystem removeSelector: #helpStringForOperator:!
StandardScriptingSystem removeSelector: #helpStringOrNilForOperator:!
StandardScriptingSystem removeSelector: #holderWithAlphabet!
StandardScriptingSystem removeSelector: #informScriptingUser:!
StandardScriptingSystem removeSelector: #installSolidMenuForm!
StandardScriptingSystem removeSelector: #mergeGraphicsFrom:!
StandardScriptingSystem removeSelector: #nameForInstanceVariablesCategory!
StandardScriptingSystem removeSelector: #nameForScriptsCategory!
StandardScriptingSystem removeSelector: #newScriptingSpace!
StandardScriptingSystem removeSelector: #newScriptingSpace2!
StandardScriptingSystem removeSelector: #noButtonPressedTiles!
StandardScriptingSystem removeSelector: #numericComparitorsAndHelpStrings!
StandardScriptingSystem removeSelector: #patchInNewStandardPlayerForm!
StandardScriptingSystem removeSelector: #prepareForExternalReleaseNamed:!
StandardScriptingSystem removeSelector: #prototypicalHolder!
StandardScriptingSystem removeSelector: #readFormsFromFileNamed:!
StandardScriptingSystem removeSelector: #readFormsFromFileNamed:andStoreIntoGlobal:!
StandardScriptingSystem removeSelector: #reclaimSpace!
StandardScriptingSystem removeSelector: #referenceAt:!
StandardScriptingSystem removeSelector: #referenceAt:put:!
StandardScriptingSystem removeSelector: #reinvigorateThumbnailsInViewerFlapTabs!
StandardScriptingSystem removeSelector: #reportToUser:!
StandardScriptingSystem removeSelector: #resetAllScriptingReferences!
StandardScriptingSystem removeSelector: #resetStaleScriptingReferences!
StandardScriptingSystem removeSelector: #resetStandardPartsBin!
StandardScriptingSystem removeSelector: #restorePrivateGraphics!
StandardScriptingSystem removeSelector: #saveFormsToFileNamed:!
StandardScriptingSystem removeSelector: #scriptControlButtons!
StandardScriptingSystem removeSelector: #setterSelectorForGetter:!
StandardScriptingSystem removeSelector: #smallBoldFont!
StandardScriptingSystem removeSelector: #standardEventStati!
StandardScriptingSystem removeSelector: #standardForms!
StandardScriptingSystem removeSelector: #statusColorSymbolFor:!
StandardScriptingSystem removeSelector: #statusHelpString!
StandardScriptingSystem removeSelector: #stepButton!
StandardScriptingSystem removeSelector: #stepDown:with:!
StandardScriptingSystem removeSelector: #stepStillDown:with:!
StandardScriptingSystem removeSelector: #stepUp:with:!
StandardScriptingSystem removeSelector: #stopButton!
StandardScriptingSystem removeSelector: #stopUp:with:!
StandardScriptingSystem removeSelector: #systemSlotNamesOfType:!
StandardScriptingSystem removeSelector: #tileForArgType:!
StandardScriptingSystem removeSelector: #tilesForQuery:label:!
StandardScriptingSystem removeSelector: #tryButtonFor:!
StandardScriptingSystem removeSelector: #uniqueNameForReference!
StandardScriptingSystem removeSelector: #wordingForOperator:!
Object subclass: #StandardScriptingSystem
	instanceVariableNames: ''
	classVariableNames: 'FormDictionary HelpStrings'
	poolDictionaries: ''
	category: 'Morphic-Scripting'!

!StandardScriptingSystem reorganize!
('font & color choices' uniformTileInteriorColor)
('form dictionary' deletePrivateGraphics deletePrivateGraphics:afterStoringToFileNamed: formAtKey: formAtKey:extent:depth: formDictionary inspectFormDictionary privateGraphics saveForm:atKey: squeakyMouseForm)
('help dictionary' helpStringOrNilFor: initializeHelpStrings)
('tile colors' colorFudge)
('utilities' allClassVarNamesInSystem spaceReclaimed stripGraphicsForExternalRelease)
!

SpeakerMorph class removeSelector: #additionsToViewerCategories!
SmartRefStream removeSelector: #starLogoAntColonybosfcedppplppppttwssdlgrstta0!
SmartRefStream removeSelector: #starLogoMorphbosfcedppplppppttwssdlgrstt0!
SmartRefStream removeSelector: #starLogoTreesbosfcedppplppppttwssdlgrsttdt0!
SmartRefStream removeSelector: #starLogoTurtlewwxywwhcpn0!

!SmartRefStream reorganize!
('read write' appendClassDefns checkCrLf initKnownRenames initShapeDicts instVarInfo: mapClass: moreObjects next nextAndClose nextPut: nextPutObjOnly: noHeader readInstance readInstanceSize:clsname:refPosn: readShortInst recordImageSegment: renamed renamedConv restoreClassInstVars saveClassInstVars scanFrom: setStream: setStream:reading: structures superclasses uniClasesDo: uniClassInstVarsRefs: verifyStructure versionSymbol:)
('class changed shape' catalogValues:size: conversionMethodsFor: storeInstVarsIn:from: writeClassRename:was: writeClassRenameMethod:was:fromInstVars: writeConversionMethod:class:was:fromInstVars:to: writeConversionMethodIn:fromInstVars:to:renamedFrom:)
('conversion' bookPageMorphbosfcepcbbfgcc0 clippingMorphbosfcep0 clippingMorphbosfcepc0 dropShadowMorphbosfces0 gradientFillbosfcepbbfgcc0 layoutMorphbosfcepbbochvimol0 layoutMorphbosfcepcbbochvimol0 morphicEventtcbks0 morphicSoundEventtcbkss0 myMorphbosfce0 newMorphicEventts0 scrollControllermvslrrsmsms0 transparentColorrcc0 worldMorphbosfcebbfgccpmcpbttloiairfidcuwhavcdsll0)
('import image segment' applyConversionMethodsTo:className:varMap: checkFatalReshape: convert1:to:allVarMaps: convert2:allVarMaps: mapClass:origName: reshapedClassesIn:)
('accessing' structures: superclasses:)
!

SmallInteger removeSelector: #uniqueNameForReference!
SketchMorph class removeSelector: #additionsToViewerCategories!
SketchMorph class removeSelector: #exampleBackgroundSketch!
ColorPickerMorph removeSelector: #delete!
ColorPickerMorph removeSelector: #isCandidateForAutomaticViewing!
SketchMorph removeSelector: #acquirePlayerSimilarTo:!
SketchMorph removeSelector: #appearsToBeSameCostumeAs:!
SketchMorph removeSelector: #asWearableCostume!
SketchMorph removeSelector: #convertToCurrentVersion:refStream:!
SketchMorph removeSelector: #couldHoldSeparateDataForEachInstance!
SketchMorph removeSelector: #currentDataValue!
SketchMorph removeSelector: #drawPostscriptOn:!
SketchMorph removeSelector: #heading:!
SketchMorph removeSelector: #variableDocks!
SimpleSwitchMorph removeSelector: #updateReferencesUsing:!
SimpleSliderMorph class removeSelector: #additionsToViewerCategories!
SimpleSliderMorph class removeSelector: #initialize!
SimpleSliderMorph class removeSelector: #registerInFlapsRegistry!
SimpleSliderMorph class removeSelector: #unload!
SimpleSliderMorph removeSelector: #setNumericValue:!
SimpleSliderMorph removeSelector: #updateReferencesUsing:!
SimpleButtonMorph class removeSelector: #additionsToViewerCategories!
IconicButton removeSelector: #initializeToShow:withLabel:andSend:to:!
SimpleButtonMorph removeSelector: #adaptToWorld:!
SimpleButtonMorph removeSelector: #objectForDataStream:!
SimpleButtonMorph removeSelector: #updateReferencesUsing:!
ServerDirectory class removeSelector: #eToyBaseFolderSpecForFileDirectory:!
ServerDirectory class removeSelector: #eToyBaseFolderSpecForFileDirectory:put:!
ServerDirectory class removeSelector: #eToyUserListForFileDirectory:!
ServerDirectory class removeSelector: #eToyUserListUrlForFileDirectory:!
ServerDirectory class removeSelector: #eToyUserListUrlForFileDirectory:put:!
ServerDirectory class removeSelector: #localEToyBaseFolderSpecs!
ServerDirectory class removeSelector: #localEToyUserListUrls!
ServerDirectory class removeSelector: #parseEToyUserListFrom:!
ServerDirectory class removeSelector: #projectDefaultDirectory!

!ServerDirectory class reorganize!
('misc' defaultStemUrl newFrom: on: parseFTPEntry: secondsForDay:month:yearOrTime:thisMonth:thisYear:)
('available servers' addLocalProjectDirectory: addServer:named: localProjectDirectories nameForServer: projectServers removeServerNamed: removeServerNamed:ifAbsent: resetLocalProjectDirectories resetServers serverForURL: serverNamed: serverNamed:ifAbsent: serverNames servers)
('server groups' convertGroupNames groupNames serverInGroupNamed: serversInGroupNamed:)
('server prefs' determineLocalServerDirectory: fetchExternalSettingsIn: parseServerEntryFrom: releaseExternalSettings serverConfDirectoryName storeCurrentServersIn: transferServerDefinitionsToExternal)
('class initialization' initialize)
!

ServerDirectory removeSelector: #eToyUserList!
ServerDirectory removeSelector: #eToyUserList:!
ServerDirectory removeSelector: #eToyUserListUrl!
ServerDirectory removeSelector: #eToyUserListUrl:!
ServerDirectory removeSelector: #eToyUserName:!
ServerDirectory removeSelector: #hasEToyUserList!
Object subclass: #ServerDirectory
	instanceVariableNames: 'server directory type user passwordHolder group moniker altURL urlObject client loaderUrl eToyUserListUrl eToyUserList keepAlive'
	classVariableNames: 'LocalProjectDirectories Servers'
	poolDictionaries: ''
	category: 'Network-RemoteDirectory'!

!ServerDirectory reorganize!
('accessing' acceptsUploads: altUrl altUrl: bareDirectory copy directory directory: directoryObject downloadUrl fullPath: isTypeFTP isTypeFile isTypeHTTP keepAlive: loaderUrl loaderUrl: moniker moniker: password password: passwordSequence passwordSequence: printOn: realUrl server server: slashDirectory type: typeForPrefs typeWithDefault url url: urlObject urlObject: user user:)
('testing' acceptsUploads isProjectSwiki isRemoteDirectory isRoot isSearchable keepAlive)
('up/download' fileExists: getDirectory getFileList getFileNamed: getFileNamed:into: getFileNamed:into:httpRequest: getOnlyBuffer:from: putFile:named: putFile:named:retry: putFileSavingOldVersion:named:)
('dis/connect' openFTPClient quit quitClient)
('file directory' asServerFileNamed: assureExistence assureExistenceOfPath: containingDirectory createDirectory: deleteDirectory: deleteFileNamed: directoryNamed: directoryNames entries exists fileAndDirectoryNames fileNamed: fileNames fullNameFor: getOnly:from: includesKey: localName localNameFor: localPathExists: matchingEntries: newFileNamed: oldFileNamed: oldFileOrNoneNamed: on: pathName pathNameDelimiter pathParts readOnlyFileNamed: rename:toBe: serverDelimiter splitName:to: streamOnBeginningOf:)
('multi-action sessions' reset sleep wakeUp)
('server groups' closeGroup convertGroupName groupName groupName: openGroup serversInGroup)
('initialize' fromUser)
('squeaklets' directoryWrapperClass moveAllButYoungest:in:to: upLoadProject:members:retry: upLoadProject:named:resourceUrl:retry: updateProjectInfoFor: writeProject:inFileNamed:fromDirectory:)
('file-in/out' storeServerEntryOn:)
('updates' checkNames: checkServersWithPrefix:andParseListInto: copyUpdatesNumbered:toVersion: exportUpdatesExcept: outOfDate: putUpdate: putUpdateMulti:fromDirectory: updateInstallVersion:)
!

SelectionMorph removeSelector: #privateFullMoveBy:!
SelectionMorph removeSelector: #refineUndoTarget:selector:arguments:in:!
SelectionMorph removeSelector: #undoMove:redo:owner:bounds:predecessor:!
ScrollingToolHolder removeSelector: #updateReferencesUsing:!
ScreenController removeSelector: #lookUpDefinition!
ScreenController removeSelector: #openMorphicWorld!
ScaleMorph removeSelector: #convertToCurrentVersion:refStream:!
ReturnNode removeSelector: #asMorphicSyntaxIn:!
ReturnNode removeSelector: #explanation!

!ReturnNode reorganize!
('code generation' code emitForReturn:on: emitForValue:on: pc sizeForReturn: sizeForValue:)
('converting' asReturnNode)
('initialize-release' expr: expr:encoder:sourceRange:)
('printing' printOn:indent:)
('testing' isReturnSelf isSpecialConstant isVariableReference)
!

RecordingControlsMorph class removeSelector: #initialize!
RecordingControlsMorph class removeSelector: #registerInFlapsRegistry!
RecordingControlsMorph class removeSelector: #unload!
GraphMorph class removeSelector: #additionsToViewerCategories!
AlignmentMorph class removeSelector: #additionsToViewerCategories!
AlignmentMorph class removeSelector: #supplementaryPartsDescriptions!
RectangleMorph class removeSelector: #initialize!
RectangleMorph class removeSelector: #registerInFlapsRegistry!
RectangleMorph class removeSelector: #supplementaryPartsDescriptions!
RectangleMorph class removeSelector: #unload!
Quadrangle removeSelector: #vocabularyDemanded!
Rectangle removeSelector: #encodeForRemoteCanvas!
Rectangle removeSelector: #encodePostscriptOn:!
RecordingControlsMorph removeSelector: #makeTile!
RecordingControlsMorph removeSelector: #updateReferencesUsing:!
RealEstateAgent class removeSelector: #reduceByFlaps:!
ProjectViewMorph removeSelector: #checkForNewerVersionAndLoad!
ProjectViewMorph removeSelector: #eToyStreamedRepresentationNotifying:!
ProjectViewMorph removeSelector: #fullDrawPostscriptOn:!
ProjectLauncher removeSelector: #doEtoyLogin!
ProjectLauncher removeSelector: #loginAs:!
ProjectLauncher removeSelector: #setupFlaps!
ProjectHistory removeSelector: #mostRecentThread!
Project removeSelector: #assureFlapIntegrity!
Project removeSelector: #assureNavigatorPresenceMatchesPreference!
Project removeSelector: #cleanseDisabledGlobalFlapIDsList!
Project removeSelector: #convertToCurrentVersion:refStream:!
Project removeSelector: #currentStack!
Project removeSelector: #findAFolderToLoadProjectFrom!
Project removeSelector: #flapsSuppressed:!
Project removeSelector: #globalFlapWithIDEnabledString:!
Project removeSelector: #isFlapEnabled:!
Project removeSelector: #isFlapIDEnabled:!
Project removeSelector: #loadFromServer!
Project removeSelector: #loadFromServer:!
Project removeSelector: #navigatorFlapVisible!
Project removeSelector: #restoreReferences!
Project removeSelector: #tellAFriend!
Project removeSelector: #tellAFriend:!
Project removeSelector: #tryToFindAServerWithMe!
Project removeSelector: #writeStackText:in:registerIn:!
ProcessBrowser initialize!
ProcessBrowser class removeSelector: #registerInFlapsRegistry!
ProcessBrowser class removeSelector: #unload!
Preferences class removeSelector: #addPreferenceForCelesteShowingAttachmentsFlag!
Preferences class removeSelector: #addPreferenceForOptionalCelesteStatusPane!
Preferences class removeSelector: #automaticFlapLayoutString!
Preferences class removeSelector: #batchPenTrails!
Preferences class removeSelector: #borderColorWhenRunning!
Preferences class removeSelector: #capitalizedReferences!
Preferences class removeSelector: #celesteHasStatusPane!
Preferences class removeSelector: #celesteShowsAttachmentsFlag!
Preferences class removeSelector: #chooseEToysFont!
Preferences class removeSelector: #chooseFlapsFont!
Preferences class removeSelector: #classicTilesSettingToggled!
Preferences class removeSelector: #eToyFriendly!
Preferences class removeSelector: #eToyFriendlyChanged!
Preferences class removeSelector: #eToyLoginEnabled!
Preferences class removeSelector: #enableProjectNavigator!
Preferences class removeSelector: #fenceEnabled!
Preferences class removeSelector: #fenceSoundEnabled!
Preferences class removeSelector: #fenceSoundEnabled:!
Preferences class removeSelector: #infiniteUndoChanged!
Preferences class removeSelector: #initialize!
Preferences class removeSelector: #initializePreferencePanel:in:!
Preferences class removeSelector: #largeTilesSettingToggled!
Preferences class removeSelector: #messengersInViewers!
Preferences class removeSelector: #mouseOverHalos!
Preferences class removeSelector: #mouseOverHalosChanged!
Preferences class removeSelector: #navigatorShowingString!
Preferences class removeSelector: #openFactoredPanel!
Preferences class removeSelector: #openFactoredPanelWithWidth:!
Preferences class removeSelector: #openNewPreferencesPanel!
Preferences class removeSelector: #openPreferencesControlPanel!
Preferences class removeSelector: #preferencesControlPanel!
Preferences class removeSelector: #registerInFlapsRegistry!
Preferences class removeSelector: #setArrowheads!
Preferences class removeSelector: #setEToysFontTo:!
Preferences class removeSelector: #sharedFlapsSettingChanged!
Preferences class removeSelector: #showProjectNavigator!
Preferences class removeSelector: #showProjectNavigatorChanged!
Preferences class removeSelector: #standardEToysFont!
Preferences class removeSelector: #standardFlapFont!
Preferences class removeSelector: #tileTranslucentDrag!
Preferences class removeSelector: #typeCheckingInTileScripting!
Preferences class removeSelector: #uniTilesClassic!
Preferences class removeSelector: #universalTiles!
Preferences class removeSelector: #universalTilesSettingToggled!
Preferences class removeSelector: #unload!

!Preferences class reorganize!
('add preferences' addPreference:categories:default:balloonHelp: addPreference:categories:default:balloonHelp:projectLocal:changeInformee:changeSelector: addPreference:category:default:balloonHelp:)
('factored pref panel' categoriesContainingPreference:)
('fonts' chooseBalloonHelpFont chooseCodeFont chooseFontWithPrompt:andSendTo:withSelector: chooseFontWithPrompt:andSendTo:withSelector:highlight: chooseListFont chooseMenuFont chooseSystemFont chooseWindowTitleFont fontConfigurationMenu presentMvcFontConfigurationMenu printStandardSystemFonts refreshFontSettings restoreDefaultFonts setBalloonHelpFontTo: setButtonFontTo: setCodeFontTo: setDefaultFonts: setFlapsFontTo: setListFontTo: setMenuFontTo: setSystemFontTo: setWindowTitleFontTo: standardBalloonHelpFont standardButtonFont standardCodeFont standardDefaultTextFont standardListFont standardMenuFont windowTitleFont windowTitleStyle)
('get/set' disable: disableGently: doesNotUnderstand: enable: enableGently: enableOrDisable:asPer: setPreference:toValue: togglePreference: valueOfFlag: valueOfFlag:ifAbsent:)
('halos' classicHaloSpecs classicHalosInForce customHaloSpecs customHalosInForce editCustomHalos haloSpecifications haloSpecificationsForWorld haloTheme iconicHaloSpecifications iconicHalosInForce installClassicHaloSpecs installCustomHaloSpecs installHaloSpecsFromArray: installHaloTheme: installIconicHaloSpecs installSimpleHaloSpecs resetHaloSpecifications showChooseGraphicHaloHandle simpleFullHaloSpecifications simpleHalosInForce)
('hard-coded prefs' browseToolClass cmdGesturesEnabled cmdKeysInText debugMenuItemsInvokableFromScripts desktopMenuTitle isFlagship metaMenuDisabled preserveCommandExcursions suppressWindowTitlesInInstanceBrowsers useCategoryListsInViewers)
('initialization' chooseInitialSettings compileAccessMethodForPreference: initializeDictionaryOfPreferences removePreference: setPreferencesFrom:)
('menu parameters' menuBorderColor menuBorderWidth menuColor menuLineColor menuTitleBorderColor menuTitleBorderWidth menuTitleColor restoreDefaultMenuParameters)
('misc' addModelItemsToWindowMenu: browseThemes cleanUp defaultValueTableForCurrentRelease giveHelpWithPreferences installTheme: menuColorString offerThemesMenu okayToChangeProjectLocalnessOf: roundedCornersString setFlag:toValue:during: soundEnablingString staggerPolicyString themeChoiceButtonOfColor:font: toggleMenuColorPolicy toggleRoundedCorners toggleSoundEnabling toggleWindowPolicy wantsChangeSetLogging)
('parameters' acceptAnnotationsFrom: annotationEditingWindow annotationInfo defaultAnnotationRequests defaultAnnotationRequests: defaultAuthorName defaultPaintingExtent desktopColor desktopColor: editAnnotations expungeParameter: initializeParameters inspectParameters maxBalloonHelpLineLength parameterAt: parameterAt:default: parameterAt:ifAbsent: parameterAt:ifAbsentPut: scrollBarColor scrollBarWidth setDefaultAnnotationInfo setParameter:to:)
('personalization' compileHardCodedPref:enable: disableProgrammerFacilities enableProgrammerFacilities letUserPersonalizeMenu loadPreferencesFrom: personalizeUserMenu: restorePersonalPreferences restorePreferencesFromDisk savePersonalPreferences storePreferencesIn: storePreferencesToDisk)
('preference-object access' allPreferenceObjects preferenceAt: preferenceAt:ifAbsent:)
('preferences panel' initialExtent inspectPreferences listOfCategories openPreferencesInspector preferenceObjectsInCategory:)
('reacting to change' annotationPanesChanged optionalButtonsChanged roundedWindowCornersChanged setNotificationParametersForStandardPreferences smartUpdatingChanged)
('scrollbar parameters' fontFactor)
('standard queries' abbreviatedBrowserButtons allowCelesteTell alphabeticalProjectMenu alternativeBrowseIt alternativeButtonsInScrollBars alternativeScrollbarLook alternativeWindowBoxesLook alternativeWindowLook alwaysHideHScrollbar alwaysShowHScrollbar alwaysShowVScrollbar annotationPanes ansiAssignmentOperatorWhenPrettyPrinting areaFillsAreTolerant areaFillsAreVeryTolerant autoAccessors automaticFlapLayout automaticKeyGeneration automaticPlatformSettings automaticViewerPlacement balloonHelpEnabled balloonHelpInMessageLists browseWithDragNDrop browseWithPrettyPrint browserNagIfNoClassComment browserShowsPackagePane canRecordWhilePlaying caseSensitiveFinds cautionBeforeClosing changeSetVersionNumbers checkForSlips checkForUnsavedProjects classicNavigatorEnabled classicNewMorphMenu clickOnLabelToEdit cmdDotEnabled collapseWindowsInPlace colorWhenPrettyPrinting compactViewerFlaps compressFlashImages confirmFirstUseOfStyle conversionMethodsAtFileOut cpuWatcherEnabled debugHaloHandle debugLogTimestamp debugPrintSpaceLog debugShowDamage decorateBrowserButtons diffsInChangeList diffsWithPrettyPrint dismissAllOnOptionClose dragNDropWithAnimation duplicateControlAndAltKeys enableLocalSave extraDebuggerButtons extractFlashInHighQuality extractFlashInHighestQuality fastDragWindowForMorphic fullScreenLeavesDeskMargins gradientMenu gradientScrollBars haloEnclosesFullBounds haloTransitions higherPerformance honorDesktopCmdKeys ignoreStyleIfOnlyBold inboardScrollbars includeSoundControlInNavigator infiniteUndo logDebuggerStackToFile magicHalos menuAppearance3d menuButtonInToolPane menuColorFromWorld menuKeyboardControl menuWithIcons modalColorPickers mouseOverForKeyboardFocus mvcProjectsAllowed navigatorOnLeftEdge noviceMode okToReinitializeFlaps optionalButtons passwordsOnPublish personalizedWorldMenu postscriptStoredAsEPS preserveTrash printAlternateSyntax projectViewsInWindows projectZoom projectsSentToDisk promptForUpdateServer propertySheetFromHalo readDocumentAtStartup restartAlsoProceeds reverseWindowStagger roundedMenuCorners roundedWindowCorners scrollBarsNarrow scrollBarsOnRight scrollBarsWithoutMenuButton securityChecksEnabled selectionsMayShrink selectiveHalos showBoundsInHalo showDeprecationWarnings showDirectionForSketches showDirectionHandles showFlapsWhenPublishing showLinesInHierarchyViews showSecurityStatus showSharedFlaps signProjectFiles simpleMenus slideDismissalsToTrash smartUpdating soundQuickStart soundStopWhenDone soundsEnabled standaloneSecurityChecksEnabled startInUntrustedDirectory swapControlAndAltKeys swapMouseButtons systemWindowEmbedOK thoroughSenders timeStampsInMenuTitles translationWithBabel turnOffPowerManager twentyFourHourFileStamps twoSidedPoohTextures uniqueNamesInHalos unlimitedPaintArea updateSavesFile useButtonProprtiesToFire useFileList2 useUndo viewersInFlaps warnAboutInsecureContent warnIfNoChangesFile warnIfNoSourcesFile warningForMacOSFileNameLength wordStyleCursorMovement)
('text highlighting' chooseInsertionPointColor chooseKeyboardFocusColor chooseTextHighlightColor initializeTextHighlightingParameters insertionPointColor insertionPointColor: keyboardFocusColor keyboardFocusColor: textHighlightColor textHighlightColor:)
('themes' brightSqueak magdeburg outOfTheBox paloAlto personal smalltalk80 westwood)
('window colors' darkenStandardWindowPreferences installBrightWindowColors installMissingWindowColors installPastelWindowColors installUniformWindowColors installWindowColorsVia: lightenStandardWindowPreferences setWindowColorFor:to: windowColorFor: windowColorHelp windowColorTable windowSpecificationPanel)
!

CurveMorph class removeSelector: #initialize!
CurveMorph class removeSelector: #registerInFlapsRegistry!
CurveMorph class removeSelector: #supplementaryPartsDescriptions!
CurveMorph class removeSelector: #unload!
PolygonMorph class removeSelector: #initialize!
PolygonMorph class removeSelector: #registerInFlapsRegistry!
PolygonMorph class removeSelector: #supplementaryPartsDescriptions!
PolygonMorph class removeSelector: #unload!
BalloonMorph removeSelector: #isBalloonHelp!
PolygonMorph removeSelector: #convertToCurrentVersion:refStream:!
PolygonMorph removeSelector: #drawPostscriptOn:!
PolygonMorph removeSelector: #heading:!
PolygonMorph removeSelector: #justDroppedInto:event:!
Point removeSelector: #encodeForRemoteCanvas!
Point removeSelector: #encodePostscriptOn:!
PluggableTextView removeSelector: #convertToCurrentVersion:refStream:!
PluggableTextMorphWithModel removeSelector: #variableDocks!
PluggableTextMorph removeSelector: #eToyGetMainFont!
PluggableTextMorph removeSelector: #selectionAsTiles!
PluggableTextMorph removeSelector: #tileForIt!
PianoRollScoreMorph removeSelector: #addMovieClipPlayer!
Pen removeSelector: #arrowHeadFrom:to:forPlayer:!
PasteUpMorph class removeSelector: #additionsToViewerCategories!
PasteUpMorph class removeSelector: #initialize!
PasteUpMorph class removeSelector: #registerInFlapsRegistry!
PasteUpMorph class removeSelector: #supplementaryPartsDescriptions!
PasteUpMorph class removeSelector: #unload!
PasteUpMorph removeSelector: #abandonCostumeHistory!
PasteUpMorph removeSelector: #abandonOldReferenceScheme!
PasteUpMorph removeSelector: #accommodateFlap:!
PasteUpMorph removeSelector: #activateObjectsTool!
PasteUpMorph removeSelector: #activeHand:!
PasteUpMorph removeSelector: #adaptedToWorld:!
PasteUpMorph removeSelector: #addCenteredAtBottom:offset:!
PasteUpMorph removeSelector: #addGlobalFlaps!
PasteUpMorph removeSelector: #addImageToPenTrailsFor:!
PasteUpMorph removeSelector: #addMorphInLayer:!
PasteUpMorph removeSelector: #addPenMenuItems:hand:!
PasteUpMorph removeSelector: #addPenTrailsMenuItemsTo:!
PasteUpMorph removeSelector: #addPlayfieldMenuItems:hand:!
PasteUpMorph removeSelector: #addRemoteClient:!
PasteUpMorph removeSelector: #addStackMenuItems:hand:!
PasteUpMorph removeSelector: #addUndoItemsTo:!
PasteUpMorph removeSelector: #addViewingItemsTo:!
PasteUpMorph removeSelector: #allScriptEditors!
PasteUpMorph removeSelector: #allScriptors!
PasteUpMorph removeSelector: #allTileScriptingElements!
PasteUpMorph removeSelector: #alwaysShowThumbnail!
PasteUpMorph removeSelector: #arrowheadsOnAllPens!
PasteUpMorph removeSelector: #arrowsForAllPens!
PasteUpMorph removeSelector: #assureFlapTabsFitOnScreen!
PasteUpMorph removeSelector: #assureFlapWidth:!
PasteUpMorph removeSelector: #assureNotPaintingEvent:!
PasteUpMorph removeSelector: #autoExpansionString!
PasteUpMorph removeSelector: #autoLineLayout!
PasteUpMorph removeSelector: #autoLineLayout:!
PasteUpMorph removeSelector: #autoLineLayoutString!
PasteUpMorph removeSelector: #autoViewingString!
PasteUpMorph removeSelector: #automaticPhraseExpansion!
PasteUpMorph removeSelector: #automaticViewing!
PasteUpMorph removeSelector: #automaticViewing:!
PasteUpMorph removeSelector: #backgroundForm!
PasteUpMorph removeSelector: #backgroundForm:!
PasteUpMorph removeSelector: #backgroundSketch!
PasteUpMorph removeSelector: #backgroundSketch:!
PasteUpMorph removeSelector: #batchPenTrails!
PasteUpMorph removeSelector: #batchPenTrails:!
PasteUpMorph removeSelector: #batchPenTrailsString!
PasteUpMorph removeSelector: #becomeLikeAHolder!
PasteUpMorph removeSelector: #behaveLikeAHolderString!
PasteUpMorph removeSelector: #behaveLikeHolder!
PasteUpMorph removeSelector: #behaveLikeHolder:!
PasteUpMorph removeSelector: #behavingLikeAHolder!
PasteUpMorph removeSelector: #bringFlapTabsToFront!
PasteUpMorph removeSelector: #buildDebugMenu:!
PasteUpMorph removeSelector: #cachedOrNewThumbnailFrom:!
PasteUpMorph removeSelector: #chooseClickTarget!
PasteUpMorph removeSelector: #clearCommandHistory!
PasteUpMorph removeSelector: #clearTurtleTrails!
PasteUpMorph removeSelector: #closedViewerFlapTabs!
PasteUpMorph removeSelector: #colorAt:belowMorph:!
PasteUpMorph removeSelector: #commandHistory!
PasteUpMorph removeSelector: #connectRemoteUser!
PasteUpMorph removeSelector: #connectRemoteUserWithName:picture:andIPAddress:!
PasteUpMorph removeSelector: #convertAlignment!
PasteUpMorph removeSelector: #convertRemoteClientToBuffered:!
PasteUpMorph removeSelector: #convertToCurrentVersion:refStream:!
PasteUpMorph removeSelector: #correspondingFlapTab!
PasteUpMorph removeSelector: #createOrResizeTrailsForm!
PasteUpMorph removeSelector: #currentVocabulary!
PasteUpMorph removeSelector: #currentVocabularyFor:!
PasteUpMorph removeSelector: #deEmphasizeViewMVC:!
PasteUpMorph removeSelector: #defersHaloOnClickTo:!
PasteUpMorph removeSelector: #deleteAllFlapArtifacts!
PasteUpMorph removeSelector: #deleteBackgroundPainting!
PasteUpMorph removeSelector: #deleteGlobalFlapArtifacts!
PasteUpMorph removeSelector: #detachableScriptingSpace!
PasteUpMorph removeSelector: #disconnectAllRemoteUsers!
PasteUpMorph removeSelector: #disconnectRemoteUser!
PasteUpMorph removeSelector: #displayWorldAsTwoTone!
PasteUpMorph removeSelector: #doOneCycleInBackground!
PasteUpMorph removeSelector: #dotsForAllPens!
PasteUpMorph removeSelector: #drawPenTrailFor:from:to:!
PasteUpMorph removeSelector: #elementCount!
PasteUpMorph removeSelector: #enableGlobalFlaps!
PasteUpMorph removeSelector: #endDrawing:!
PasteUpMorph removeSelector: #fenceEnabled!
PasteUpMorph removeSelector: #fenceEnabled:!
PasteUpMorph removeSelector: #fenceEnabledString!
PasteUpMorph removeSelector: #findAPreferencesPanel:!
PasteUpMorph removeSelector: #flapTab!
PasteUpMorph removeSelector: #flapTabs!
PasteUpMorph removeSelector: #getCharacters!
PasteUpMorph removeSelector: #getWorldMenu:!
PasteUpMorph removeSelector: #gridModulus!
PasteUpMorph removeSelector: #gridModulus:!
PasteUpMorph removeSelector: #gridOrigin!
PasteUpMorph removeSelector: #gridOrigin:!
PasteUpMorph removeSelector: #gridPoint:!
PasteUpMorph removeSelector: #gridSpec!
PasteUpMorph removeSelector: #gridSpecPut:!
PasteUpMorph removeSelector: #gridVisible!
PasteUpMorph removeSelector: #gridVisibleOnOff!
PasteUpMorph removeSelector: #gridVisibleString!
PasteUpMorph removeSelector: #griddingOn!
PasteUpMorph removeSelector: #griddingOnOff!
PasteUpMorph removeSelector: #griddingString!
PasteUpMorph removeSelector: #haloMorphOrNil!
PasteUpMorph removeSelector: #hasRemoteServer!
PasteUpMorph removeSelector: #heightForThumbnails!
PasteUpMorph removeSelector: #hideAllPlayers!
PasteUpMorph removeSelector: #hideFlapsOtherThan:ifClingingTo:!
PasteUpMorph removeSelector: #hideViewerFlaps!
PasteUpMorph removeSelector: #hideViewerFlapsOtherThanFor:!
PasteUpMorph removeSelector: #impartPrivatePresenter!
PasteUpMorph removeSelector: #imposeListViewSortingBy:retrieving:!
PasteUpMorph removeSelector: #indicateCursor!
PasteUpMorph removeSelector: #indicateCursor:!
PasteUpMorph removeSelector: #indicateCursorString!
PasteUpMorph removeSelector: #innocuousName!
PasteUpMorph removeSelector: #installFlaps!
PasteUpMorph removeSelector: #isCandidateForAutomaticViewing!
PasteUpMorph removeSelector: #isOpenForDragNDropString!
PasteUpMorph removeSelector: #isPartsBin!
PasteUpMorph removeSelector: #isPartsBin:!
PasteUpMorph removeSelector: #isPartsBinString!
PasteUpMorph removeSelector: #justDroppedInto:event:!
PasteUpMorph removeSelector: #keyboardNavigationHandler:!
PasteUpMorph removeSelector: #laySubpartsOutInOneRow!
PasteUpMorph removeSelector: #layoutChanged!
PasteUpMorph removeSelector: #liftAllPens!
PasteUpMorph removeSelector: #linesAndArrowsForAllPens!
PasteUpMorph removeSelector: #linesForAllPens!
PasteUpMorph removeSelector: #localFlapTabs!
PasteUpMorph removeSelector: #lowerAllPens!
PasteUpMorph removeSelector: #makeDetachable!
PasteUpMorph removeSelector: #maxHeightToAvoidThumbnailing!
PasteUpMorph removeSelector: #maximumThumbnailWidth!
PasteUpMorph removeSelector: #modernizeBJProject!
PasteUpMorph removeSelector: #morphicLayerNumber!
PasteUpMorph removeSelector: #mouseOverHalosString!
PasteUpMorph removeSelector: #nextPage!
PasteUpMorph removeSelector: #noArrowheadsOnAllPens!
PasteUpMorph removeSelector: #noteNewLocation:forPlayer:!
PasteUpMorph removeSelector: #notePenDown:forPlayer:at:!
PasteUpMorph removeSelector: #offsetForAccommodating:onEdge:!
PasteUpMorph removeSelector: #openScrapsBook:!
PasteUpMorph removeSelector: #openWithTitle:cautionOnClose:!
PasteUpMorph removeSelector: #originAtCenter!
PasteUpMorph removeSelector: #originAtCenterString!
PasteUpMorph removeSelector: #padding:!
PasteUpMorph removeSelector: #paintArea!
PasteUpMorph removeSelector: #paintAreaFor:!
PasteUpMorph removeSelector: #paintBackground!
PasteUpMorph removeSelector: #paintingFlapTab!
PasteUpMorph removeSelector: #patchAt:without:andNothingAbove:!
PasteUpMorph removeSelector: #playfieldOptionsMenu!
PasteUpMorph removeSelector: #positionNear:forExtent:adjustmentSuggestion:!
PasteUpMorph removeSelector: #presentCardAndStackMenu!
PasteUpMorph removeSelector: #presentPlayfieldMenu!
PasteUpMorph removeSelector: #presentViewMenu!
PasteUpMorph removeSelector: #presenter!
PasteUpMorph removeSelector: #previousPage!
PasteUpMorph removeSelector: #printScriptSummary!
PasteUpMorph removeSelector: #putUpPenTrailsSubmenu!
PasteUpMorph removeSelector: #recreateScripts!
PasteUpMorph removeSelector: #rectifyCursor!
PasteUpMorph removeSelector: #referencePlayfield!
PasteUpMorph removeSelector: #relaunchAllViewers!
PasteUpMorph removeSelector: #releaseRemoteServer!
PasteUpMorph removeSelector: #releaseSqueakPages!
PasteUpMorph removeSelector: #releaseViewers!
PasteUpMorph removeSelector: #remoteServer!
PasteUpMorph removeSelector: #remoteServer:!
PasteUpMorph removeSelector: #removeAccommodationForFlap:!
PasteUpMorph removeSelector: #removeAllViewers!
PasteUpMorph removeSelector: #removeRemoteClient:!
PasteUpMorph removeSelector: #replaceTallSubmorphsByThumbnails!
PasteUpMorph removeSelector: #reportLocalAddress!
PasteUpMorph removeSelector: #repositionFlapsAfterScreenSizeChange!
PasteUpMorph removeSelector: #residesInPartsBin!
PasteUpMorph removeSelector: #resizeToFit!
PasteUpMorph removeSelector: #resizeToFitString!
PasteUpMorph removeSelector: #respondToCommand:bySending:to:!
PasteUpMorph removeSelector: #restartWorldCycleWithEvent:!
PasteUpMorph removeSelector: #restoreBoundsOfSubmorphs!
PasteUpMorph removeSelector: #restoreFlapsDisplay!
PasteUpMorph removeSelector: #roundUpStrays!
PasteUpMorph removeSelector: #saveAsWorld!
PasteUpMorph removeSelector: #saveBoundsOfSubmorphs!
PasteUpMorph removeSelector: #scriptSelectorToTriggerFor:!
PasteUpMorph removeSelector: #scriptorForTextualScript:ofPlayer:!
PasteUpMorph removeSelector: #selectedRect!
PasteUpMorph removeSelector: #sendTextContentsBackToDonor!
PasteUpMorph removeSelector: #setGridSpec!
PasteUpMorph removeSelector: #setPartsBinStatusTo:!
PasteUpMorph removeSelector: #setThumbnailHeight!
PasteUpMorph removeSelector: #showAllPlayers!
PasteUpMorph removeSelector: #showStatusOfAllScripts!
PasteUpMorph removeSelector: #showThumbnailString!
PasteUpMorph removeSelector: #showingListView!
PasteUpMorph removeSelector: #smallThumbnailForPageSorter!
PasteUpMorph removeSelector: #someHalo!
PasteUpMorph removeSelector: #sortSubmorphsBy:!
PasteUpMorph removeSelector: #specialNameInModelFor:!
PasteUpMorph removeSelector: #standardPlayerHit!
PasteUpMorph removeSelector: #standardSystemController!
PasteUpMorph removeSelector: #startBackgroundProcess!
PasteUpMorph removeSelector: #startRunningAll!
PasteUpMorph removeSelector: #stepAll!
PasteUpMorph removeSelector: #stepListSummary!
PasteUpMorph removeSelector: #stopRunningAll!
PasteUpMorph removeSelector: #storeProjectsAsSegments!
PasteUpMorph removeSelector: #tellAllContents:!
PasteUpMorph removeSelector: #thumbnailForPageSorter!
PasteUpMorph removeSelector: #toggleAlwaysShowThumbnail!
PasteUpMorph removeSelector: #toggleAutoLineLayout!
PasteUpMorph removeSelector: #toggleAutomaticPhraseExpansion!
PasteUpMorph removeSelector: #toggleAutomaticViewing!
PasteUpMorph removeSelector: #toggleBatchPenTrails!
PasteUpMorph removeSelector: #toggleBehaveLikeAHolder!
PasteUpMorph removeSelector: #toggleClassicNavigatorIfAppropriate!
PasteUpMorph removeSelector: #toggleFenceEnabled!
PasteUpMorph removeSelector: #toggleIndicateCursor!
PasteUpMorph removeSelector: #toggleIsPartsBin!
PasteUpMorph removeSelector: #toggleMouseOverHalos!
PasteUpMorph removeSelector: #toggleOriginAtCenter!
PasteUpMorph removeSelector: #toggleResizeToFit!
PasteUpMorph removeSelector: #trailMorph!
PasteUpMorph removeSelector: #trailStyleForAllPens:!
PasteUpMorph removeSelector: #transferRemoteServerFrom:!
PasteUpMorph removeSelector: #triggerClosingScripts!
PasteUpMorph removeSelector: #triggerOpeningScripts!
PasteUpMorph removeSelector: #undoOrRedoCommand!
PasteUpMorph removeSelector: #updateStatusForAllScriptEditors!
PasteUpMorph removeSelector: #updateSubmorphThumbnails!
PasteUpMorph removeSelector: #updateTrailsForm!
PasteUpMorph removeSelector: #validateMouseEvent:!
PasteUpMorph removeSelector: #valueAtCursor!
PasteUpMorph removeSelector: #valueAtCursor:!
PasteUpMorph removeSelector: #viewByIcon!
PasteUpMorph removeSelector: #viewByName!
PasteUpMorph removeSelector: #viewBySize!
PasteUpMorph removeSelector: #viewNonOverlapping!
PasteUpMorph removeSelector: #viewerFlapTabFor:!
PasteUpMorph removeSelector: #viewingByIconString!
PasteUpMorph removeSelector: #viewingByNameString!
PasteUpMorph removeSelector: #viewingBySizeString!
PasteUpMorph removeSelector: #viewingNonOverlappingString!
PasteUpMorph removeSelector: #viewingNormally!
PasteUpMorph removeSelector: #wantsHaloFor:!
PasteUpMorph removeSelector: #wantsMouseOverHalos!
PasteUpMorph removeSelector: #wantsMouseOverHalos:!
BorderedMorph subclass: #PasteUpMorph
	instanceVariableNames: 'model cursor backgroundMorph worldState'
	classVariableNames: 'DisableDeferredUpdates MinCycleLapse'
	poolDictionaries: ''
	category: 'Morphic-Worlds'!

!PasteUpMorph reorganize!
('WiW support' shouldGetStepsFrom:)
('accessing' modelOrNil useRoundedCorners)
('alarms-scheduler' addAlarm:withArguments:for:at: removeAlarm:for:)
('caching' releaseCachedState)
('change reporting' invalidRect:from:)
('classification' isPlayfieldLike isWorldMorph)
('copying' veryDeepCopyWith:)
('cursor' cursorWrapped: numberAtCursor)
('display' gradientFillColor: setGradientColor:)
('drawing' drawOn:)
('dropping/grabbing' acceptDroppingMorph:event: dropEnabled morphToDropFrom: repelsMorph:event: wantsDroppedMorph:event:)
('e-toy support' cursor cursor:)
('event handling' dropFiles: handlesKeyboard: handlesMouseDown: keyStroke: morphToGrab: mouseDown: mouseUp: wantsDropFiles: wantsKeyboardFocusFor:)
('events-processing' processEvent:using:)
('geometry' extent: position:)
('geometry testing' fullContainsPoint:)
('halos and balloon help' wantsDirectionHandles wantsHaloFromClick)
('initialization' becomeActiveDuring: defaultBorderColor defaultBorderWidth defaultColor initialize newResourceLoaded)
('interaction loop' doOneCycleNow)
('menu & halo' addCustomMenuItems:hand: addScalingMenuItems:hand: addWorldHaloMenuItemsTo:hand: addWorldToggleItemsToHaloMenu: defineApplicationView defineFactoryView deleteBalloonTarget: reformulateUpdatingMenus saveOnFile showApplicationView showExpandedView showFactoryView showFullView showReducedView transformToShow:)
('misc' cartesianOrigin mouseX mouseY nameForCopyIfAlreadyNamed: prepareToBeSaved unhideHiddenObjects)
('model' createCustomModel model setModel:)
('options')
('painting' drawSubmorphsOn: makeNewDrawingWithin paintingBoundsAround: prepareToPaint prepareToPaint: reasonablePaintingExtent)
('parts bin' initializeToStandAlone)
('printing' printOn:)
('project' project)
('project state' canvas firstHand hands handsDo: handsReverseDo: isStepping: isStepping:selector: listOfSteppingMorphs stepListSize steppingMorphsNotInWorld viewBox viewBox:)
('stepping' cleanseStepList runLocalStepMethods runStepMethods startStepping: startStepping:at:selector:arguments:stepTime: stopStepping: stopStepping:selector:)
('stepping and presenter' step)
('structure' activeHand world)
('submorphs-accessing' allMorphsDo: morphsInFrontOf:overlapping:do:)
('submorphs-add/remove' addAllMorphs: addMorphFront:)
('testing' stepTime)
('user interface' modelWakeUp)
('viewer' defaultNameStemForInstances)
('visual properties' canHaveFillStyles)
('world menu' bringWindowsFullOnscreen buildWorldMenu: closeUnchangedWindows collapseAll collapseNonWindows commandKeySelectors defaultDesktopCommandKeyTriplets deleteNonWindows dispatchCommandKeyInWorld:event: drawingClass expandAll extractScreenRegion:andPutSketchInHand: findAChangeSorter: findAFileList: findAMessageNamesWindow: findATranscript: findAWindowSatisfying:orMakeOneUsing: findDirtyBrowsers: findDirtyWindows: findWindow: grabDrawingFromScreen: grabFloodFromScreen: grabLassoFromScreen: grabRubberBandFromScreen: initializeDesktopCommandKeySelectors invokeWorldMenu: keyboardNavigationHandler keystrokeInWorld: makeNewDrawing: makeNewDrawing:at: newDrawingFromMenu: openRecentSubmissionsBrowser: putUpDesktopMenu: putUpNewMorphMenu putUpWorldMenu: putUpWorldMenuFromEscapeKey yellowButtonClickOnDesktopWithEvent:)
('world state' abandonAllHalos abandonVocabularyPreference addHand: addMorph:centeredNear: addMorphsAndModel: allNonFlapRelatedSubmorphs assureNotPaintingElse: assuredCanvas beWorldForProject: checkCurrentHandForObjectToPaste checkCurrentHandForObjectToPaste2 currentNaturalLanguage deleteAllHalos displayWorld displayWorldNonIncrementally displayWorldSafely doOneCycle doOneSubCycle dragThroughOnDesktop: embeddedProjectDisplayMode exit flashRects:color: fullRepaintNeeded goBack haloMorphs handleFatalDrawingError: initForProject: install installAsActiveSubprojectIn:at:titled: installAsActiveSubprojectIn:titled: installVectorVocabulary jumpToProject open optimumExtentFromAuthor paintBox paintBoxOrNil pauseEventRecorder privateOuterDisplayWorld removeHand: repairEmbeddedWorlds restoreDisplay restoreMorphicDisplay sketchEditorOrNil sleep startSteppingSubmorphsOf:)
('private' privateFullMoveBy: privateMoveBy: privateRemoveMorph:)
!

MethodNode removeSelector: #asMorphicSyntaxIn:!
MessageNode removeSelector: #asMorphicSyntaxIn:!
LiteralNode removeSelector: #asMorphicSyntaxIn:!
LiteralNode removeSelector: #explanation!
CascadeNode removeSelector: #asMorphicSyntaxIn:!
BraceNode removeSelector: #asMorphicSyntaxIn:!
BlockNode removeSelector: #asMorphicCollectSyntaxIn:!
BlockNode removeSelector: #asMorphicSyntaxIn:!
AssignmentNode removeSelector: #asMorphicSyntaxIn:!
AssignmentNode removeSelector: #explanation!
ParseNode removeSelector: #addCommentToMorph:!
ParseNode removeSelector: #asMorphicSyntaxIn:!
ParseNode removeSelector: #explanation!
ParagraphEditor removeSelector: #languagePrefs!
ParagraphEditor removeSelector: #selectionAsTiles!
ParagraphEditor removeSelector: #translateIt!
ParagraphEditor removeSelector: #verifyWordSpelling!
ParagraphEditor removeSelector: #wordDefinition!
PaintInvokingMorph class removeSelector: #initialize!
PaintInvokingMorph class removeSelector: #registerInFlapsRegistry!
PaintInvokingMorph class removeSelector: #unload!
PaintInvokingMorph removeSelector: #isCandidateForAutomaticViewing!
PaintBoxMorph removeSelector: #isCandidateForAutomaticViewing!
PaintBoxMorph removeSelector: #updateReferencesUsing:!
PNGReadWriter class removeSelector: #test1!
MethodInterface removeSelector: #initializeFromEToyCommandSpec:category:!
MethodInterface removeSelector: #initializeFromEToySlotSpec:!
MethodInterface removeSelector: #initializeSetterFromEToySlotSpec:!
MorphicModel class removeSelector: #officialClass!
MorphicEvent class removeSelector: #fromStringArray:!
ImageMorph initialize!
ImageMorph class removeSelector: #registerInFlapsRegistry!
ImageMorph class removeSelector: #unload!
EllipseMorph class removeSelector: #initialize!
EllipseMorph class removeSelector: #registerInFlapsRegistry!
EllipseMorph class removeSelector: #unload!
Morph class removeSelector: #addPartsDescriptorQuadsTo:if:!
Morph class removeSelector: #additionsToViewerCategories!
Morph class removeSelector: #additionsToViewerCategory:!
Morph class removeSelector: #additionsToViewerCategoryBasic!
Morph class removeSelector: #additionsToViewerCategoryColorAndBorder!
Morph class removeSelector: #additionsToViewerCategoryDragAndDrop!
Morph class removeSelector: #additionsToViewerCategoryGeometry!
Morph class removeSelector: #additionsToViewerCategoryLayout!
Morph class removeSelector: #additionsToViewerCategoryMiscellaneous!
Morph class removeSelector: #additionsToViewerCategoryMotion!
Morph class removeSelector: #additionsToViewerCategoryObservation!
Morph class removeSelector: #additionsToViewerCategoryPenUse!
Morph class removeSelector: #additionsToViewerCategoryScripting!
Morph class removeSelector: #additionsToViewerCategoryScripts!
Morph class removeSelector: #additionsToViewerCategoryTests!
Morph class removeSelector: #noteCompilationOf:meta:!
Morph class removeSelector: #partName:categories:documentation:sampleImageForm:!
Morph class removeSelector: #supplementaryPartsDescriptions!
Morph class removeSelector: #vectorAdditions!
Language class removeSelector: #recreateFlaps!
HTTPClient class removeSelector: #tellAFriend:url:name:!
FreeTranslation class removeSelector: #openScamperOn:!
FreeTranslation class removeSelector: #translatePanel:fromTo:!
DualChangeSorter class removeSelector: #registerInFlapsRegistry!
DualChangeSorter class removeSelector: #unload!
CurrentProjectRefactoring class removeSelector: #currentToggleFlapsSuppressed!
CurrentProjectRefactoring class removeSelector: #isFlapEnabled:!
Object class removeSelector: #newUserInstance!
Number removeSelector: #newTileMorphRepresentative!
Number removeSelector: #vocabularyDemanded!
NewHandleMorph removeSelector: #undoGrabCommand!
MorphicUnknownEvent removeSelector: #convertToCurrentVersion:refStream:!
MorphicTransform removeSelector: #encodeForRemoteCanvas!
ComponentLikeModel removeSelector: #addPinFromSpec:!
ComponentLikeModel removeSelector: #deleteComponent!
ComponentLikeModel removeSelector: #extent:!
ComponentLikeModel removeSelector: #initComponentIn:!
ComponentLikeModel removeSelector: #justDroppedInto:event:!
ComponentLikeModel removeSelector: #pinsDo:!
ComponentLikeModel removeSelector: #showPins!
MorphicModel removeSelector: #allKnownNames!
MorphicEvent removeSelector: #convertToCurrentVersion:refStream:!
MorphExtension removeSelector: #actorState:!
MorphExtension removeSelector: #convertProperty:toValue:!
MorphExtension removeSelector: #updateReferencesUsing:!
MenuMorph removeSelector: #isCandidateForAutomaticViewing!
MenuMorph removeSelector: #undoGrabCommand!
MatrixTransformMorph removeSelector: #heading:!
ImageMorph removeSelector: #couldHoldSeparateDataForEachInstance!
ImageMorph removeSelector: #currentDataValue!
ImageMorph removeSelector: #drawPostscriptOn:!
ImageMorph removeSelector: #variableDocks!
HandleMorph removeSelector: #isCandidateForAutomaticViewing!
HandMorph removeSelector: #adaptedToWorld:!
HandMorph removeSelector: #autoFocusRectangleBoundsFor:!
HandMorph removeSelector: #disableGenieFocus!
HandMorph removeSelector: #enableGenie!
HandMorph removeSelector: #focusStartEvent!
HandMorph removeSelector: #genieGestureProcessor!
HandMorph removeSelector: #isGenieAvailable!
HandMorph removeSelector: #isGenieEnabled!
HandMorph removeSelector: #isGenieFocused!
HandMorph removeSelector: #trailMorph!
Morph subclass: #HandMorph
	instanceVariableNames: 'mouseFocus keyboardFocus eventListeners mouseListeners keyboardListeners mouseClickState mouseOverHandler lastMouseEvent targetOffset damageRecorder cacheCanvas cachedCanvasHasHoles temporaryCursor temporaryCursorOffset hasChanged savedPatch userInitials lastEventBuffer'
	classVariableNames: 'DoubleClickTime EventStats NewEventRules NormalCursor PasteBuffer ShowEvents'
	poolDictionaries: 'EventSensorConstants'
	category: 'Morphic-Kernel'!

!HandMorph reorganize!
('accessing' colorForInsets lastEvent mouseOverHandler targetOffset userInitials userPicture userPicture:)
('balloon help' balloonHelp balloonHelp: deleteBalloonTarget: removePendingBalloonFor: spawnBalloonFor: triggerBalloonFor:after:)
('caching' releaseCachedState)
('change reporting' invalidRect:from:)
('classification' isHandMorph)
('copying' veryDeepCopyWith:)
('cursor' cursorBounds showTemporaryCursor: showTemporaryCursor:hotSpotOffset: temporaryCursor)
('double click support' resetClickState waitForClicksOrDrag:event: waitForClicksOrDrag:event:selectors:threshold:)
('drawing' drawOn: fullDrawOn: hasChanged hasUserInformation needsToBeDrawn nonCachingFullDrawOn: restoreSavedPatchOn: savePatchFrom: shadowForm updateCacheCanvas:)
('drop shadows' shadowOffset)
('event handling' checkForMoreKeyboard cursorPoint flushEvents noticeMouseOver:event: pauseEventRecorderIn: processEvents)
('events-processing' handleEvent: isCapturingGesturePoints)
('focus handling' keyboardFocus keyboardFocus: mouseFocus mouseFocus: newKeyboardFocus: newMouseFocus: newMouseFocus:event: releaseAllFoci releaseKeyboardFocus releaseKeyboardFocus: releaseMouseFocus releaseMouseFocus:)
('geometry' position position: userInitials:andPicture:)
('grabbing/dropping' attachMorph: dropMorph:event: dropMorphs dropMorphs: grabMorph:from: targetOffset:)
('halo handling' halo: obtainHalo: releaseHalo: removeHaloFromClick:on: removePendingHaloFor: spawnMagicHaloFor: triggerHaloFor:after:)
('halos and balloon help' halo)
('initialization' initForEvents initialize interrupted resourceJustLoaded)
('layout' fullBounds)
('listeners' addEventListener: addKeyboardListener: addListener:to: addMouseListener: eventListeners eventListeners: keyboardListeners keyboardListeners: mouseListeners mouseListeners: removeEventListener: removeKeyboardListener: removeListener:from: removeMouseListener:)
('meta-actions' copyToPasteBuffer: grabMorph:)
('objects from disk' objectForDataStream:)
('paste buffer' objectToPaste pasteBuffer pasteBuffer: pasteMorph)
('pen')
('scripting')
('updating' changed)
('private events' generateDropFilesEvent: generateKeyboardEvent: generateMouseEvent: mouseTrailFrom: moveToEvent: sendEvent:focus: sendEvent:focus:clear: sendFocusEvent:to:clear: sendKeyboardEvent: sendListenEvent:to: sendMouseEvent:)
!

HaloMorph removeSelector: #addPaintBgdHandle:!
HaloMorph removeSelector: #addScriptHandle:!
HaloMorph removeSelector: #addTileHandle:!
HaloMorph removeSelector: #addViewHandle:!
HaloMorph removeSelector: #addViewingHandle:!
HaloMorph removeSelector: #convertToCurrentVersion:refStream:!
HaloMorph removeSelector: #openViewerForTarget:with:!
HaloMorph removeSelector: #tearOffTileForTarget:with:!
GraphMorph removeSelector: #convertToCurrentVersion:refStream:!
FillInTheBlankMorph removeSelector: #convertToCurrentVersion:refStream:!
FillInTheBlankMorph removeSelector: #undoGrabCommand!
AlignmentMorph removeSelector: #configureForKids!
AlignmentMorph removeSelector: #convertToCurrentVersion:refStream:!
Morph removeSelector: #abstractAModel!
Morph removeSelector: #actorState!
Morph removeSelector: #actorState:!
Morph removeSelector: #actorStateOrNil!
Morph removeSelector: #adaptToWorld:!
Morph removeSelector: #addPlayerItemsTo:!
Morph removeSelector: #addStackItemsTo:!
Morph removeSelector: #addViewingItemsTo:!
Morph removeSelector: #addedOrRemovedSubmorph:!
Morph removeSelector: #adoptVocabulary:!
Morph removeSelector: #affiliatedSelector!
Morph removeSelector: #allowsGestureStart:!
Morph removeSelector: #appearsToBeSameCostumeAs:!
Morph removeSelector: #applyStatusToAllSiblings:!
Morph removeSelector: #asEPS!
Morph removeSelector: #asEmptyPermanentScriptor!
Morph removeSelector: #asPostscript!
Morph removeSelector: #asPostscriptPrintJob!
Morph removeSelector: #asWearableCostume!
Morph removeSelector: #asWearableCostumeOfExtent:!
Morph removeSelector: #assuredCardPlayer!
Morph removeSelector: #assuredPlayer!
Morph removeSelector: #attachToResource!
Morph removeSelector: #automaticViewing!
Morph removeSelector: #beAStackBackground!
Morph removeSelector: #beFlap:!
Morph removeSelector: #becomeSharedBackgroundField!
Morph removeSelector: #bringAllSiblingsToMe:!
Morph removeSelector: #bringTileScriptingElementsUpToDate!
Morph removeSelector: #bringUpToDate!
Morph removeSelector: #cartesianBoundsTopLeft!
Morph removeSelector: #cartesianXY:!
Morph removeSelector: #categoriesForViewer!
Morph removeSelector: #choosePenColor:!
Morph removeSelector: #choosePenSize!
Morph removeSelector: #clipPostscript!
Morph removeSelector: #color:sees:!
Morph removeSelector: #colorUnder!
Morph removeSelector: #commandHistory!
Morph removeSelector: #configureForKids!
Morph removeSelector: #constructorString!
Morph removeSelector: #containsCard:!
Morph removeSelector: #convertAugust1998:using:!
Morph removeSelector: #convertNovember2000DropShadow:using:!
Morph removeSelector: #convertToCurrentVersion:refStream:!
Morph removeSelector: #copyCostumeStateFrom:!
Morph removeSelector: #couldHoldSeparateDataForEachInstance!
Morph removeSelector: #creationStamp!
Morph removeSelector: #currentDataInstance!
Morph removeSelector: #currentDataValue!
Morph removeSelector: #currentPlayerDo:!
Morph removeSelector: #currentVocabulary!
Morph removeSelector: #defaultVariableName!
Morph removeSelector: #defersHaloOnClickTo:!
Morph removeSelector: #definePath!
Morph removeSelector: #deletePath!
Morph removeSelector: #deleteSubmorphsWithProperty:!
Morph removeSelector: #demandsBoolean!
Morph removeSelector: #demandsThumbnailing!
Morph removeSelector: #dismissButton!
Morph removeSelector: #doesOwnRotation!
Morph removeSelector: #drawPostscriptOn:!
Morph removeSelector: #enclosingEditor!
Morph removeSelector: #enforceTileColorPolicy!
Morph removeSelector: #explainDesignations!
Morph removeSelector: #fenceEnabled!
Morph removeSelector: #followPath!
Morph removeSelector: #fullDrawPostscriptOn:!
Morph removeSelector: #getCharacters!
Morph removeSelector: #getIndexInOwner!
Morph removeSelector: #getPenColor!
Morph removeSelector: #getPenDown!
Morph removeSelector: #getPenSize!
Morph removeSelector: #goToNextCardInStack!
Morph removeSelector: #goToPreviousCardInStack!
Morph removeSelector: #griddedPoint:!
Morph removeSelector: #handMeTilesToFire!
Morph removeSelector: #hasSubmorphWithProperty:!
Morph removeSelector: #heading:!
Morph removeSelector: #holdsSeparateDataForEachInstance!
Morph removeSelector: #inPartsBin!
Morph removeSelector: #insertAsStackBackground!
Morph removeSelector: #insertCard!
Morph removeSelector: #inspectArgumentsPlayerInMorphic:!
Morph removeSelector: #inspectInMorphic!
Morph removeSelector: #installAsCurrent:!
Morph removeSelector: #instantiatedUserScriptsDo:!
Morph removeSelector: #isAViewer!
Morph removeSelector: #isBalloonHelp!
Morph removeSelector: #isCandidateForAutomaticViewing!
Morph removeSelector: #isFlap!
Morph removeSelector: #isFlapOrTab!
Morph removeSelector: #isFlapTab!
Morph removeSelector: #isFlashMorph!
Morph removeSelector: #isGestureStart:!
Morph removeSelector: #isModalShell!
Morph removeSelector: #isPartsBin!
Morph removeSelector: #isPlayer:ofReferencingTile:!
Morph removeSelector: #isShared!
Morph removeSelector: #isStackBackground!
Morph removeSelector: #isStandardViewer!
Morph removeSelector: #isSyntaxMorph!
Morph removeSelector: #isTileEditor!
Morph removeSelector: #isTileLike!
Morph removeSelector: #isTileScriptingElement!
Morph removeSelector: #isValidWonderlandTexture!
Morph removeSelector: #isValidWonderlandTexture:!
Morph removeSelector: #jettisonScripts!
Morph removeSelector: #jumpTo:!
Morph removeSelector: #liftPen!
Morph removeSelector: #listViewLineForFieldList:!
Morph removeSelector: #lowerPen!
Morph removeSelector: #makeAllTilesColored!
Morph removeSelector: #makeAllTilesGreen!
Morph removeSelector: #makeFenceSound!
Morph removeSelector: #makeGraphPaper!
Morph removeSelector: #makeHoldSeparateDataForEachInstance!
Morph removeSelector: #makeMultipleSiblings:!
Morph removeSelector: #makeNascentScript!
Morph removeSelector: #makeNewPlayerInstance:!
Morph removeSelector: #makeSiblings:!
Morph removeSelector: #makeSiblingsLookLikeMe:!
Morph removeSelector: #methodCommentAsBalloonHelp!
Morph removeSelector: #morphRepresented!
Morph removeSelector: #move:toPosition:!
Morph removeSelector: #moveWithPenDownBy:!
Morph removeSelector: #moveWithPenDownByRAA:!
Morph removeSelector: #nameForUndoWording!
Morph removeSelector: #nameInModel!
Morph removeSelector: #newCard!
Morph removeSelector: #newPlayerInstance!
Morph removeSelector: #nextOwnerPage!
Morph removeSelector: #noteNegotiatedName:for:!
Morph removeSelector: #objectViewed!
Morph removeSelector: #okayToAddDismissHandle!
Morph removeSelector: #okayToAddGrabHandle!
Morph removeSelector: #openAButtonPropertySheet!
Morph removeSelector: #openAPropertySheet!
Morph removeSelector: #openATextPropertySheet!
Morph removeSelector: #openInMVC!
Morph removeSelector: #openViewerForArgument!
Morph removeSelector: #pagesHandledAutomatically!
Morph removeSelector: #penColor:!
Morph removeSelector: #penUpWhile:!
Morph removeSelector: #permitsThumbnailing!
Morph removeSelector: #previousOwnerPage!
Morph removeSelector: #printConstructorOn:indent:!
Morph removeSelector: #printPSToFile!
Morph removeSelector: #printPSToFileNamed:!
Morph removeSelector: #printSpecs!
Morph removeSelector: #putOnBackground!
Morph removeSelector: #putOnForeground!
Morph removeSelector: #randomBoundsFor:!
Morph removeSelector: #readoutForField:!
Morph removeSelector: #reassessBackgroundShape!
Morph removeSelector: #redButtonGestureDictionaryOrName:!
Morph removeSelector: #referencePlayfield!
Morph removeSelector: #regularColor!
Morph removeSelector: #regularColor:!
Morph removeSelector: #relaxGripOnVariableNames!
Morph removeSelector: #renameTo:!
Morph removeSelector: #representativeNoTallerThan:norWiderThan:thumbnailHeight:!
Morph removeSelector: #reserveUrl:!
Morph removeSelector: #reshapeBackground!
Morph removeSelector: #residesInPartsBin!
Morph removeSelector: #restoreTypeColor!
Morph removeSelector: #rootAt:!
Morph removeSelector: #rootMorphsAtGlobal:!
Morph removeSelector: #saveAsResource!
Morph removeSelector: #saveDocPane!
Morph removeSelector: #saveOnURL!
Morph removeSelector: #saveOnURL:!
Morph removeSelector: #saveOnURLbasic!
Morph removeSelector: #screenLocation!
Morph removeSelector: #screenRectangle!
Morph removeSelector: #scriptEditorFor:!
Morph removeSelector: #scriptPerformer!
Morph removeSelector: #selectorsForViewer!
Morph removeSelector: #set:!
Morph removeSelector: #setArrowheads!
Morph removeSelector: #setAsActionInButtonProperties:!
Morph removeSelector: #setAsDefaultValueForNewCard!
Morph removeSelector: #setIndexInOwner:!
Morph removeSelector: #setNumericValue:!
Morph removeSelector: #setProperties:!
Morph removeSelector: #shouldRememberCostumes!
Morph removeSelector: #showBackgroundObjects!
Morph removeSelector: #showDesignationsOfObjects!
Morph removeSelector: #showForegroundObjects!
Morph removeSelector: #showHiders!
Morph removeSelector: #showPlayerMenu!
Morph removeSelector: #slotSpecifications!
Morph removeSelector: #spaceFillWeight:!
Morph removeSelector: #specialNameInModel!
Morph removeSelector: #sqkPage!
Morph removeSelector: #stack!
Morph removeSelector: #stackDo:!
Morph removeSelector: #standardPalette!
Morph removeSelector: #stopHoldingSeparateDataForEachInstance!
Morph removeSelector: #succeededInRevealing:!
Morph removeSelector: #tabHitWithEvent:!
Morph removeSelector: #tearOffTile!
Morph removeSelector: #topEditor!
Morph removeSelector: #touchesColor:!
Morph removeSelector: #trailMorph!
Morph removeSelector: #traverseRowTranslateSlotOld:of:to:!
Morph removeSelector: #traverseRowTranslateSlotOld:to:!
Morph removeSelector: #triggerScript:!
Morph removeSelector: #tryToRenameTo:!
Morph removeSelector: #unHighlight!
Morph removeSelector: #undoGrabCommand!
Morph removeSelector: #undoMove:redo:owner:bounds:predecessor:!
Morph removeSelector: #updateAllFromResources!
Morph removeSelector: #updateAllScriptingElements!
Morph removeSelector: #updateCachedThumbnail!
Morph removeSelector: #updateFromResource!
Morph removeSelector: #updateReferencesUsing:!
Morph removeSelector: #updateThumbnailUrl!
Morph removeSelector: #updateThumbnailUrlInBook:!
Morph removeSelector: #url!
Morph removeSelector: #usableSiblingInstance!
Morph removeSelector: #useUniformTileColor!
Morph removeSelector: #variableDocks!
Morph removeSelector: #viewAfreshIn:showingScript:at:!
Morph removeSelector: #viewMorphDirectly!
Morph removeSelector: #wantsHalo!
Morph removeSelector: #wantsHaloFor:!
Morph removeSelector: #wantsScriptorHaloHandle!
Morph removeSelector: #wonderlandTexture!
Morph removeSelector: #wonderlandTexture:!
Morph removeSelector: #wrap!
Morph removeSelector: #wrapWithAStack!
Morph removeSelector: #x!
Morph removeSelector: #x:!
Morph removeSelector: #x:y:!
Morph removeSelector: #y!
Morph removeSelector: #y:!
Morph removeSelector: #yellowButtonGestureDictionaryOrName:!

!Morph reorganize!
('*sound-piano rolls' addMorphsTo:pianoRoll:eventTime:betweenTime:and: encounteredAtTime:inScorePlayer:atIndex:inEventTrack:secsPerTick: justDroppedIntoPianoRoll:event: pauseFrom: resetFrom: resumeFrom: triggerActionFromPianoRoll)
('WiW support' addMorphInFrontOfLayer: addMorphInLayer: eToyRejectDropMorph:event: morphicLayerNumber morphicLayerNumberWithin: shouldGetStepsFrom:)
('accessing' adoptPaneColor: balloonText balloonTextSelector balloonTextSelector: beSticky beUnsticky borderColor borderColor: borderStyle borderStyle: borderStyleForSymbol: borderWidth borderWidth: borderWidthForRounding color color: colorForInsets couldHaveRoundedCorners doesBevels eventHandler eventHandler: forwardDirection hasTranslucentColor highlight highlightColor highlightColor: highlightOnlySubmorph: insetColor isLocked isSticky lock lock: modelOrNil player player: presenter raisedColor rememberedColor rememberedColor: resistsRemoval resistsRemoval: scaleFactor setBorderStyle: sticky: toggleLocked toggleResistsRemoval toggleStickiness unlock unlockContents userString wantsToBeCachedByHand)
('accessing - extension' assureExtension extension hasExtension initializeExtension privateExtension: resetExtension)
('accessing - properties' hasProperty: otherProperties removeProperty: setProperty:toValue: valueOfProperty: valueOfProperty:ifAbsent: valueOfProperty:ifAbsentPut: valueOfProperty:ifPresentDo:)
('button' doButtonAction fire firedMouseUpCode)
('button properties' buttonProperties buttonProperties: ensuredButtonProperties hasButtonProperties)
('caching' fullLoadCachedState fullReleaseCachedState loadCachedState releaseCachedState)
('change reporting' addedMorph: colorChangedForSubmorph: invalidRect: invalidRect:from: ownerChanged privateInvalidateMorph: userSelectedColor:)
('classification' isAlignmentMorph isFlexMorph isHandMorph isPlayfieldLike isRenderer isTextMorph isWorldMorph isWorldOrHandMorph)
('converting' asDraggableMorph)
('copying' copy deepCopy duplicate duplicateMorphCollection: fullCopy veryDeepCopyWith: veryDeepFixupWith: veryDeepInner:)
('creation' asMorph)
('debug and other' addDebuggingItemsTo:hand: addMouseActionIndicatorsWidth:color: addMouseUpAction addMouseUpActionWith: allStringsAfter: altSpecialCursor0 altSpecialCursor1 altSpecialCursor2 altSpecialCursor3 altSpecialCursor3: buildDebugMenu: defineTempCommand deleteAnyMouseActionIndicators inspectOwnerChain installModelIn: mouseUpCodeOrNil ownerChain programmedMouseDown:for: programmedMouseEnter:for: programmedMouseLeave:for: programmedMouseUp:for: programmedMouseUp:for:with: removeMouseUpAction resumeAfterDrawError resumeAfterStepError tempCommand)
('drawing' areasRemainingToFill: boundingBoxOfSubmorphs boundsWithinCorners changeClipSubmorphs clipLayoutCells clipLayoutCells: clipSubmorphs clipSubmorphs: clippingBounds drawDropHighlightOn: drawDropShadowOn: drawErrorOn: drawMouseDownHighlightOn: drawOn: drawRolloverBorderOn: drawSubmorphsOn: expandFullBoundsForDropShadow: expandFullBoundsForRolloverBorder: fullDrawOn: hasClipSubmorphsString hide highlightForMouseDown highlightForMouseDown: highlightedForMouseDown imageForm imageForm:forRectangle: imageFormDepth: imageFormForRectangle: imageFormWithout:andStopThere: refreshWorld shadowForm show visible visible:)
('drop shadows' addDropShadow addDropShadowMenuItems:hand: changeShadowColor hasDropShadow hasDropShadow: hasDropShadowString hasRolloverBorder hasRolloverBorder: removeDropShadow setShadowOffset: shadowColor shadowColor: shadowOffset shadowOffset: shadowPoint: toggleDropShadow)
('dropping/grabbing' aboutToBeGrabbedBy: disableDragNDrop dragEnabled dragEnabled: dragNDropEnabled dragSelectionColor dropEnabled dropEnabled: dropHighlightColor dropSuccessColor enableDrag: enableDragNDrop enableDragNDrop: enableDrop: formerOwner formerOwner: formerPosition formerPosition: grabTransform highlightForDrop highlightForDrop: highlightedForDrop justDroppedInto:event: justGrabbedFrom: rejectDropMorphEvent: repelsMorph:event: resetHighlightForDrop separateDragAndDrop slideBackToFormerSituation: slideToTrash: startDrag:with: toggleDragNDrop transportedMorph vanishAfterSlidingTo:event: wantsDroppedMorph:event: wantsToBeDroppedInto: wantsToBeOpenedInWorld willingToBeDiscarded)
('e-toy support' allMorphsAndBookPagesInto: asNumber: changeAllBorderColorsFrom:to: containingWindow cursor cursor: decimalPlacesForGetter: defaultValueOrNil embedInWindow embeddedInMorphicWindowLabeled: getNumericValue gridFormOrigin:grid:background:line: makeGraphPaperGrid:background:line: mustBeBackmost noteDecimalPlaces:forGetter: rotationStyle rotationStyle: setNaturalLanguageTo: setStandardTexture textureParameters unlockOneSubpart wantsRecolorHandle wrappedInWindow: wrappedInWindowWithTitle:)
('event handling' click click: cursorPoint doubleClick: doubleClickTimeout: dropFiles: firstClickTimedOut: handlesKeyboard: handlesMouseDown: handlesMouseOver: handlesMouseOverDragging: handlesMouseStillDown: hasFocus keyDown: keyStroke: keyUp: keyboardFocusChange: mouseDown: mouseEnter: mouseEnterDragging: mouseLeave: mouseLeaveDragging: mouseMove: mouseStillDown: mouseStillDownThreshold mouseUp: on:send:to: on:send:to:withValue: removeLink: restoreSuspendedEventHandler startDrag: suspendEventHandler transformFrom: transformFromOutermostWorld transformFromWorld wantsDropFiles: wantsEveryMouseMove wantsKeyboardFocusFor: wouldAcceptKeyboardFocus wouldAcceptKeyboardFocusUponTab)
('events-accessing' actionMap updateableActionMap)
('events-alarms' addAlarm:after: addAlarm:at: addAlarm:with:after: addAlarm:with:at: addAlarm:with:with:after: addAlarm:with:with:at: addAlarm:withArguments:after: addAlarm:withArguments:at: alarmScheduler removeAlarm: removeAlarm:at:)
('events-processing' containsPoint:event: defaultEventDispatcher handleDropFiles: handleDropMorph: handleEvent: handleFocusEvent: handleKeyDown: handleKeyUp: handleKeystroke: handleListenEvent: handleMouseEnter: handleMouseLeave: handleMouseMove: handleMouseOver: handleMouseStillDown: handleMouseUp: handleUnknownEvent: handlerForMouseDown: mouseDownPriority processEvent: processEvent:using: rejectDropEvent: rejectsEvent: transformedFrom:)
('events-removing' releaseActionMap)
('fileIn/out' prepareToBeSaved saveOnFile)
('filter streaming' drawOnCanvas:)
('geometry' align:with: bottom bottom: bottomCenter bottomLeft bottomLeft: bottomRight bottomRight: bounds bounds: bounds:from: bounds:in: boundsIn: boundsInWorld center center: extent extent: fullBoundsInWorld globalPointToLocal: gridPoint: height height: innerBounds left left: leftCenter localPointToGlobal: minimumExtent minimumExtent: outerBounds point:from: point:in: pointFromWorld: pointInWorld: position position: positionInWorld positionSubmorphs right right: rightCenter setConstrainedPosition:hangOut: shiftSubmorphsBy: shiftSubmorphsOtherThan:by: top top: topCenter topLeft topLeft: topRight topRight: transformedBy: width width: worldBounds worldBoundsForHalo)
('geometry eToy' addTransparentSpacerOfSize: beTransparent degreesOfFlex forwardDirection: goHome heading referencePosition referencePosition: referencePositionInWorld referencePositionInWorld: rotationCenter rotationCenter: setDirectionFrom: transparentSpacerOfSize:)
('geometry testing' containsPoint: fullContainsPoint: obtrudesBeyondContainer)
('halos and balloon help' addHalo addHalo: addHalo:from: addHandlesTo:box: addMagicHaloFor: addOptionalHandlesTo:box: addSimpleHandlesTo:box: addWorldHandlesTo:box: balloonColor balloonColor: balloonFont balloonFont: balloonHelpAligner balloonHelpDelayTime balloonHelpTextForHandle: boundsForBalloon comeToFrontAndAddHalo defaultBalloonColor defaultBalloonFont deleteBalloon editBalloonHelpContent: editBalloonHelpText halo haloClass haloDelayTime hasHalo hasHalo: isLikelyRecipientForMouseOverHalos mouseDownOnHelpHandle: noHelpString okayToBrownDragEasily okayToExtractEasily okayToResizeEasily okayToRotateEasily removeHalo setBalloonText: setBalloonText:maxLineLength: setCenteredBalloonText: showBalloon: showBalloon:hand: transferHalo:from: wantsBalloon wantsDirectionHandles wantsDirectionHandles: wantsHaloFromClick wantsHaloHandleWithSelector:inHalo:)
('initialization' basicInitialize defaultBounds defaultColor inATwoWayScrollPane initialize intoWorld: openCenteredInWorld openInHand openInWindow openInWindowLabeled: openInWindowLabeled:inWorld: openInWorld openInWorld: outOfWorld: resourceJustLoaded)
('layout' acceptDroppingMorph:event: adjustLayoutBounds doLayoutIn: fullBounds layoutBounds layoutBounds: layoutChanged layoutInBounds: layoutProportionallyIn: minExtent minHeight minHeight: minWidth minWidth: privateFullBounds submorphBounds)
('layout-menu' addCellLayoutMenuItems:hand: addLayoutMenuItems:hand: addTableLayoutMenuItems:hand: changeCellInset: changeClipLayoutCells changeDisableTableLayout changeLayoutInset: changeListDirection: changeMaxCellSize: changeMinCellSize: changeNoLayout changeProportionalLayout changeReverseCells changeRubberBandCells changeTableLayout hasClipLayoutCellsString hasDisableTableLayoutString hasNoLayoutString hasProportionalLayoutString hasReverseCellsString hasRubberBandCellsString hasTableLayoutString layoutMenuPropertyString:from:)
('layout-properties' assureLayoutProperties assureTableProperties cellInset cellInset: cellPositioning cellPositioning: cellPositioningString: cellSpacing cellSpacing: cellSpacingString: disableTableLayout disableTableLayout: hResizing hResizing: hResizingString: layoutFrame layoutFrame: layoutInset layoutInset: layoutPolicy layoutPolicy: layoutProperties layoutProperties: listCentering listCentering: listCenteringString: listDirection listDirection: listDirectionString: listSpacing listSpacing: listSpacingString: maxCellSize maxCellSize: minCellSize minCellSize: reverseTableCells reverseTableCells: rubberBandCells rubberBandCells: spaceFillWeight vResizeToFit: vResizing vResizing: vResizingString: wrapCentering wrapCentering: wrapCenteringString: wrapDirection wrapDirection: wrapDirectionString:)
('macpal' flash)
('menu' addBorderStyleMenuItems:hand: addGestureMenuItems:hand:)
('menus' absorbStateFromRenderer: addAddHandMenuItemsForHalo:hand: addCopyItemsTo: addCustomHaloMenuItems:hand: addCustomMenuItems:hand: addExportMenuItems:hand: addFillStyleMenuItems:hand: addHaloActionsTo: addMiscExtrasTo: addPaintingItemsTo:hand: addStandardHaloMenuItemsTo:hand: addTitleForHaloMenu: addToggleItemsToHaloMenu: adhereToEdge adhereToEdge: adjustedCenter adjustedCenter: allMenuWordings changeColor changeDirectionHandles changeDragAndDrop chooseNewGraphic chooseNewGraphicCoexisting: chooseNewGraphicFromHalo collapse defaultArrowheadSize doMenuItem: exportAsBMP exportAsGIF exportAsJPEG exportAsPNG hasDirectionHandlesString hasDragAndDropEnabledString helpButton inspectInMorphic: lockUnlockMorph lockedString maybeAddCollapseItemTo: menuItemAfter: menuItemBefore: presentHelp resetForwardDirection resistsRemovalString setRotationCenter setRotationCenterFrom: setToAdhereToEdge: snapToEdgeIfAppropriate stickinessString transferStateToRenderer: uncollapseSketch)
('messenger')
('meta-actions' addEmbeddingMenuItemsTo:hand: beThisWorldsModel blueButtonDown: blueButtonUp: buildHandleMenu: buildMetaMenu: changeColorTarget:selector:originalColor:hand: copyToPasteBuffer: dismissMorph: duplicateMorph: embedInto: grabMorph: handlerForBlueButtonDown: handlerForMetaMenu: inspectAt:event: invokeMetaMenu: invokeMetaMenuAt:event: maybeDuplicateMorph maybeDuplicateMorph: potentialEmbeddingTargets resizeFromMenu resizeMorph: saveAsPrototype showActions subclassMorph)
('miscellaneous' setExtentFromHalo:)
('naming' choosePartName downshiftedNameOfObjectRepresented innocuousName name: nameForFindWindowFeature nameOfObjectRepresented setNamePropertyTo: setNameTo:)
('object fileIn')
('objects from disk' objectForDataStream: storeDataOn:)
('other' removeAllButFirstSubmorph)
('other events' menuButtonMouseEnter: menuButtonMouseLeave:)
('parts bin' initializeToStandAlone isPartsDonor isPartsDonor: markAsPartsDonor partRepresented)
('player' assureExternalName okayToDuplicate)
('player commands' beep: playSoundNamed:)
('player viewer' updateLiteralLabel)
('printing' clipText colorString: fullPrintOn: initString morphReport morphReportFor: morphReportFor:on:indent: printConstructorOn:indent:nodeDict: printOn: printSpecs: printStructureOn:indent: reportableSize structureString textToPaste)
('rotate scale and flex' addFlexShell addFlexShellIfNecessary keepsTransform newTransformationMorph rotationDegrees)
('rounding' cornerStyle: roundedCorners roundedCornersString toggleCornerRounding wantsRoundedCorners)
('scripting' defaultFloatPrecisionFor:)
('stepping and presenter' arrangeToStartStepping arrangeToStartSteppingIn: isStepping isSteppingSelector: start startStepping startStepping:at:arguments:stepTime: startSteppingIn: startSteppingSelector: step stepAt: stop stopStepping stopSteppingSelector: stopSteppingSelfAndSubmorphs)
('structure' activeHand allOwners allOwnersDo: firstOwnerSuchThat: hasOwner: isInWorld morphPreceding: nearestOwnerThat: orOwnerSuchThat: outermostMorphThat: outermostWorldMorph owner ownerThatIsA: ownerThatIsA:orA: pasteUpMorph pasteUpMorphHandlingTabAmongFields primaryHand renderedMorph root topPasteUp topRendererOrSelf withAllOwners withAllOwnersDo: world)
('submorphs-accessing' allKnownNames allMorphs allMorphsDo: allNonSubmorphMorphs allSubmorphNamesDo: findA: findDeepSubmorphThat:ifAbsent: findDeeplyA: findSubmorphBinary: firstSubmorph hasSubmorphs indexOfMorphAbove: lastSubmorph morphsAt: morphsAt:behind:unlocked: morphsAt:unlocked: morphsAt:unlocked:do: morphsInFrontOf:overlapping:do: morphsInFrontOverlapping: morphsInFrontOverlapping:do: noteNewOwner: rootMorphsAt: shuffleSubmorphs submorphAfter submorphBefore submorphCount submorphNamed: submorphNamed:ifNone: submorphOfClass: submorphThat:ifNone: submorphWithProperty: submorphs submorphsBehind:do: submorphsDo: submorphsInFrontOf:do: submorphsReverseDo: submorphsSatisfying:)
('submorphs-add/remove' abandon actWhen actWhen: addAllMorphs: addAllMorphs:after: addMorph: addMorph:after: addMorph:asElementNumber: addMorph:behind: addMorph:fullFrame: addMorph:inFrontOf: addMorphBack: addMorphCentered: addMorphFront: addMorphFront:fromWorldPosition: addMorphFrontFromWorldPosition: addMorphNearBack: comeToFront copyWithoutSubmorph: delete dismissViaHalo goBehind privateDelete removeAllMorphs removeAllMorphsIn: removeMorph: removedMorph: replaceSubmorph:by: submorphIndexOf:)
('system primitives')
('testing' canDrawAtHigherResolution canDrawBorder: completeModificationHash isFlexed isMorph knownName modificationHash shouldDropOnMouseUp stepTime wantsSteps)
('text-anchor' addTextAnchorMenuItems:hand: changeDocumentAnchor changeInlineAnchor changeParagraphAnchor hasDocumentAnchorString hasInlineAnchorString hasParagraphAnchorString relativeTextAnchorPosition relativeTextAnchorPosition: textAnchorType textAnchorType:)
('texture support')
('thumbnail')
('undo')
('updating' changed)
('user interface' defaultLabelForInspector initialExtent)
('viewer' externalName)
('visual properties' canHaveFillStyles cornerStyle fillStyle fillStyle: fillWithRamp:oriented: useBitmapFill useDefaultFill useGradientFill useSolidFill)
('private' privateAddAllMorphs:atIndex: privateAddMorph:atIndex: privateBounds: privateColor: privateDeleteWithAbsolutelyNoSideEffects privateFullBounds: privateFullMoveBy: privateMoveBy: privateOwner: privateRemove: privateRemoveMorph: privateRemoveMorphWithAbsolutelyNoSideEffects: privateSubmorphs privateSubmorphs:)
('dispatching' disableSubmorphFocusForHand:)
('*geniestubs-stubs' handleMouseDown: mouseStillDownStepRate)
('translation')
!

MessageSend removeSelector: #asTilesIn:!
MessageSend removeSelector: #asTilesIn:globalNames:!
MessageSend removeSelector: #stringFor:!
MatrixTransform2x3 removeSelector: #encodeForRemoteCanvas!
MatrixTransform2x3 removeSelector: #encodePostscriptOn:!
LayoutFrame removeSelector: #convertToCurrentVersion:refStream:!
InfiniteForm removeSelector: #encodeForRemoteCanvas!
ImageSegment removeSelector: #findStacks!
ImageSegment removeSelector: #savePlayerReferences:!
GradientFillStyle removeSelector: #encodeForRemoteCanvas!
ColorForm removeSelector: #encodeForRemoteCanvas!
ColorForm removeSelector: #encodePostscriptOn:!
Form removeSelector: #appearsToBeSameCostumeAs:!
Form removeSelector: #encodeForRemoteCanvas!
Form removeSelector: #encodePostscriptOn:!
Form removeSelector: #morphEdit!
FileDirectory removeSelector: #eToyBaseFolderSpec!
FileDirectory removeSelector: #eToyBaseFolderSpec:!
FileDirectory removeSelector: #eToyUserList!
FileDirectory removeSelector: #eToyUserListUrl!
FileDirectory removeSelector: #eToyUserListUrl:!
FileDirectory removeSelector: #eToyUserName:!
FileDirectory removeSelector: #hasEToyUserList!

!FileDirectory reorganize!
('path access' fullPathFor: on: pathName pathNameDelimiter pathParts slash)
('file stream creation' fileNamed: forceNewFileNamed: newFileNamed: oldFileNamed: oldFileOrNoneNamed: readOnlyFileNamed:)
('enumeration' containingDirectory directoryEntry directoryEntryFor: directoryNamed: directoryNames entries fileAndDirectoryNames fileNames fullName fullNamesOfAllFilesInSubtree keysDo: localName matchingEntries: statsForDirectoryTree:)
('testing' acceptsUploads directoryExists: exists fileExists: includesKey: isAFileNamed: isCaseSensitive isRemoteDirectory)
('file operations' copyFile:toFile: copyFileNamed:toFileNamed: copyFileWithoutOverwriteConfirmationNamed:toFileNamed: createDirectory: deleteDirectory: deleteFileNamed: deleteFileNamed:ifAbsent: deleteLocalFiles fileOrDirectoryExists: getMacFileTypeAndCreator: mimeTypesFor: putFile:named: putFile:named:retry: recursiveDelete rename:toBe: setMacFileNamed:type:creator: upLoadProject:named:resourceUrl:retry:)
('file name utilities' asUrl checkName:fixErrors: fileNamesMatching: fullNameFor: isLegalFileName: isTypeFile lastNameFor:extension: nextNameFor:extension: realUrl relativeNameFor: splitNameVersionExtensionFor: url)
('printing' printOn:)
('private' directoryContentsFor: primCreateDirectory: primDeleteDirectory: primDeleteFileNamed: primGetMacFileNamed:type:creator: primLookupEntryIn:index: primRename:to: primSetMacFileNamed:type:creator: setPathName: storeServerEntryOn:)
('file status' entryAt: entryAt:ifAbsent:)
('file directory' assureExistence assureExistenceOfPath: localNameFor: sleep wakeUp)
('searching' filesContaining:caseSensitive: withAllFilesDo:andDirectoriesDo:)
('squeaklets' directoryObject downloadUrl updateProjectInfoFor: writeProject:inFileNamed:fromDirectory:)
!

EventHandler removeSelector: #adaptToWorld:!
EventHandler removeSelector: #convertToCurrentVersion:refStream:!
CompositeTransform removeSelector: #encodeForRemoteCanvas!
DisplayTransform removeSelector: #encodeForRemoteCanvas!
DeepCopier removeSelector: #mapUniClasses!
CompressedSoundData removeSelector: #withEToySound:samplingRate:!
Color removeSelector: #encodeForRemoteCanvas!
Color removeSelector: #encodePostscriptOn:!
Color removeSelector: #newTileMorphRepresentative!
ByteArray removeSelector: #asExternalPointer!
ByteArray removeSelector: #pointerAt:!
Collection removeSelector: #isCollection!
Class removeSelector: #officialClass!
Class removeSelector: #uniqueNameForReference!
ClassDescription removeSelector: #namedTileScriptSelectors!
ChangeSet removeSelector: #convertToCurrentVersion:refStream:!
CanvasCharacterScanner removeSelector: #convertToCurrentVersion:refStream:!
ButtonProperties removeSelector: #adaptToWorld:!
ButtonProperties removeSelector: #bringUpToDate!
ButtonProperties removeSelector: #editButtonsScript:!
ButtonProperties removeSelector: #establishEtoyLabelWording!
ButtonProperties removeSelector: #figureOutScriptSelector!
ButtonProperties removeSelector: #isTileScriptingElement!
ButtonProperties removeSelector: #updateReferencesUsing:!
Boolean removeSelector: #newTileMorphRepresentative!
Object removeSelector: #adaptedToWorld:!
Object removeSelector: #assureUniClass!
Object removeSelector: #beViewed!
Object removeSelector: #belongsToUniClass!
Object removeSelector: #browseOwnClassSubProtocol!
Object removeSelector: #capturedState!
Object removeSelector: #categoriesForViewer:!
Object removeSelector: #categoriesForVocabulary:limitClass:!
Object removeSelector: #chooseNewNameForReference!
Object removeSelector: #codeStrippedOut:!
Object removeSelector: #commandHistory!
Object removeSelector: #contentsGetz:!
Object removeSelector: #costumes!
Object removeSelector: #creationStamp!
Object removeSelector: #currentVocabulary!
Object removeSelector: #defaultLimitClassForVocabulary:!
Object removeSelector: #eToyStreamedRepresentationNotifying:!
Object removeSelector: #elementTypeFor:vocabulary:!
Object removeSelector: #encodePostscriptOn:!
Object removeSelector: #evaluateUnloggedForSelf:!
Object removeSelector: #externalCallFailed!
Object removeSelector: #fullDrawPostscriptOn:!
Object removeSelector: #graphicForViewerTab!
Object removeSelector: #handledListVerification!
Object removeSelector: #hasUserDefinedSlots!
Object removeSelector: #infoFor:inViewer:!
Object removeSelector: #initialTypeForSlotNamed:!
Object removeSelector: #isCollection!
Object removeSelector: #isPlayerLike!
Object removeSelector: #isSymbol!
Object removeSelector: #isUniversalTiles!
Object removeSelector: #launchPartVia:!
Object removeSelector: #launchTileToRefer!
Object removeSelector: #methodInterfacesForCategory:inVocabulary:limitClass:!
Object removeSelector: #methodInterfacesForInstanceVariablesCategoryIn:!
Object removeSelector: #methodInterfacesForScriptsCategoryIn:!
Object removeSelector: #methodInterfacesInPresentationOrderFrom:forCategory:!
Object removeSelector: #newScriptorAround:!
Object removeSelector: #newTileMorphRepresentative!
Object removeSelector: #objectRepresented!
Object removeSelector: #offerViewerMenuFor:event:!
Object removeSelector: #offerViewerMenuForEvt:morph:!
Object removeSelector: #openInstanceBrowserWithTiles!
Object removeSelector: #propertyList!
Object removeSelector: #purgeAllCommands!
Object removeSelector: #redoFromCapturedState:!
Object removeSelector: #refineRedoTarget:selector:arguments:in:!
Object removeSelector: #refineUndoTarget:selector:arguments:in:!
Object removeSelector: #rememberCommand:!
Object removeSelector: #rememberUndoableAction:named:!
Object removeSelector: #renameScript:!
Object removeSelector: #scriptPerformer!
Object removeSelector: #selfWrittenAsIll!
Object removeSelector: #selfWrittenAsIm!
Object removeSelector: #selfWrittenAsMe!
Object removeSelector: #selfWrittenAsMy!
Object removeSelector: #selfWrittenAsThis!
Object removeSelector: #slotInfo!
Object removeSelector: #tilePhrasesForCategory:inViewer:!
Object removeSelector: #tilePhrasesForSelectorList:inViewer:!
Object removeSelector: #tileToRefer!
Object removeSelector: #undoFromCapturedState:!
Object removeSelector: #uniqueInstanceVariableNameLike:excluding:!
Object removeSelector: #uniqueNameForReference!
Object removeSelector: #uniqueNameForReferenceFrom:!
Object removeSelector: #uniqueNameForReferenceOrNil!
Object removeSelector: #universalTilesForGetterOf:!
Object removeSelector: #universalTilesForInterface:!
Object removeSelector: #updateThresholdForGraphicInViewerTab!
Object removeSelector: #usableMethodInterfacesIn:!
Object removeSelector: #vocabularyDemanded!

!Object reorganize!
('accessing' addInstanceVarNamed:withValue: at: at:modify: at:put: basicAt: basicAt:put: basicSize bindWithTemp: doIfNotNil: ifNotNilDo: in: presenter readFromString: size yourself)
('associating' ->)
('binding' bindingOf:)
('casing' caseOf: caseOf:otherwise:)
('class membership' class inheritsFromAnyIn: isKindOf: isKindOf:orOf: isMemberOf: respondsTo: xxxClass)
('comparing' = closeTo: hash hashMappedBy: identityHashMappedBy: identityHashPrintString literalEqual: ~=)
('converting' adaptToFloat:andSend: adaptToFraction:andSend: adaptToInteger:andSend: as: asActionSequence asActionSequenceTrappingErrors asDraggableMorph asOrderedCollection asString asStringOrText complexContents mustBeBoolean mustBeBooleanIn: printDirectlyToDisplay withoutListWrapper)
('copying' clone copy copyAddedStateFrom: copyFrom: copySameFrom: copyTwoLevel deepCopy initialDeepCopierSize postCopy shallowCopy veryDeepCopy veryDeepCopySibling veryDeepCopyUsing: veryDeepCopyWith: veryDeepFixupWith: veryDeepInner:)
('creation' asMorph openAsMorph)
('dependents access' addDependent: breakDependents canDiscardEdits dependents hasUnacceptedEdits myDependents myDependents: release removeDependent:)
('deprecated' beep: beepPrimitive)
('drag and drop' acceptDroppingMorph:event:inMorph: dragAnimationFor:transferMorph: dragPassengerFor:inMorph: dragTransferType dragTransferTypeForMorph: wantsDroppedMorph:event:inMorph:)
('error handling' assert: caseError confirm: confirm:orCancel: deprecated: deprecated:block: deprecated:explanation: deprecatedExplanation: doesNotUnderstand: error: halt halt: handles: notify: notify:at: notifyWithLabel: primitiveFailed shouldBeImplemented shouldNotImplement subclassResponsibility tryToDefineVariableAccess:)
('evaluating' value valueWithArguments:)
('events-accessing' actionForEvent: actionForEvent:ifAbsent: actionMap actionSequenceForEvent: actionsDo: createActionMap hasActionForEvent: setActionSequence:forEvent: updateableActionMap)
('events-registering' when:evaluate: when:send:to: when:send:to:with: when:send:to:withArguments:)
('events-removing' releaseActionMap removeAction:forEvent: removeActionsForEvent: removeActionsSatisfying: removeActionsSatisfying:forEvent: removeActionsWithReceiver: removeActionsWithReceiver:forEvent:)
('events-triggering' triggerEvent: triggerEvent:ifNotHandled: triggerEvent:with: triggerEvent:with:ifNotHandled: triggerEvent:withArguments: triggerEvent:withArguments:ifNotHandled:)
('filter streaming' byteEncode: drawOnCanvas: elementSeparator flattenOnStream: printOnStream: putOn: storeOnStream: writeOnFilterStream:)
('finalization' actAsExecutor executor finalizationRegistry finalize retryWithGC:until: toFinalizeSend:to:with:)
('flagging' isThisEverCalled isThisEverCalled: logEntry logExecution logExit)
('macpal' contentsChanged currentEvent currentHand currentWorld flash ifKindOf:thenDo: instanceVariableValues playSoundNamed: refusesToAcceptCode)
('message handling' perform: perform:orSendTo: perform:with: perform:with:with: perform:with:with:with: perform:withArguments: perform:withArguments:inSuperclass: withArgs:executeMethod:)
('objects from disk' comeFullyUpOnReload: convertToCurrentVersion:refStream: indexIfCompact objectForDataStream: readDataFrom:size: saveOnFile storeDataOn:)
('parts bin' descriptionForPartsBin)
('printing' fullPrintString isLiteral longPrintOn: longPrintOn:limitedTo:indent: longPrintString nominallyUnsent: printOn: printString printStringLimitedTo: reportableSize storeOn: storeString stringForReadout stringRepresentation)
('scripting' defaultFloatPrecisionFor:)
('system primitives' asOop becomeForward: becomeForward:copyHash: className instVarAt: instVarAt:put: instVarNamed: instVarNamed:put: oopString primitiveChangeClassTo: rootStubInImageSegment: someObject)
('testing' basicType haltIfNil haveFullProtocolBrowsed haveFullProtocolBrowsedShowingSelector: isBehavior isBlock isBlockClosure isColor isColorForm isCompiledMethod isFloat isForm isFraction isHeap isInteger isInterval isMessageSend isMorph isMorphicEvent isMorphicModel isNumber isPoint isPseudoContext isStream isString isSystemWindow isText isTransparent isVariableBinding isWebBrowser knownName name nameForViewer notNil renameTo: showDiffs stepAt:in: stepIn: stepTime stepTimeIn: wantsDiffFeedback wantsSteps wantsStepsIn:)
('translation support' inline: var:declareC:)
('updating' changed changed: changed:with: noteSelectionIndex:for: okToChange update: update:with: updateListsAndCodeIn: windowIsClosing)
('user interface' addModelItemsToWindowMenu: addModelMenuItemsTo:forMorph:hand: asExplorerString beep defaultBackgroundColor defaultLabelForInspector explore fullScreenSize hasContentsInExplorer inform: initialExtent inspectWithLabel: launchPartVia:label: modelSleep modelWakeUp modelWakeUpIn: mouseUpBalk: notYetImplemented windowActiveOnFirstClick windowReqNewLabel:)
('viewer' defaultNameStemForInstances externalName)
('world hacking' couldOpenInMorphic)
('private' errorImproperStore errorNonIntegerIndex errorNotIndexable errorSubscriptBounds: primitiveError: species storeAt:inTempFrame:)
('*system-support' systemNavigation)
('Breakpoint' break)
('inspecting' basicInspect inspect inspectorClass)
('*sunit-preload' sunitAddDependent: sunitChanged: sunitRemoveDependent:)
('*tools-browser' browse browseHierarchy)
('x')
!

Smalltalk removeClassNamed: #CautiousModel!
Smalltalk removeClassNamed: #FatBitsPaint!
Smalltalk removeClassNamed: #FlapTab!
Smalltalk removeClassNamed: #Flaps!
Smalltalk removeClassNamed: #MVCWiWPasteUpMorph!
Smalltalk removeClassNamed: #MailComposition!
Smalltalk removeClassNamed: #MorphObjectOut!
Smalltalk removeClassNamed: #MorphWorldController!
Smalltalk removeClassNamed: #MorphWorldView!
Smalltalk removeClassNamed: #ObjectOut!
Smalltalk removeClassNamed: #Player!
Smalltalk removeClassNamed: #PreferencesPanel!
Smalltalk removeClassNamed: #Presenter!
Smalltalk removeClassNamed: #RemoteHandMorph!
Smalltalk removeClassNamed: #SqueakPage!
Smalltalk removeClassNamed: #SqueakPageCache!
Smalltalk removeClassNamed: #TrashCanMorph!
Smalltalk removeClassNamed: #TwoWayScrollPane!
Smalltalk removeClassNamed: #URLMorph!
Smalltalk removeClassNamed: #ViewerFlapTab!
Smalltalk removeClassNamed: #WiWPasteUpMorph!
Smalltalk removeClassNamed: #WorldViewModel!
Smalltalk removeClassNamed: #WorldWindow!
