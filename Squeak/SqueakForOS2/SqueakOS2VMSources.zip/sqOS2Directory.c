/****************************************************************************
*   Squeak port for OS/2
*
*   - Directory management functions
*
*   NOTES:
*    1) Caching is not supported (as in the unix and windows version)
*
* Feel free to experiment with this files, and to modify them anyway you like.
* If you fix any bugs, or enhance something, please let me know. I will
* include any enhancement on future releases. Bug reports are also welcome.
* I compile Squeak with IBM's VisualAge C++ for OS/2, but I think you can
* use other compilers as well if they support multimedia APIs (MMPM2.LIB).
* Enyoy!
*
*   Juan Manuel Vuletich
*    jvuletic@dc.uba.ar
*
*****************************************************************************/
#define INCL_DOSFILEMGR
#define INCL_DOSERRORS
#include <os2.h>
#include "sq.h"

#define MAX_PATH 2000

/***
        The interface to the directory primitive is path based.
        That is, the client supplies a Squeak string describing
        the path to the directory on every call. To avoid traversing
        this path on every call, a cache is maintained of the last
        path seen, along with the Mac volume and folder reference
        numbers corresponding to that path.
***/

/*** Constants ***/
#define ENTRY_FOUND     0
#define NO_MORE_ENTRIES 1
#define BAD_PATH        2

#define DELIMITER '\\'

int convertToSqueakTime(FDATE OS2Date, FTIME OS2Time) {
   int secs;
   int dy;
   static int nDaysPerMonth[14] = {
           0,   0,  31,  59,  90, 120, 151,
         181, 212, 243, 273, 304, 334, 365 };
   /* Squeak epoch is Jan 1, 1901 */
   dy = OS2Date.year + 1980 - 1901; /* compute delta year */
   secs = dy * 365 * 24 * 60 * 60       /* base seconds */
          + (dy >> 2) * 24 * 60 * 60;   /* seconds of leap years */
   /* check if month > 2 and current year is a leap year */
   if(OS2Date.month > 2 && (dy & 0x0003) == 0x0003)   /* compare with 0x0003 cause we substracted 1901! */
     secs += 24 * 60 * 60; /* add one day */
   /* add the days from the beginning of the year */
   secs += (nDaysPerMonth[OS2Date.month] + OS2Date.day - 1) * 24 * 60 * 60;
   /* add the hours, minutes, and seconds */
   secs +=  2*OS2Time.twosecs + 60*(OS2Time.minutes + 60*OS2Time.hours);
   return secs;
}

int dir_Create(char *pathString, int pathStringLength) {
   /* Create a new directory with the given path. By default, this
      directory is created relative to the cwd. */
   char name[1024];
   int i;
   for (i = 0; i < pathStringLength; i++)
      name[i] = pathString[i];
   name[i] = 0; /* string terminator */
   return DosCreateDir(name, NULL) == NO_ERROR;
}

int dir_Delete(char *pathString, int pathStringLength) {
   /* Delete a directory with the given path. By default, this
      directory is relative to the cwd. */
   char name[1024];
   int i;
   for (i = 0; i < pathStringLength; i++)
      name[i] = pathString[i];
   name[i] = 0; /* string terminator */
   return DosDeleteDir(name) == NO_ERROR;
}

int dir_Delimitor(void)
{
  return DELIMITER;
}

int dir_Lookup(char *pathString, int pathStringLength, int index,
/* outputs: */ char *name, int *nameLength, int *creationDate, int *modificationDate,
               int *isDirectory, int *sizeIfFile) {
   /* Lookup the index-th entry of the directory with the given path, starting
      at the root of the file system. Set the name, name length, creation date,
      creation time, directory flag, and file size (if the entry is a file).
      Return:        0        if a entry is found at the given index
                     1        if the directory has fewer than index entries
                     2        if the given path has bad syntax or does not reach a directory
   */
   char filespec[MAX_PATH+1];
   int i, nameLen;
   HDIR          hdirFindHandle = HDIR_CREATE;
   FILEFINDBUF3  FindBuffer     = {0};      /* Returned from FindFirst/Next */
   ULONG         ulResultBufLen = sizeof(FILEFINDBUF3);
   ULONG         ulFindCount    = 1;        /* Look for 1 file at a time    */
   APIRET        rc             = NO_ERROR; /* Return code                  */
   ULONG disknum, logical;

   /* default return values */
   *name             = 0;
   *nameLength       = 0;
   *creationDate     = 0;
   *modificationDate = 0;
   *isDirectory      = false;
   *sizeIfFile       = 0;

   if(pathStringLength == 0) {
      /* we're at the top of the file system --- return possible drives */
      DosQueryCurrentDisk(&disknum, &logical);
      for(i=0;i<26; i++)
         if(logical & (1 << i))
            if(--index == 0) { /* found the drive ! */
               name[0]           = 'A'+i;
               name[1]           = ':';
               *nameLength       = 2;
               *creationDate     = 0;
               *modificationDate = 0;
               *isDirectory      = true;
               *sizeIfFile       = 0;
               return ENTRY_FOUND;
            }
      return NO_MORE_ENTRIES;
   }

   for (i = 0; i < pathStringLength; i++)
      filespec[i] = pathString[i];
   filespec[pathStringLength] = 0;
   if(filespec[pathStringLength-1] != DELIMITER)
      strcat(filespec,"\\");
   strcat(filespec,"*.*");

   rc = DosFindFirst(filespec, &hdirFindHandle, FILE_NORMAL | FILE_DIRECTORY, &FindBuffer,
                      ulResultBufLen, &ulFindCount, FIL_STANDARD);
   if(rc != NO_ERROR)
      return BAD_PATH;

   i=1;
   /* Do not take the present and father directories (. and ..) */
   nameLen = strlen(FindBuffer.achName);
   if (nameLen < 3 && FindBuffer.achName[0] == '.')
      if (nameLen == 1 || FindBuffer.achName[1] == '.')
         i = i - 1; /* hack us back to the last index */

   /* Keep finding the next file until there we find the i-th file or there are no more files */
   while(i<index && rc==NO_ERROR) {
      ulFindCount = 1;                      /* Reset find count. */
      rc = DosFindNext(hdirFindHandle, &FindBuffer, ulResultBufLen, &ulFindCount);
      /* Do not take the present and father directories (. and ..) */
      nameLen = strlen(FindBuffer.achName);
      if (nameLen < 3 && FindBuffer.achName[0] == '.')
         if (nameLen == 1 || FindBuffer.achName[1] == '.')
            i = i - 1; /* hack us back to the last index */
      i++;
   }
   DosFindClose(hdirFindHandle);
   if(rc == ERROR_NO_MORE_FILES)
      return NO_MORE_ENTRIES;
   else if (rc != NO_ERROR)
      return BAD_PATH;

   strcpy(name, FindBuffer.achName);
   *nameLength= strlen(name);

   *creationDate = convertToSqueakTime(FindBuffer.fdateCreation, FindBuffer.ftimeCreation);
   *modificationDate = convertToSqueakTime(FindBuffer.fdateLastWrite, FindBuffer.ftimeLastWrite);

   if (FindBuffer.attrFile & FILE_DIRECTORY)
     *isDirectory= true;
   else
     *sizeIfFile= FindBuffer.cbFile;

   return ENTRY_FOUND;
}

dir_SetMacFileTypeAndCreator(char *filename, int filenameSize,
                             char *fType, char *fCreator)
{
  /* dos files are untyped, and the creator is correct by default */  //jmv?
  return true;
}

int dir_GetMacFileTypeAndCreator(char *filename, int filenameSize, char *fType, char *fCreator)
{
   /* Is this OK? */
   return success(false);
}
