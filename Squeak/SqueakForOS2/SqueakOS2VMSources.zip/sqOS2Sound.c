/****************************************************************************
*   Squeak port for OS/2
*
*   - Sound primitives
*
* THIS IS UNDER CONSTRUCTION - PLEASE FORGIVE THE COMMENTS IN SPANISH
*     (They won't be in the final version!)
*
* Feel free to experiment with this files, and to modify them anyway you like.
* If you fix any bugs, or enhance something, please let me know. I will
* include any enhancement on future releases. Bug reports are also welcome.
* I compile Squeak with IBM's VisualAge C++ for OS/2, but I think you can
* use other compilers as well if they support multimedia APIs (MMPM2.LIB).
* Enyoy!
*
*   Juan Manuel Vuletich
*    jvuletic@dc.uba.ar
*
*****************************************************************************/
/* JMV
Tomar de .mac nombres algo mejores
mciGetErrorString me permitiria poner mensajes en ingles ademas de codigos de retorno.
temporizacion: c/ buffer tiene un TimeStamp. Ademas puedo llamar a MCI_STATUS con MCI_STATUS_POSITION
8/16 bits: Solo soporto 16 bits
stereo: PLAY: Los buffers de Squeak son siempre stereo. si se indica Mono, Mac pone la salida en
              mono, y mezcla antes. Yo solo soporto stereo.
        RECORD: Pareciera ser solo mono en Mac. Verlo! En realidad me convendria manejar los dos canales en
                forma independiente (comenzar/parar de grabar en c/u). Ver mas adelante.
Creo que la version de Windoze no desaloca los buffers al stop(), sino que los reusa

DART mensajes
MCI_BUFFER:    Alocar y Dealocar buffers de hasta 64k
MCI_MIXSETUP:  Lectura o escritura directa de buffers de audio o midi

 To read and write audio data directly to the mixer device using the DART interface, the application does the
 following:
    1. Opens the mixer device with MCI_OPEN
    2. Initializes the mixer to use DART with MCI_MIXSETUP
    3. Allocates memory buffers with MCI_BUFFER
    4. Uses function pointers to read and write data from the audio device
    5. Uses MCI_STATUS_POSITION for precision timing
    6. Controls data transfer with MCI_PAUSE, MCI_RESUME, MCI_STOP
    7. Deallocates memory buffers with MCI_BUFFER
    8. Closes the mixer device with MCI_CLOSE
*/
/*
  Mac Sound Output Notes:
   The Squeak sound code produces 16-bit, stereo sound buffers.
   stereo, 16-bits -- array of 32-bit words; with L and R channels in high and low half-words
   Note: 16-bit samples are encoded as standard, signed integers (i.e., 2''s-complement)

   -- John Maloney, Aug 22, 1997
*/

/***************************************************************************/
/* Include files                                                           */
/***************************************************************************/
#define  INCL_PM                    /* required to use PM APIs.            */
#define  INCL_OS2MM                 /* required for MCI and MMIO headers   */
#define  INCL_DOS
#include <os2.h>
#include <os2me.h>
#include <string.h>
#include <malloc.h>
#include "sq.h"
#include "SoundPlugin.h"

#ifndef NO_SOUND

/*jmv This could be tweaked (distinta cantbuff para play y rec?)*/
#define BUFF_QTITY    8
#define REC_BUFF_SIZE 4096

// This is to include warnings to the user in case of API failures (in addition to primitive fail)
#define WARNINGS 1

/***************************************************************************/
/* Global variables                                                        */
/***************************************************************************/
USHORT DARTDeviceID;                /* Amp Mixer device id     */
int nextBuffToFill;
int actuallyPlayingBuff;
int emptyBuffQtity;
int isStarted = 0;
int isOpen = 0;
int done = 1;
int lastFlipTime;

MCI_MIX_BUFFER       MixBuffers[BUFF_QTITY];   /* Device buffers          */
MCI_MIXSETUP_PARMS   MixSetupParms;             /* Mixer parameters        */
MCI_BUFFER_PARMS     BufferParms;               /* Device buffer parms     */
int SqueakSoundSemaIndex;


// RECORDING
USHORT DARTRecDeviceID;                /* Amp Mixer device id     */
int recordingInProgress = 0;
int isRecOpen = 0;
int isRecAlloc = 0;
MCI_MIXSETUP_PARMS   RecMixSetupParms;             /* Mixer parameters        */
MCI_BUFFER_PARMS     RecBufferParms;               /* Device buffer parms     */
MCI_MIX_BUFFER       RecMixBuffers[BUFF_QTITY];   /* Device buffers          */
int SqueakRecSoundSemaIndex;
int recNextBuffToDeliver;
int recActuallyRecordingBuff;   //jmv parece no usarse para nada!
int recFilledBuffQtity;
int recDone = 1;                //jmv parece no usarse para nada!
int recLastFlipTime;
int recNextPositionToDeliver;

/* Preallocated space for error messages */
int  ErrorCode;
char ErrorMessage[200];

/***************************************************************************/
/* Function Prototypes                                                     */
/*          Support Function from sqOS2Window.c                            */
/***************************************************************************/
void SilentExit(int returnCode);
void ErrorExit(char* ErrorMessage);
void ShowErrorMessage(char* ErrorMessage);
void ShowWarningMessage(char* ErrorMessage);

/***************************************************************************/
/* Function Definition                                                     */
/***************************************************************************/
int soundInit(void) { return success(true); } //JMV What should they do?
int soundShutdown(void) { return success(true); } //JMV What should they do?
void FillBufferWithSilence(PMCI_MIX_BUFFER buf) {
   unsigned int *sample, *lastSample;

   sample      = (unsigned int *)buf->pBuffer;
   lastSample   = ((unsigned int *)buf->pBuffer) + (BufferParms.ulBufferSize>>2);
   /* word-fill buffer with silence */
   while (sample < lastSample) {
      *sample++ = 0;
   }
}

LONG APIENTRY MyEvent ( ULONG ulStatus, PMCI_MIX_BUFFER  pBuffer, ULONG  ulFlags  ) {
   switch( ulFlags ) {
   case MIX_STREAM_ERROR | MIX_WRITE_COMPLETE:  /* error occur in device */
      //jmv algo!
//OJO que parece entrar aca, pero no puede armar la ventanita!!!jmvjmvjmvjmv
//         sprintf(ErrorMessage, "Atencion, error en evento de play jmv");
//         ShowWarningMessage(ErrorMessage);
      break;
   case MIX_WRITE_COMPLETE:           /* for playback  */
      if (emptyBuffQtity < BUFF_QTITY)
         emptyBuffQtity++;
      /* insert a click to help user detect failure to fill buffer in time */
      *(unsigned int *)MixBuffers[actuallyPlayingBuff].pBuffer = 0;
      *((unsigned int *)MixBuffers[actuallyPlayingBuff].pBuffer+1) = 0xFFFFFFFF;
      /* If still doing sound, signal semaphore. If for some reaseon snd_Stop()
         was called, but we still get here, just play silence (this was taken
         from the Mac and I'm not sure if it's needed in OS/2) */
      if(!done)
         signalSemaphoreWithIndex(SqueakSoundSemaIndex);  //jmv manejo mejorado de Andreas Raab
      else {
//jmv testear esto, y decidir que dejar!
// Que significa que se llame aca? puede ser que el buffer este accesible y con basura? o ya es trap 00e?
//         FillBufferWithSilence(&MixBuffers[actuallyPlayingBuff]);
         sprintf(ErrorMessage, "This should NOT happen!");
         ShowWarningMessage(ErrorMessage);
      }

      //jmv estas 2 van juntas! (chquear que realmente apunten al que se esta tocando!)
      actuallyPlayingBuff = (actuallyPlayingBuff+1) % BUFF_QTITY;
      lastFlipTime = ioMicroMSecs(); //jmv ACORDARSE QUE DART TIENE ALGO MEJOR (y que no tiene por que ir atado a actuallyPlayingBuffer)
      break;
   } /* end switch */
   return( TRUE );
} /* end MyEvent */

/* Sound Play */
int snd_AvailableSpace(void) {
   /*"Return the number of bytes of available space in the sound output buffer."
      "Note: Squeak always uses buffers containing 4-bytes per sample (2 channels
       at 2 bytes per channel) regardless of the state of the Stereo flag."*/
   /* Si hay algun buffer de salida disponible, devuelve su tamanio. Sino, devuelve cero. */
   if (!isStarted) return -1;
   if(emptyBuffQtity>0)
      return BufferParms.ulBufferSize;
   return 0;
}

void MixInSamples(int count, char *srcBufPtr, int srcStartIndex, char *dstBufPtr, int dstStartIndex) {
   int sample;
   short int *src, *dst, *end;
   src = (short int *) (srcBufPtr + (srcStartIndex * 4));
   end = (short int *) (srcBufPtr + ((srcStartIndex + count) * 4));
   if (1) {  /* stereo jmv */
      dst = (short int *) (dstBufPtr + (dstStartIndex * 4));
      while (src < end) {
         sample = *dst + *src++;
         if (sample > 32767) sample = 32767;
         if (sample < -32767) sample = -32767;
         *dst++ = sample;
      }
   } else {  /* mono */
      /* if mono, average the left and right channels of the source */
      dst = (short int *) (dstBufPtr + (dstStartIndex * 2));
      while (src < end) {
         sample = *dst + ((*src++ + *src++) / 2);
         if (sample > 32767) sample = 32767;
         if (sample < -32767) sample = -32767;
         *dst++ = sample;
      }
   }
}

int snd_InsertSamplesFromLeadTime(int frameCount, int srcBufPtr, int samplesOfLeadTime) {
/*"Mix the given number of sample frames from the given sound buffer into the
   queue of samples that has already been submitted to the sound driver. This
   primitive is used to start a sound playing with minimum latency, even if
   large sound output buffers are being used to ensure smooth sound output.
   Returns the number of samples consumed, or zero if the primitive is not
   implemented or fails."*/
   PMCI_MIX_BUFFER bufPlaying, otherBuf;
   int samplesInserted, startSample, count;

   if (!isStarted) return -1;

   bufPlaying = &MixBuffers[actuallyPlayingBuff];
   otherBuf = &MixBuffers[(actuallyPlayingBuff+1) % BUFF_QTITY];

   samplesInserted = 0;

   /* mix as many samples as can fit into the remainder of the currently playing buffer */
   startSample =
      ((MixSetupParms.ulSamplesPerSec * (ioMicroMSecs() - lastFlipTime)) / 1000) + samplesOfLeadTime;
   if (startSample < (BufferParms.ulBufferSize>>2)) {
      count = (BufferParms.ulBufferSize>>2) - startSample;
      if (count > frameCount) count = frameCount;
      MixInSamples(count, (char *) srcBufPtr, 0, (char *) bufPlaying->pBuffer, startSample);
      samplesInserted = count;
   }

   /* mix remaining samples into the inactive buffer */
   count = BufferParms.ulBufferSize>>2;
   if (count > (frameCount - samplesInserted)) {
      count = frameCount - samplesInserted;
   }
   MixInSamples(count, (char *) srcBufPtr, samplesInserted, (char *) otherBuf->pBuffer, 0);
   return samplesInserted + count;
}

int snd_PlaySamplesFromAtLength(int frameCount, int arrayIndex, int startIndex) {
/*"Copy count bytes into the current sound output buffer from the given sample
   buffer starting at the given index."*/
   ULONG rc;
   int framesWritten;

   if (!isStarted) return -1;

   if( emptyBuffQtity==0)
      return 0;

   if((BufferParms.ulBufferSize>>2) < frameCount)   //jmv ok este if?
      framesWritten = BufferParms.ulBufferSize>>2;
   else if((BufferParms.ulBufferSize>>2) == frameCount)
      framesWritten = frameCount;
   else {
      //jmv En este caso hago pmixWrite de un buffer incompleto,
      //que nunca se llena (la vez siguiente toma otr buffer!)
      //jmv Lo que hay que hacer es ir llenando buffers, y hacer pmixwrite y actualizar variables
      //    SOLAMENTE CUANDO LLENO UN BUFFER DEL TODO!
      framesWritten = frameCount;
      sprintf(ErrorMessage, "This should NOT happen! buf:%d, frames:%d", (BufferParms.ulBufferSize>>2), frameCount);
      ShowWarningMessage(ErrorMessage);
   }


   {
      short int *src, *dst, *end;
      src = (short int *) (arrayIndex + (startIndex * 4));
      end = (short int *) (arrayIndex + ((startIndex + framesWritten) * 4));
      dst = (short int *) MixBuffers[nextBuffToFill].pBuffer;
      while (src < end) {
         *dst++ = *src++;
      }
   }
   rc = MixSetupParms.pmixWrite( MixSetupParms.ulMixHandle, &MixBuffers[nextBuffToFill], 1 );
   if ( rc != MCIERR_SUCCESS ) {
      #ifdef WARNINGS
         sprintf(ErrorMessage, "pmixWrite()\n" "Return Code: %d.", rc);
         ShowWarningMessage(ErrorMessage);
      #endif
      return success(false);
   }

   nextBuffToFill = (nextBuffToFill + 1) % BUFF_QTITY;
   emptyBuffQtity--;
   return framesWritten;
}

int snd_PlaySilence(void) {
   ULONG rc;

   if (!isStarted) return -1;

   FillBufferWithSilence(&MixBuffers[nextBuffToFill]);

   // Si va en snd_PlaySamplesFromAtLength(), va aca!
   rc = MixSetupParms.pmixWrite( MixSetupParms.ulMixHandle, &MixBuffers[nextBuffToFill], 1 );
   if ( rc != MCIERR_SUCCESS ) {
      #ifdef WARNINGS
         sprintf(ErrorMessage, "pmixWrite()\n" "Return Code: %d.", rc);
         ShowWarningMessage(ErrorMessage);
      #endif
      return success(false);
   }

   nextBuffToFill = (nextBuffToFill + 1) % BUFF_QTITY;
   emptyBuffQtity--;
   return BufferParms.ulBufferSize>>2;
}

int snd_Start(int frameCount, int samplesPerSec, int stereo, int semaIndex) {
/*"Start double-buffered sound output with the given buffer size and sampling
   rate. If the given semaphore index is > 0, it is taken to be the index of
   a Semaphore in the external objects array to be signalled when the sound
   driver is ready to accept another buffer of samples."*/
   MCI_AMP_OPEN_PARMS   AmpOpenParms;
   ULONG                rc, ulIndex;
   int i;

   if (isStarted)
      /* still open from last time; clean up before continuing */
      snd_Stop();

   /* open the mixer device */
   memset ( &AmpOpenParms, '\0', sizeof ( MCI_AMP_OPEN_PARMS ) );
   AmpOpenParms.usDeviceID = ( USHORT ) 0;
   AmpOpenParms.pszDeviceType = ( PSZ ) MCI_DEVTYPE_AUDIO_AMPMIX;
   rc = mciSendCommand( 0, MCI_OPEN, MCI_WAIT | MCI_OPEN_TYPE_ID | MCI_OPEN_SHAREABLE, (PVOID) &AmpOpenParms, 0 );
   if ( rc != MCIERR_SUCCESS ) {
      #ifdef WARNINGS
         sprintf(ErrorMessage, "mciSendCommand(MCI_OPEN)\n" "Return Code: %d.", rc);
         ShowWarningMessage(ErrorMessage);
      #endif
      return success(false);
   }

   DARTDeviceID = AmpOpenParms.usDeviceID;

   /* Set the MixSetupParms data structure to match the loaded file.
    * This is a global that is used to setup the mixer. */
   memset( &MixSetupParms, '\0', sizeof(MCI_MIXSETUP_PARMS) );
   MixSetupParms.ulBitsPerSample = 16;
   MixSetupParms.ulFormatTag = MCI_WAVE_FORMAT_PCM;
   MixSetupParms.ulSamplesPerSec = samplesPerSec;
   MixSetupParms.ulChannels = 2;

   /* Setup the mixer for playback of wave data */
   MixSetupParms.ulFormatMode = MCI_PLAY;
   MixSetupParms.ulDeviceType = MCI_DEVTYPE_WAVEFORM_AUDIO;
   MixSetupParms.pmixEvent    = MyEvent;

   rc = mciSendCommand(DARTDeviceID, MCI_MIXSETUP, MCI_WAIT | MCI_MIXSETUP_INIT, (PVOID)&MixSetupParms, 0);
   if ( rc != MCIERR_SUCCESS ) {
      #ifdef WARNINGS
         sprintf(ErrorMessage, "mciSendCommand(MCI_MIXSETUP)\n" "Return Code: %d.", rc);
         ShowWarningMessage(ErrorMessage);
      #endif
      return success(false);
   }

   /* Set up the BufferParms data structure and allocate
    * device buffers from the Amp-Mixer */
   BufferParms.ulNumBuffers = BUFF_QTITY;
   BufferParms.ulBufferSize = frameCount*4; // / (MAX_BUFFERS/2);//jmv !!! ???(MAX_BUFFERS)???
   BufferParms.pBufList = MixBuffers;
   rc = mciSendCommand(DARTDeviceID, MCI_BUFFER, MCI_WAIT | MCI_ALLOCATE_MEMORY, (PVOID)&BufferParms, 0);
   // If there was any error
   if (ULONG_LOWD(rc) != MCIERR_SUCCESS ) {
      #ifdef WARNINGS
         sprintf(ErrorMessage, "mciSendCommand(MCI_BUFFER, MCI_ALLOCATE_MEMORY)\n" "Return Code: %d.", rc);
         ShowWarningMessage(ErrorMessage);
      #endif
      return success(false);
   }
   // If the quantity of buffers we asked for could not be allocated
   if (BufferParms.ulNumBuffers != BUFF_QTITY) {
      #ifdef WARNINGS
         sprintf(ErrorMessage, "mciSendCommand(MCI_BUFFER, MCI_ALLOCATE_MEMORY)\n"
                               "Returned Buffers:%d, Asked Buffers:%d.",
                               BufferParms.ulNumBuffers, BUFF_QTITY);
         ShowWarningMessage(ErrorMessage);
      #endif
      return success(false);
   }

   for (i=0; i<BUFF_QTITY; i++)
      memset(MixBuffers[i].pBuffer, '\0', BufferParms.ulBufferSize);

   SqueakSoundSemaIndex = semaIndex;
   emptyBuffQtity = BUFF_QTITY;
   nextBuffToFill = 0;
   actuallyPlayingBuff = 0;
   isStarted = -1;
   done = 0;
   /* Write buffers to kick off the amp mixer. */
   //jmv Realmente hace falta esto? (Win32 tiene una variable playingStarted)
   rc = MixSetupParms.pmixWrite( MixSetupParms.ulMixHandle, &MixBuffers[0], 2 );
   if ( rc != MCIERR_SUCCESS ) {
      #ifdef WARNINGS
         sprintf(ErrorMessage, "pmixWrite()\n" "Return Code: %d.", rc);
         ShowWarningMessage(ErrorMessage);
      #endif
      return success(false);
   }
   emptyBuffQtity-=2;  //jmv esto exige al menos 3 buffers!
   nextBuffToFill+=2;  //jmv esto exige al menos 3 buffers!
   return success(true);
}

int snd_Stop(void) {
   /*"Stop double-buffered sound output."*/
   /* Called by primitive 172 */
   MCI_GENERIC_PARMS    GenericParms;
   ULONG                rc;

   /* Si no esta abierto, no cerrar nada! */
   if(!isStarted)
      return;

   isStarted = 0;
   done = 1;
   rc = mciSendCommand( DARTDeviceID, MCI_STOP, MCI_WAIT , ( PVOID )&GenericParms, 0 );
   if ( rc != MCIERR_SUCCESS ) {
      #ifdef WARNINGS
         sprintf(ErrorMessage, "mciSendCommand(MCI_STOP)\n" "Return Code: %d.", rc);
         ShowWarningMessage(ErrorMessage);
      #endif
      return success(false);
   }
   rc = mciSendCommand( DARTDeviceID, MCI_BUFFER, MCI_WAIT | MCI_DEALLOCATE_MEMORY, ( PVOID )&BufferParms, 0 );
   if ( rc != MCIERR_SUCCESS ) {
      #ifdef WARNINGS
         sprintf(ErrorMessage, "mciSendCommand(MCI_BUFFER, MCI_DEALLOCATE_MEMORY)\n" "Return Code: %d.", rc);
         ShowWarningMessage(ErrorMessage);
      #endif
      return success(false);
   }

   rc = mciSendCommand( DARTDeviceID, MCI_CLOSE, MCI_WAIT , ( PVOID )&GenericParms, 0 );
   if ( rc != MCIERR_SUCCESS ) {
      #ifdef WARNINGS
         sprintf(ErrorMessage, "mciSendCommand(MCI_CLOSE)\n" "Return Code: %d.", rc);
         ShowWarningMessage(ErrorMessage);
      #endif
      return success(false);
   }
}

/* Sound Record */

LONG APIENTRY MyEventRec ( ULONG ulStatus, PMCI_MIX_BUFFER  pBuffer, ULONG  ulFlags  ) {
   switch( ulFlags ) {
   case MIX_STREAM_ERROR | MIX_READ_COMPLETE:  /* error occur in device */
      //jmv algo!
//OJO que parece entrar aca, pero no puede armar la ventanita!!!jmvjmvjmvjmv
//         sprintf(ErrorMessage, "Atencion, error en evento de grabacion jmv");
//         ShowWarningMessage(ErrorMessage);
      break;
   case MIX_READ_COMPLETE:           /* for playback  */
      if (recFilledBuffQtity < BUFF_QTITY)
         recFilledBuffQtity++;  //jmv revisar esto!
      signalSemaphoreWithIndex(SqueakRecSoundSemaIndex);  //jmv manejo mejorado de Andreas Raab
      //jmv estas 2 van juntas! (chquear que realmente apunten al que se esta tocando!)
      recActuallyRecordingBuff = (recActuallyRecordingBuff+1) % BUFF_QTITY;
      recLastFlipTime = ioMicroMSecs(); //jmv ACORDARSE QUE DART TIENE ALGO MEJOR (y que no tiene por que ir atado a actuallyPlayingBuffer)
      break;
   } /* end switch */
   return( TRUE );
} /* end MyEventRec */

int snd_SetRecordLevel(int level) {
   return success(true);  //jmv no es imprescindible pero hacelo!
}

int snd_StartRecording(int desiredSamplesPerSec, int stereo, int semaIndex) {
   /* turn on sound recording, trying to use a sampling rate close to
      the one specified. semaIndex is the index in the exportedObject
      array of a semaphore to be signalled when input data is available. */
      //jmvjmv ver que volar!
   MCI_AMP_OPEN_PARMS   AmpOpenParms;
   ULONG                rc, ulIndex;
   int i;

// jmvjmvjmv NO esta en la Mac
//   if (recordingInProgress)
//      /* still open from last time; clean up before continuing */
//      snd_StopRecording();

   /* open the mixer device */
   memset ( &AmpOpenParms, '\0', sizeof ( MCI_AMP_OPEN_PARMS ) );
   AmpOpenParms.usDeviceID = ( USHORT ) 0;
   AmpOpenParms.pszDeviceType = ( PSZ ) MCI_DEVTYPE_AUDIO_AMPMIX;
   rc = mciSendCommand( 0, MCI_OPEN, MCI_WAIT | MCI_OPEN_TYPE_ID | MCI_OPEN_SHAREABLE, (PVOID) &AmpOpenParms, 0 );
   if ( rc != MCIERR_SUCCESS ) {
      #ifdef WARNINGS
         sprintf(ErrorMessage, "REC: mciSendCommand(MCI_OPEN)\n" "Return Code: %d.", rc);
         ShowWarningMessage(ErrorMessage);
      #endif
      return success(false);
   }

   DARTRecDeviceID = AmpOpenParms.usDeviceID;

//if(!isRecAlloc) {
{
   /* Set the MixSetupParms data structure to match the loaded file.
    * This is a global that is used to setup the mixer. */
   memset( &RecMixSetupParms, '\0', sizeof(MCI_MIXSETUP_PARMS) );
   RecMixSetupParms.ulBitsPerSample = 16;
   RecMixSetupParms.ulFormatTag = MCI_WAVE_FORMAT_PCM;
   RecMixSetupParms.ulSamplesPerSec = desiredSamplesPerSec; //jmv!!! codigo para que intente con cosas mas normales!
   RecMixSetupParms.ulSamplesPerSec = 22050; //jmv!!! codigo para que intente con cosas mas normales!
   RecMixSetupParms.ulChannels = 2;
   RecMixSetupParms.ulChannels = 1; //jmv mono

   /* Setup the mixer for recording of wave data */
   RecMixSetupParms.ulFormatMode = MCI_RECORD;
   RecMixSetupParms.ulDeviceType = MCI_DEVTYPE_WAVEFORM_AUDIO;
   RecMixSetupParms.pmixEvent    = MyEventRec;

   rc = mciSendCommand(DARTRecDeviceID, MCI_MIXSETUP, MCI_WAIT | MCI_MIXSETUP_INIT, (PVOID)&RecMixSetupParms, 0);
   if ( rc != MCIERR_SUCCESS ) {
      #ifdef WARNINGS
         sprintf(ErrorMessage, "REC: mciSendCommand(MCI_MIXSETUP)\n" "Return Code: %d.", rc);
         ShowWarningMessage(ErrorMessage);
      #endif
      return success(false);
   }

   /* Set up the BufferParms data structure and allocate
    * device buffers from the Amp-Mixer */
   RecBufferParms.ulNumBuffers = BUFF_QTITY;
   RecBufferParms.ulBufferSize = REC_BUFF_SIZE; // / (MAX_BUFFERS/2);//jmv !!! ???(MAX_BUFFERS)???
   RecBufferParms.pBufList = RecMixBuffers;
   rc = mciSendCommand(DARTRecDeviceID, MCI_BUFFER, MCI_WAIT | MCI_ALLOCATE_MEMORY, (PVOID)&RecBufferParms, 0);
   // If there was any error
   if (ULONG_LOWD(rc) != MCIERR_SUCCESS ) {
      #ifdef WARNINGS
         sprintf(ErrorMessage, "REC: mciSendCommand(MCI_BUFFER, MCI_ALLOCATE_MEMORY)\n" "Return Code: %d.", rc);
         ShowWarningMessage(ErrorMessage);
      #endif
      return success(false);
   }
   // If the quantity of buffers we asked for could not be allocated
   if (RecBufferParms.ulNumBuffers != BUFF_QTITY) {
      #ifdef WARNINGS
         sprintf(ErrorMessage, "REC: mciSendCommand(MCI_BUFFER, MCI_ALLOCATE_MEMORY)\n"
                               "Returned Buffers:%d, Asked Buffers:%d.",
                               BufferParms.ulNumBuffers, BUFF_QTITY);
         ShowWarningMessage(ErrorMessage);
      #endif
      return success(false);
   }
   isRecAlloc=-1;
}

   for (i=0; i<BUFF_QTITY; i++)
      memset(RecMixBuffers[i].pBuffer, '\0', RecBufferParms.ulBufferSize);

   SqueakRecSoundSemaIndex = semaIndex;
   recFilledBuffQtity = 0;
   recNextBuffToDeliver = 0;
   recActuallyRecordingBuff = 0;
   recordingInProgress = -1;
   recDone = 0;
   /* Write buffers to kick off the amp mixer. */
   //jmv Realmente hace falta esto? (Win32 tiene una variable playingStarted)
   rc = RecMixSetupParms.pmixRead( RecMixSetupParms.ulMixHandle, &RecMixBuffers[0], 2 );
   if ( rc != MCIERR_SUCCESS ) {
      #ifdef WARNINGS
         sprintf(ErrorMessage, "REC: pmixRead()\n" "Return Code: %d.", rc);
         ShowWarningMessage(ErrorMessage);
      #endif
      return success(false);
   }
   return success(true);
}

int snd_StopRecording(void) {
   /* turn off sound recording */
   MCI_GENERIC_PARMS    GenericParms;
   ULONG                rc;

   /* Si no esta abierto, no cerrar nada! */
   if(!recordingInProgress)
      return 0;

   recordingInProgress = 0;
   recDone = 1;
   rc = mciSendCommand( DARTRecDeviceID, MCI_STOP, MCI_WAIT , ( PVOID )&GenericParms, 0 );
   if ( rc != MCIERR_SUCCESS ) {
      #ifdef WARNINGS
         sprintf(ErrorMessage, "REC: mciSendCommand(MCI_STOP)\n" "Return Code: %d.", rc);
         ShowWarningMessage(ErrorMessage);
      #endif
      return success(false);
   }

   rc = mciSendCommand( DARTRecDeviceID, MCI_BUFFER, MCI_WAIT | MCI_DEALLOCATE_MEMORY, ( PVOID )&RecBufferParms, 0 );
   if ( rc != MCIERR_SUCCESS ) {
      #ifdef WARNINGS
         sprintf(ErrorMessage, "REC: mciSendCommand(MCI_BUFFER, MCI_DEALLOCATE_MEMORY)\n" "Return Code: %d.", rc);
         ShowWarningMessage(ErrorMessage);
      #endif
      return success(false);
   }

   rc = mciSendCommand( DARTRecDeviceID, MCI_CLOSE, MCI_WAIT , ( PVOID )&GenericParms, 0 );
   if ( rc != MCIERR_SUCCESS ) {
      #ifdef WARNINGS
         sprintf(ErrorMessage, "REC: mciSendCommand(MCI_CLOSE)\n" "Return Code: %d.", rc);
         ShowWarningMessage(ErrorMessage);
      #endif
      return success(false);
   }
   /* JMV �hacer MCI_MIXSETUP_DEINIT? �Tambien en Play? */
   return 1;
}

double snd_GetRecordingSampleRate(void) {
   /* return the actual recording rate; fail if not currently recording */
//   return success(false);
   return 22050.0; //jmv hacelo chanta!
}

int snd_RecordSamplesIntoAtLength(int buf, int startSliceIndex, int bufferSizeInBytes) {
   /* if data is available, copy as many sample slices as possible into the
      given buffer starting at the given slice index. do not write past the
      end of the buffer, which is buf + bufferSizeInBytes. return the number
      of slices (not bytes) copied. a slice is one 16-bit sample in mono
      or two 16-bit samples in stereo. */
/* jmv Entonces, tengo que:
   src = recNextBuffToDeliver + recNextPositionToDeliver
   srcEnd = El final del ultimo buffer ya llenado  (TODAVIA NO IMPLEMENTADO)
   dst = nextBuf
   dstEnd = bufEnd
Copio hasta llegar a alguno de los dos finales. Devuelvo cuanto copie, y preparo para la siguiente
*/

   ULONG rc;
   char *dst = (char *) buf + (startSliceIndex<<1); //jmv ojo mono!
   char *dstEnd = (char *) buf + bufferSizeInBytes;
   char *src, *srcEnd;
   int bytesCopied;

//   if (!recordingInProgress) return -1;
   //jmv En Mac esta asi (revisar casos similares)
   if (!recordingInProgress) {
      success(false);
      return 0;
   }

   //jmv si no hay nada ya grabado a tomar para Squeak
   if(recFilledBuffQtity==0) {
      return 0;
   }

   src = (char*) ((short int *) RecMixBuffers[recNextBuffToDeliver].pBuffer + recNextPositionToDeliver);
   srcEnd = (char*)((short int *) RecMixBuffers[recNextBuffToDeliver].pBuffer + (RecBufferParms.ulBufferSize>>1)); //jmv ojo mono!
   /* jmv Esto copia a lo sumo hasta el final de 1 buffer de dart. Mejorarlo. Windoze pone todos los que se pueda */
   while ((src < srcEnd) && (dst < dstEnd)) {
      *dst++ = *src++;
   }

   /* jmv como termino? */
   if (src == srcEnd) {       /* jmv pasamos todo el buffer de dart */
      recNextPositionToDeliver = 0;
      /* jmv Uno menos para entregar */
      recNextBuffToDeliver = (recNextBuffToDeliver + 1) % BUFF_QTITY;
      recFilledBuffQtity--;
      /*jmv termine uno. Asi que pido otro */
      rc = RecMixSetupParms.pmixRead( RecMixSetupParms.ulMixHandle, &RecMixBuffers[recNextBuffToDeliver], 1 );
      if ( rc != MCIERR_SUCCESS ) {
         #ifdef WARNINGS
            sprintf(ErrorMessage, "REC: pmixRead()\n" "Return Code: %d.", rc);
            ShowWarningMessage(ErrorMessage);
         #endif
         return success(false);
      }
   } else {                   /* jmv quedo un cacho de buffer de dart sin pasar */
      recNextPositionToDeliver =
           (short int*)src - (short int *)RecMixBuffers[recNextBuffToDeliver].pBuffer;  /* update read index */
   }

   /* return the number of slices copied */
   bytesCopied = (int) dst - (buf + (startSliceIndex<<1));  //jmv ojo mono!
   return (bytesCopied>>1);   //jmv ojo mono!
}
#endif

   /* Set the "end-of-stream" flag */
//jmv   MixBuffers[buffQtity - 1].ulFlags = MIX_BUFFER_EOS;
