/****************************************************************************
*   Squeak port for OS/2
*
*   - Stub functions for nonimplemented yet primitives
*
* Feel free to experiment with this files, and to modify them anyway you like.
* If you fix any bugs, or enhance something, please let me know. I will
* include any enhancement on future releases. Bug reports are also welcome.
* I compile Squeak with IBM's VisualAge C++ for OS/2, but I think you can
* use other compilers as well if they support multimedia APIs (MMPM2.LIB).
* Enyoy!
*
*   Juan Manuel Vuletich
*    jvuletic@dc.uba.ar
*
*
* Originally from:
*   PROJECT: Squeak port for Win32 (NT / Win95)
*   FILE:    sqWin32Stubs.c
*   AUTHOR:  Andreas Raab (ar)
*   ADDRESS: University of Magdeburg, Germany
*   EMAIL:   raab@isg.cs.uni-magdeburg.de
*   RCSID:   $Id$
*
*   NOTES:
*****************************************************************************/
#include "sq.h"
#include "SoundPlugin.h"
#include "JoystickTabletPlugin.h"
#include "SocketPlugin.h"
#include "SerialPlugin.h"
#include "MidiPlugin.h"
#include "AsynchFilePlugin.h"
#include "sqFFI.h"

/*#define NO_SOUND*/
#define NO_JOYSTICK
/*#define NO_NETWORK*/
#define NO_SERIAL_PORT
#define NO_MIDI
#define NO_ASYNC_FILES
#define NO_TABLET // Don't even know what a tablet is!
#define NO_FFI


#ifdef NO_SOUND
int soundInit(void) { return success(false); }
int soundShutdown(void) { return success(false); }
int snd_AvailableSpace(void) { return success(false); }
int snd_InsertSamplesFromLeadTime(int frameCount, int srcBufPtr, int samplesOfLeadTime) { return success(false); }
int snd_PlaySamplesFromAtLength(int frameCount, int arrayIndex, int startIndex) { return success(false); }
int snd_PlaySilence(void) { return success(false); }
int snd_Start(int frameCount, int samplesPerSec, int stereo, int semaIndex) { return success(false); }
int snd_Stop(void) { return 1; }
int snd_SetRecordLevel(int level) { return success(false); }
int snd_StartRecording(int desiredSamplesPerSec, int stereo, int semaIndex) { return success(false); }
int snd_StopRecording(void) { return success(false); }
double snd_GetRecordingSampleRate(void) { return success(false); }
int snd_RecordSamplesIntoAtLength(int buf, int startSliceIndex, int bufferSizeInBytes) { return success(false); }
#endif

#ifdef NO_JOYSTICK
extern char *sqWin32JoystickRCSID="";
int joystickInit(void) { return 1; }
int joystickShutdown(void) { return success(false); }
int joystickRead(int stickIndex) { return success(false); }
#endif

#ifdef NO_NETWORK
int  sqNetworkInit(int resolverSemaIndex) { return success(false); }
void sqNetworkShutdown(void) { }
void sqResolverAbort(void) { success(false); }
void sqResolverAddrLookupResult(char *nameForAddress, int nameSize) { success(false); }
int  sqResolverAddrLookupResultSize(void) { return success(false); }
int  sqResolverError(void) { return success(false); }
int  sqResolverLocalAddress(void) { return success(false); }
int  sqResolverNameLookupResult(void) { return success(false); }
void sqResolverStartAddrLookup(int address) { success(false); }
void sqResolverStartNameLookup(char *hostName, int nameSize) { success(false); }
int  sqResolverStatus(void) { return success(false); }
void sqSocketAbortConnection(SocketPtr s) { success(false); }
void sqSocketCloseConnection(SocketPtr s) { success(false); }
int  sqSocketConnectionStatus(SocketPtr s) { return success(false); }
void sqSocketConnectToPort(SocketPtr s, int addr, int port) { success(false); }
void sqSocketCreateNetTypeSocketTypeRecvBytesSendBytesSemaID(SocketPtr s, int netType, int socketType,
                                      int recvBufSize, int sendBufSize, int semaIndex) { success(false); }
void sqSocketDestroy(SocketPtr s) { success(false); }
int  sqSocketError(SocketPtr s) { return success(false); }
void sqSocketListenOnPort(SocketPtr s, int port) { success(false); }
int  sqSocketLocalAddress(SocketPtr s) { return success(false); }
int  sqSocketLocalPort(SocketPtr s) { return success(false); }
int  sqSocketReceiveDataAvailable(SocketPtr s) { return success(false); }
int  sqSocketReceiveDataBufCount(SocketPtr s, int buf, int bufSize) { return success(false); }
int  sqSocketRemoteAddress(SocketPtr s) { return success(false); }
int  sqSocketRemotePort(SocketPtr s) { return success(false); }
int  sqSocketSendDataBufCount(SocketPtr s, int buf, int bufSize) { return success(false); }
int  sqSocketSendDone(SocketPtr s) { return success(false); }
#endif

#ifdef NO_SERIAL_PORT
int serialPortInit(void) { return success(false); }
int serialPortShutdown(void) { return success(false); }
int serialPortClose(int portNum) { return 1; }
int serialPortOpen(int portNum, int baudRate, int stopBitsType, int parityType, int dataBits,
                   int inFlowCtrl, int outFlowCtrl, int xOnChar, int xOffChar) { return success(false); }
int serialPortReadInto(int portNum, int count, int bufferPtr) { return success(false); }
int serialPortWriteFrom(int portNum, int count, int bufferPtr) { return success(false); }
#endif

#ifdef NO_MIDI
int midiInit(void) { return success(false); }
int midiShutdown(void) { return success(false); }
int sqMIDIGetClock(void) { return success(false); }
int sqMIDIGetPortCount(void) { return success(false); }
int sqMIDIGetPortDirectionality(int portNum) { return success(false); }
int sqMIDIGetPortName(int portNum, int namePtr, int length) { return success(false); }
int sqMIDIClosePort(int portNum) { return 1; }
int sqMIDIOpenPort(int portNum, int readSemaIndex, int interfaceClockRate) { return success(false); }
int sqMIDIParameterSet(int whichParameter, int newValue) { return success(false); }
int sqMIDIParameterGet(int whichParameter) { return success(false); }
int sqMIDIPortReadInto(int portNum, int count, int bufferPtr) { return success(false); }
int sqMIDIPortWriteFromAt(int portNum, int count, int bufferPtr, int time) { return success(false); }
#endif

#ifdef NO_ASYNC_FILES
int asyncFileInit(void) { return success(false); }
int asyncFileShutdown(void) { return success(false); }
int asyncFileClose(AsyncFile *f) { return success(false); }
int asyncFileOpen(AsyncFile *f, int fileNamePtr, int fileNameSize, int writeFlag, int semaIndex) { return success(false); }
int asyncFileRecordSize() { return success(false); }
int asyncFileReadResult(AsyncFile *f, int bufferPtr, int bufferSize) { return success(false); }
int asyncFileReadStart(AsyncFile *f, int fPosition, int count) { return success(false); }
int asyncFileWriteResult(AsyncFile *f) { return success(false); }
int asyncFileWriteStart(AsyncFile *f, int fPosition, int bufferPtr, int bufferSize) { return success(false); }
#endif

#ifdef NO_TABLET
int tabletGetParameters(int cursorIndex, int result[]) { return success(false); }
int tabletRead(int cursorIndex, int result[]) { return success(false); }
int tabletResultSize(void) { return success(false); }
#endif

/* browser plug-in support */
int plugInAllowAccessToFilePath(char *pathString, int pathStringLength) { return -1; }
void plugInForceTimeToReturn(void) { success(false); }
int plugInInit(char *imageName) { return success(false); }
int plugInNotifyUser(char *msg) { return success(false); }
void plugInSetStartTime(void) { success(false); }
int plugInShutdown(void) { return success(false); }
int plugInTimeToReturn(void) { return success(false); }

#ifdef NO_FFI
int ffiInitialize(void) { return success(false); }
int ffiCleanup(void) { return success(false); }
int ffiAlloc(int byteSize) { return success(false); }
int ffiFree(int ptr) { return success(false); }
int ffiPushSignedByte(int value) { return success(false); }
int ffiPushUnsignedByte(int value) { return success(false); }
int ffiPushSignedShort(int value) { return success(false); }
int ffiPushUnsignedShort(int value) { return success(false); }
int ffiPushSignedInt(int value) { return success(false); }
int ffiPushUnsignedInt(int value) { return success(false); }
int ffiPushSignedLongLong(int lowWord, int highWord) { return success(false); }
int ffiPushUnsignedLongLong(int lowWord, int highWord) { return success(false); }
int ffiLongLongResultLow(void) { return success(false); }
int ffiLongLongResultHigh(void) { return success(false); }
int ffiPushSignedChar(int value) { return success(false); }
int ffiPushUnsignedChar(int value) { return success(false); }
int ffiPushSingleFloat(double value) { return success(false); }
int ffiPushDoubleFloat(double value) { return success(false); }
int ffiPushStructureOfLength(int pointer, int* structSpec, int specSize) { return success(false); }
int ffiPushPointer(int pointer) { return success(false); }
int ffiPushStringOfLength(int srcIndex, int length) { return success(false); }
int ffiSupportsCallingConvention(int callType) { return success(false); }
int ffiCanReturn(int* structSpec, int specSize) { return success(false); }
int ffiCallAddressOfWithPointerReturn(int fn, int callType) { return success(false); }
int ffiCallAddressOfWithStructReturn(int fn, int callType, int* structSpec, int specSize) { return success(false); }
int ffiCallAddressOfWithReturnType(int fn, int callType, int typeSpec) { return success(false); }
int ffiStoreStructure(int address, int structSize) { return success(false); }
double ffiReturnFloatValue(void) { success(false); return 0.0; }
#endif

// Still not implemented - OS Drag & Drop
int dropRequestFileHandle(int dropIndex) { return success(false); }
int dropShutdown(void) { return success(false); }
int dropInit(void) { return success(false); }
char* dropRequestFileName(int dropIndex) { success(false); return (char*)0; }

// Still not implemented - Sound
void snd_Volume(double *left, double *right) { success(false); }
void snd_SetVolume(double left, double right) { success(false); }

// Still not implemented - Power Management
int ioDisablePowerManager(int disableIfNonZero) { return success(false); }

// Still not implemented - OS events
int ioSetInputSemaphore(int semaIndex) { return success(false); }
int ioGetNextEvent(sqInputEvent *evt) { return success(false); }
