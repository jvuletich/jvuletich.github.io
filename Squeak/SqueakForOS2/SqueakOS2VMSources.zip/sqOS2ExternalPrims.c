/****************************************************************************
*   Squeak port for OS/2
*
*   - Named External Primitives support
*
* Feel free to experiment with this files, and to modify them anyway you like.
* If you fix any bugs, or enhance something, please let me know. I will
* include any enhancement on future releases. Bug reports are also welcome.
* I compile Squeak with IBM's VisualAge C++ for OS/2, but I think you can
* use other compilers as well if they support multimedia APIs (MMPM2.LIB).
* Enyoy!
*
*   Juan Manuel Vuletich
*    jvuletic@dc.uba.ar
*
*****************************************************************************/
#define INCL_DOSMODULEMGR
#define INCL_DOSERRORS
#include <os2.h>
#include <stdio.h>
#include "sq.h"

// This is to include warnings to the user in case of API failures (in addition to primitive fail)
#define WARNINGS 1

/***************************************************************************/
/* Function Prototypes                                                     */
/*          Support Function from sqOS2Window.c                            */
/***************************************************************************/
char ErrorMessage[200];
void ShowErrorMessage(char* ErrorMessage);
void ShowWarningMessage(char* ErrorMessage);


/* Try to load a given library. Return it's handle or NULL */
int ioLoadModule(char *libName) {
   char loadName[255];
   char shortLoadName[255];
   char loadError[255];

   HDIR          hdirFindHandle = HDIR_CREATE;
   FILEFINDBUF3  FindBuffer     = {0};      /* Returned from FindFirst/Next */
   ULONG         ulResultBufLen = sizeof(FILEFINDBUF3);
   ULONG         ulFindCount    = 1;        /* Look for 1 file at a time    */

   APIRET rc;
   HMODULE h;

   strcpy(loadName, ".\\");
   strcat(loadName, libName);
   strcat(loadName, ".dll");
   /* jmvjmv OS/2 seems not to allow long dll names. Truncate the given name to 8 chars.
      When compiling a Squeak plugin on OS/2, rename the dll so it won't use more than 8 chars!!!
      (jmv is this really this way??? is there any fix to allow using long name dlls???) */
   strcpy(shortLoadName, ".\\");
   strcat(shortLoadName, libName);
   shortLoadName[10] = '\0';
   strcat(shortLoadName, ".dll");

   rc = DosLoadModule(loadError, sizeof(loadError), shortLoadName, &h);
   if(rc != NO_ERROR) {
      /* No error message should be sent to the user.
         The primitive call will fail, and someone will take care of that
      #ifdef WARNINGS
         sprintf(ErrorMessage, "DosLoadModule failed with return code %u for %s \n"
                               "when trying to load module %s.", rc, loadError shortLoadName);
         ShowWarningMessage(ErrorMessage);
      #endif
      */
      rc = DosFindFirst(loadName, &hdirFindHandle, FILE_NORMAL, &FindBuffer, ulResultBufLen, &ulFindCount, FIL_STANDARD);
      DosFindClose(hdirFindHandle);
      if(!rc) {
         sprintf(ErrorMessage, "I can't handle DLL's with long file names.\n"
                               "Please copy or rename %s to %s.\n"
                               "(Primitive will fail, this is probably not fatal).", loadName, shortLoadName);
         ShowWarningMessage(ErrorMessage);
      }
      h = 0;
   }
   return (int) h;
}

int ioFreeModule(int handle) {
   DosFreeModule((HMODULE) handle);
      return success(true);
}

int ioFindExternalFunctionIn(char* functionName, int handle) {
   int i;
   void *fn;
   APIRET rc;

   /* Load the function address from the module handle */
   rc = DosQueryProcAddr((HMODULE)handle, 0, functionName, (PFN*)&fn);
   if(rc != NO_ERROR) {
      #ifdef WARNINGS
         sprintf(ErrorMessage, "DosQueryProcAddr failed with return code %u\n"
                               "when trying to find function %s().", rc, functionName);
         ShowWarningMessage(ErrorMessage);
      #endif
      fn = (void*) 0;
   }

   if(!fn)
      return success(false);

   return (int) fn;
}
