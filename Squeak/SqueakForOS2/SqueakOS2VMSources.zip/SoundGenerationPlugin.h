/* obsolete primitives for backward compatibility */
int primFMSoundmixSampleCountintostartingAtpan(void);
int oldprimSampledSoundmixSampleCountintostartingAtleftVolrightVol(void);
int primPluckedSoundmixSampleCountintostartingAtpan(void);
int primSampledSoundmixSampleCountintostartingAtpan(void);
int primWaveTableSoundmixSampleCountintostartingAtpan(void);
