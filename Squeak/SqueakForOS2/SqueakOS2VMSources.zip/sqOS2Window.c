/****************************************************************************
*   Squeak port for OS/2
*
*   - Window, mouse and keyboard primitives
*   - assorted support primitives
*   - main() and OS event processing functions
*
* Feel free to experiment with this files, and to modify them anyway you like.
* If you fix any bugs, or enhance something, please let me know. I will
* include any enhancement on future releases. Bug reports are also welcome.
* I compile Squeak with IBM's VisualAge C++ for OS/2, but I think you can
* use other compilers as well if they support multimedia APIs (MMPM2.LIB).
* Enyoy!
*
*   Juan Manuel Vuletich
*    jvuletic@dc.uba.ar
*
*****************************************************************************/
/* Things that need to be enhanced
 - Variable names
 - DIVE has DiveBlitImageLines(), could be useful to avoid DiveSetup() each time!
 - Add some assertions
 - Possible VM optimizations (IP and SP in registers, checkassertions variable, etc)
 - JITTER
 - Look at ivmcpp\include\os2\DIVE.H comments about color Palettes. Improve palette management.
 - Squeak times are in seconds, 32 bits gives only 136 years (from 1901 to 2037)
   (if this is modified, be careful with leap years 4 - 100 - 400 - 4000 in
    convertToSqueakTime() and ioSeconds() on this and all the other platforms!)
 - Avoid parameters in time critical function calls. Use globals instead (if no recursion or reentering needed!)
 - DIVEBlitterSetup.ulDitherType as a command line option
 - You can erase Squeak window with another window
 - Squeak window does not update if not in focus
 - Check for maximized app, to avoid palette sharing and avoiding overwriting other windows checks
*/
/***************************************************************************/

/***************************************************************************/
/* Include files                                                           */
/***************************************************************************/
#define INCL_WIN
#define INCL_DOS
#define INCL_DOSFILEMGR
#define INCL_DOSMEMMGR
#define INCL_DOSPROCESS
#define INCL_DOSSESMGR
#define INCL_WINSTDFILE
#define INCL_WINACCELERATORS
#define INCL_GPIPRIMITIVES
#define INCL_GPIBITMAPS
#define INCL_GPI
#define INCL_WINPOINTERS
#define INCL_BASE
#define INCL_DOSEXCEPTIONS
#include <os2.h>
#include <string.h>
#include <stdlib.h>
#include <stdarg.h>
#include <stdio.h>
#include <mmioos2.h>                    /* It is from MMPM toolkit           */
#include <dive.h>
#include <fourcc.h>
#include <float.h>
#include "sq.h"

/* OS/2 PM */
#define WIN_CLASS_NAME              "WC_CLIENT"   /* Client window class name */

/*** Variables -- Imported from Virtual Machine ***/
extern int interruptPending;
extern int interruptCheckCounter;
extern int interruptKeycode;
extern int savedWindowSize;

/***************************************************************************/
/* Global variables                                                        */
/***************************************************************************/
/* Preallocated space for error messages */
int  ErrorCode;
char ErrorMessage[200];

/* DIVE & Palette */
HPAL hpal = NULLHANDLE;
struct {
      unsigned char blue;
      unsigned char green;
      unsigned char red;
      unsigned char flags;
} colorPalette[256];
short           WindowSizeX = 0;
short           WindowSizeY = 0;
SWP             ClientWindowPosition;
SWP             FrameWindowPosition;
RECTL           DIVEUpdateRect = {0, 0, 640, 480};
SETUP_BLITTER   DIVEBlitterSetup;              /* structure for DiveBlitterSetup  */
unsigned long   DIVEBuffNum=0;
HDIVE           DIVEHandle=0;                  /* DIVE handle                         */
FOURCC          FccSrcColorFormat;             /* Bitmap color format                 */
HAB             hab = NULLHANDLE;              /* Anchor block handle */
QMSG            qmsg;                          /* Message data structure */
HMQ             hmq = NULLHANDLE;              /* Message queue handle */
HWND            hwndFrame = NULLHANDLE;        /* Frame window handle */
HWND            hwndClient = NULLHANDLE;       /* client window handle */
POINTL          mousePosition;                 /* position at last PointerMotion event */
HPOINTER        hptr = NULLHANDLE;
unsigned char * SqueakMousePointerAndMask=0, * SqueakMousePointerXorMask=0;
HBITMAP         hbm = NULLHANDLE;
HPS             hps = NULLHANDLE;
HDC             hdc = NULLHANDLE;

/* To allow use of normal RAM for video buffers */
int DoNotUseVRAMBuffer = 0;
PBYTE NoVRAMBuffer = 0;

/* Parameters for CopyForDepthXX - They are globals just for calling speed */
int* PtDIVESourceBuffer;
int* PtSqueakBuffer;
int SqueakWidth;
int DIVEWidthInWords;
int AffectedL;
int AffectedR;
int AffectedT;
int AffectedB;

/*** Variables -- Event Recording ***/
#define KEYBUF_SIZE 64

int keyBuf[KEYBUF_SIZE];        /* circular buffer */
int keyBufGet= 0;               /* index of next item of keyBuf to read */
int keyBufPut= 0;               /* index of next item of keyBuf to write */
int keyBufOverflows= 0;         /* number of characters dropped */

int buttonState= 0;             /* mouse button and modifier state when mouse
                                   button went down or 0 if not pressed */

/* image file and VM path names */
/* jmv */
#define MAX_PATH 255
#define IMAGE_NAME_SIZE MAX_PATH
char imageName[MAX_PATH+1];            /* full path to image */
char vmPath[MAX_PATH+1];               /* full path to interpreter's directory */
char vmName[MAX_PATH+1];               /* name of the interpreter's executable */
char documentName[MAX_PATH+1];         /* full path to the documents name */

/* The following is a mapping to Mac Roman glyphs.
   It is not entirely correct since a number of glyphs are
   different but should be good enough for Squeak.
   More significantly, we can now map in both directions. */
unsigned char keymap[256] =
{
  0,  1,  2,  3,  4,  5,  6,  7,  8,  9, 10, 11, 12, 13, 14, 15,
 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31,
 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47,
 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63,
 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79,
 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95,
 96, 97, 98, 99,100,101,102,103,104,105,106,107,108,109,110,111,
112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127,
130,159,142,137,138,136,140,141,144,145,143,149,148,147,128,129,
131,190,174,153,154,152,158,157,216,133,134,162,163,180,139,196,
135,146,151,156,150,132,187,188,192,201,194,155,160,193,199,200,
161,164,165,166,168,169,170,171,172,173,185,186,198,202,203,204,
205,206,207,208,209,211,212,213,215,217,218,219,220,221,222,223,
224,226,227,228,229,230,231,232,233,234,235,236,237,238,239,240,
244,167,246,184,183,247,181,248,191,249,189,182,176,175,252,253,
254,177,178,179,255,210,214,197,251,225,250,195,241,242,245,243
};

/* The following is the inverse keymap */
unsigned char iKeymap[256];

/***************************************************************************/
/* Function Prototypes                                                     */
/*          Squeak Primitives                                              */
/***************************************************************************/
/* File Naming, path */
int imageNameSize(void);
int imageNameGetLength(int sqImageNameIndex, int length);
int imageNamePutLength(int sqImageNameIndex, int length);
int vmPathSize(void);
int vmPathGetLength(int sqVMPathIndex, int length);
/* System Attributes */
char* GetAttributeString(int id);
int attributeSize(int id);
int getAttributeIntoLength(int id, int byteArrayIndex, int length);
/* Mouse and Keyboard */
int ioGetButtonState(void);
int ioGetKeystroke(void);
int ioPeekKeystroke(void);
int ioMousePoint(void);
/* Screen */
int ioScreenSize(void);
int ioSetCursor(int cursorBitsIndex, int offsetX, int offsetY);
int ioSetCursorWithMask(int cursorBitsIndex, int cursorMaskIndex, int offsetX, int offsetY);
int ioShowDisplay(int dispBitsIndex, int width, int height, int depth,
                  int affectedL, int affectedR, int affectedT, int affectedB);
int ioFormPrint(int bitsAddr, int width, int height, int depth,
                double hScale, double vScale, int landscapeFlag);
int ioForceDisplayUpdate(void);
int ioSetFullScreen(int fullScreen);
int ioSetDisplayMode(int width, int height, int depth, int fullscreenFlag);
int ioHasDisplayDepth(int depth);
/* Time & various */
int ioProcessEvents(void);
int ioRelinquishProcessorForMicroseconds(int microSeconds);
int ioLoResMSecs(void);
int ioMSecs(void);
int ioMicroMSecs(void);
int ioSeconds(void);
int ioBeep(void);
int ioExit(void);
/* Clipboard */
int clipboardSize(void);
int clipboardWriteFromAt(int count, int byteArrayIndex, int startIndex);
int clipboardReadIntoAt(int count, int byteArrayIndex, int startIndex);
/* Profile */
int clearProfile(void);
int dumpProfile(void);
int startProfiling(void);
int stopProfiling(void);

/***************************************************************************/
/* Function Prototypes                                                     */
/*          Support Function                                               */
/***************************************************************************/
void SilentExit(int returnCode);
void ErrorExit(char* ErrorMessage);
void ShowErrorMessage(char* ErrorMessage);
void ShowWarningMessage(char* ErrorMessage);
int printf(const char *fmt, ...);   /* Might be called from the Interpreter */
/* display, mouse, keyboard, time i/o */
void recordMouseDown(void);
void recordModifierButtons(void);
void recordVirtualKey(SHORT virtualKey);
void recordKeystroke(SHORT characterCode);
/* Various setup                                 */
void SetColorEntry(int index, int red, int green, int blue);
void SetUpPixmaps(void);
void SetupKeymap(void);
void SetWindowSize(void);
void setupFilesAndPath(void);
/* Squeak screen to DIVE buffer copy functions */
void CopyForDepth1(void);
void CopyForDepth2(void);
void CopyForDepth4(void);
void CopyForDepth8(void);
void CopyForDepth16(void);
void CopyForDepth32(void);

/* polling functions in socket/sound plugins, called from HandleEvents */
void (*socketPollFunction)(int delay, int extraFd)= 0;   /* aioPollForIO */

/***************************************************************************/
/* Function Prototypes                                                     */
/*          main(), windowProcedure() and handler for OS/2 exceptions      */
/***************************************************************************/
int main(int argc, char * argv[]);
MRESULT APIENTRY fnClientWndProc(HWND, ULONG, MPARAM, MPARAM);
ULONG _System sqOS2ExceptionHandler(PEXCEPTIONREPORTRECORD,
                            PEXCEPTIONREGISTRATIONRECORD,
                            PCONTEXTRECORD,
                            PVOID);

/***************************************************************************/
/* Function Definition                                                     */
/*          Squeak Primitives                                              */
/***************************************************************************/
/* File Naming, path */
int imageNameSize(void) {
  return strlen(imageName);
}

int imageNameGetLength(int sqImageNameIndex, int length) {
  char *sqImageName = (char*)sqImageNameIndex;
  int count, i;
  count= strlen(imageName);
  count= (length < count) ? length : count;
  /* copy the file name into the Squeak string */
  for (i= 0; i < count; i++)
    sqImageName[i]= imageName[i];
  return count;
}

int imageNamePutLength(int sqImageNameIndex, int length) {
   char *sqImageName= (char *)sqImageNameIndex;
   char tmpImageName[MAX_PATH+1];
   char *tmp;
   int count, i;
   count= (IMAGE_NAME_SIZE < length) ? IMAGE_NAME_SIZE : length;
   /* copy the file name into a null-terminated C string */
   for (i= 0; i < count; i++)
     tmpImageName[i]= sqImageName[i];
   tmpImageName[count]= 0;
   /* Note: We have to preserve the fully qualified image path */
   tmp = strrchr(tmpImageName,'\\');
   if(tmp) {
     /* fully qualified */
       strcpy(imageName,tmpImageName);
   } else { /* not qualified */
       tmp = strrchr(imageName,'\\');
       if(!tmp)
         strcpy(imageName,tmpImageName);
       else {
           tmp++; *tmp = 0;
           count = IMAGE_NAME_SIZE - (tmp-imageName);
           if(count < length)
             tmpImageName[count] = 0;
           strcat(imageName,tmpImageName);
       }
   }
   //jmv SetWindowTitle(shortImageName);
   return count;
}

/*** VM Home Directory Path ***/
int vmPathSize(void) {
  return strlen(vmPath);
}

int vmPathGetLength(int sqVMPathIndex, int length) {
  char *stVMPath= (char *)sqVMPathIndex;
  int count, i;
  count= strlen(vmPath);
  count= (length < count) ? length : count;
  /* copy the file name into the Squeak string */
  for (i= 0; i < count; i++)
    stVMPath[i]= vmPath[i];
  return count;
}

/* System Attributes */
char* GetAttributeString(int id) {
   /* This is a hook for getting various status strings back from
      the OS. In particular, it allows Squeak to be passed arguments
      such as the name of a file to be processed. Command line options
      could be reported this way as well.
   */
   switch (id) {
      case 0:
         return documentName;
         break;
     }
     return "";
}

int attributeSize(int id) {
   return strlen(GetAttributeString(id));
}

int getAttributeIntoLength(int id, int byteArrayIndex, int length) {
   char *srcPtr, *dstPtr, *end;
   int charsToMove;

   srcPtr = GetAttributeString(id);
   charsToMove = strlen(srcPtr);
   if (charsToMove > length) {
      charsToMove = length;
   }

   dstPtr = (char *) byteArrayIndex;
   end = srcPtr + charsToMove;
   while (srcPtr < end) {
      *dstPtr++ = *srcPtr++;
   }
   return charsToMove;
}

/* Mouse and Keyboard */
int ioGetButtonState(void) {
  ioProcessEvents();  /* process all pending events */
  return buttonState;
}

int ioGetKeystroke(void) {
  int keystate;

  ioProcessEvents();  /* process all pending events */
  if (keyBufGet == keyBufPut)
    return -1;  /* keystroke buffer is empty */

  keystate= keyBuf[keyBufGet];
  keyBufGet= (keyBufGet + 1) % KEYBUF_SIZE;
  /* set modifer bits in buttonState to reflect the last keystroke fetched */
  buttonState= ((keystate >> 5) & 0xF8) | (buttonState & 0x7);
  return keystate;
}

int ioPeekKeystroke(void) {
  int keystate;

  ioProcessEvents();  /* process all pending events */
  if (keyBufGet == keyBufPut)
    return -1;  /* keystroke buffer is empty */

  keystate= keyBuf[keyBufGet];
  /* set modifer bits in buttonState to reflect the last keystroke peeked at */
  buttonState= ((keystate >> 5) & 0xF8) | (buttonState & 0x7);
  return keystate;
}

int ioMousePoint(void) {
  ioProcessEvents();  /* process all pending events */
  /* x is high 16 bits; y is low 16 bits */
  return (mousePosition.x << 16) | (WindowSizeY-mousePosition.y);
}

/* Screen */
int ioScreenSize(void) {
   /* width is high 16 bits; height is low 16 bits */
   return (WindowSizeX << 16) | (WindowSizeY);
}

int ioSetCursor(int cursorBitsIndex, int offsetX, int offsetY) {
   /* Old version; forward to new version. */
   return ioSetCursorWithMask(cursorBitsIndex, 0, offsetX, offsetY);
}

int ioSetCursorWithMask(int cursorBitsIndex, int cursorMaskIndex, int offsetX, int offsetY) {
   /* Set the 16x16 mouse pointer cursor bitmap. If cursorMaskIndex is 0, then make the mask the
      same as the cursor bitmap. If not, then mask and cursor bits combined determine how cursor is
      displayed:
         mask  cursor   effect
           0     0        transparent (underlying pixel shows through)
           1     1        opaque black
           1     0        opaque white
           0     1        invert the underlying pixel
   */
   static int cx=0,cy=0,cursorSize=0;
   BITMAPINFO2 bmi;
   int i;
   int rc;
   HBITMAP hbmOld;
   HPOINTER hSysPointer;
   POINTERINFO pointerInfo;
   SIZEL imageSize;

   /* Initialize pointer masks */
   if(!SqueakMousePointerAndMask || !SqueakMousePointerXorMask) {
      cx = WinQuerySysValue(HWND_DESKTOP, SV_CXPOINTER);
      cy = WinQuerySysValue(HWND_DESKTOP, SV_CYPOINTER);
      cursorSize = cx*cy / 8;
      SqueakMousePointerAndMask = malloc(cursorSize);
      SqueakMousePointerXorMask = malloc(cursorSize);
      memset(SqueakMousePointerAndMask, 0xff, cursorSize);
      memset(SqueakMousePointerXorMask, 0x00, cursorSize);
   }
   bmi.cbFix = 16;
   bmi.cx = cx;
   bmi.cy = cy*2;
   bmi.cPlanes = 1;
   bmi.cBitCount = 1;

   /* Create a memory device context and a memory presentation space */
   if ( hdc == NULLHANDLE)
      hdc = DevOpenDC (hab, OD_MEMORY, "*", 0L, NULL, 0);
   if ( hps == NULLHANDLE ) {
      imageSize.cx = cx;
      imageSize.cy = cy*2;
      hps = GpiCreatePS(hab, hdc, &imageSize, PU_PELS | GPIF_DEFAULT | GPIT_MICRO | GPIA_ASSOC );
      if ( !hps ) {
         ErrorCode = WinGetLastError(hab);
         sprintf(ErrorMessage, "GpiCreatePS()\n" "Return Code: %d.", ErrorCode);
         ShowErrorMessage(ErrorMessage);
         return -1;
      }
   }

   /* If we had an old pointer, destroy it */
   if (hptr != NULLHANDLE) {
      WinDestroyPointer(hptr);
   }
   /* Set the new pointer data */
   if (cursorMaskIndex == 0) {
      for (i=0; i<16; i++) {
         SqueakMousePointerAndMask[(31-i)*cx/8+0] = ~(checkedLongAt(cursorBitsIndex + (4 * i)) >> 24) & 0xFF;
         SqueakMousePointerAndMask[(31-i)*cx/8+1] = ~(checkedLongAt(cursorBitsIndex + (4 * i)) >> 16) & 0xFF;
         SqueakMousePointerXorMask[(31-i)*cx/8+0] = 0;
         SqueakMousePointerXorMask[(31-i)*cx/8+1] = 0;
      }
   } else {
      for (i=0; i<16; i++) {
         SqueakMousePointerAndMask[(31-i)*cx/8+0] = ~(checkedLongAt(cursorMaskIndex + (4 * i)) >> 24) & 0xFF;
         SqueakMousePointerAndMask[(31-i)*cx/8+1] = ~(checkedLongAt(cursorMaskIndex + (4 * i)) >> 16) & 0xFF;
         SqueakMousePointerXorMask[(31-i)*cx/8+0] = ((checkedLongAt(cursorMaskIndex + (4 * i)) >> 24)  ^
                                                    (checkedLongAt(cursorBitsIndex + (4 * i)) >> 24)) & 0xFF;
         SqueakMousePointerXorMask[(31-i)*cx/8+1] = ((checkedLongAt(cursorMaskIndex + (4 * i)) >> 16)  ^
                                                    (checkedLongAt(cursorBitsIndex + (4 * i)) >> 16)) & 0xFF;
      }
   }

   /* Ask for a copy of a system pointer, to modify it */
   hSysPointer = WinQuerySysPointer(HWND_DESKTOP, SPTR_MOVE, TRUE);
   WinQueryPointerInfo(hSysPointer, &pointerInfo);

   /* Prepare pointer bitmap */
   hbmOld = GpiSetBitmap(hps, pointerInfo.hbmPointer);
   if(hbmOld == HBM_ERROR) {
      ErrorCode = WinGetLastError(hab);
      sprintf(ErrorMessage, "GpiSetBitmap()\n" "Return Code: %d.", ErrorCode);
      ShowErrorMessage(ErrorMessage);
      WinDestroyPointer(hSysPointer);
      return -1;
   }
   /* This call is needed for GpiSetBitmapBits to work (I don't know why!) */
   {
      char dummyData[1024];
      GpiQueryBitmapBits(hps, cx, cx*2, dummyData, &bmi);
   }
   /* Set And mask */
   rc = GpiSetBitmapBits(hps, cy, cy, SqueakMousePointerAndMask, &bmi);
   if(rc==GPI_ALTERROR) {
      ErrorCode = WinGetLastError(hab);
      sprintf(ErrorMessage, "GpiSetBitmapBits()\n" "Return Code: %d.", ErrorCode);
      ShowErrorMessage(ErrorMessage);
      WinDestroyPointer(hSysPointer);
      return -1;
   }
   /* Set Xor mask*/
   rc = GpiSetBitmapBits(hps, 0, cy, SqueakMousePointerXorMask, &bmi);
   if(rc==GPI_ALTERROR) {
      ErrorCode = WinGetLastError(hab);
      sprintf(ErrorMessage, "GpiSetBitmapBits()\n" "Return Code: %d.", ErrorCode);
      ShowErrorMessage(ErrorMessage);
      WinDestroyPointer(hSysPointer);
      return -1;
   }
   hbmOld = GpiSetBitmap(hps, hbmOld);

   /* Create the new pointer */
   pointerInfo.xHotspot = -offsetX;
   pointerInfo.yHotspot = cy + offsetY;
   hptr = WinCreatePointerIndirect(HWND_DESKTOP, &pointerInfo);
   if(!hptr) {
      ErrorCode = WinGetLastError(hab);
      sprintf(ErrorMessage, "WinCreatePointer()\n" "Return Code: %d.", ErrorCode);
      ShowErrorMessage(ErrorMessage);
      WinDestroyPointer(hSysPointer);
      return -1;
   }
   /* Set the new pointer */
   rc = WinSetPointer(HWND_DESKTOP, hptr);
   if(!rc) {
      ErrorCode = WinGetLastError(hab);
      sprintf(ErrorMessage, "WinSetPointer()\n" "Return Code: %d.", ErrorCode);
      ShowErrorMessage(ErrorMessage);
      WinDestroyPointer(hSysPointer);
      return -1;
   }
   WinDestroyPointer(hSysPointer);
   return 0;
}

int OLDioSetCursorWithMask(int cursorBitsIndex, int cursorMaskIndex, int offsetX, int offsetY) {
   /* Set the 16x16 mouse pointer cursor bitmap. If cursorMaskIndex is 0, then make the mask the
      same as the cursor bitmap. If not, then mask and cursor bits combined determine how cursor is
      displayed:
         mask  cursor   effect
           0     0        transparent (underlying pixel shows through)
           1     1        opaque black
           1     0        opaque white
           0     1        invert the underlying pixel
   */
   static int cx=0,cy=0,cursorSize=0;
   static BITMAPINFOHEADER2 bmih;
   int i;
   int rc;
   HBITMAP hbmOld;

   SIZEL imageSize;

   /* Initialize pointer masks */
   if(!SqueakMousePointerAndMask || !SqueakMousePointerXorMask) {
      cx = WinQuerySysValue(HWND_DESKTOP, SV_CXPOINTER);
      cy = WinQuerySysValue(HWND_DESKTOP, SV_CYPOINTER);
      cursorSize = cx*cy / 8;
      SqueakMousePointerAndMask = malloc(cursorSize);
      SqueakMousePointerXorMask = malloc(cursorSize);
      memset(SqueakMousePointerAndMask, 0xff, cursorSize);
      memset(SqueakMousePointerXorMask, 0x00, cursorSize);
   }

   /* Create a memory device context and a memory presentation space */
   if ( hdc == NULLHANDLE)
      hdc = DevOpenDC (hab, OD_MEMORY, "*", 0L, NULL, 0);
   if ( hps == NULLHANDLE ) {
      imageSize.cx = cx;
      imageSize.cy = cy*2;
      hps = GpiCreatePS(hab, hdc, &imageSize, PU_PELS | GPIF_DEFAULT | GPIT_MICRO | GPIA_ASSOC );
      if ( !hps ) {
         ErrorCode = WinGetLastError(hab);
         sprintf(ErrorMessage, "GpiCreatePS()\n" "Return Code: %d.", ErrorCode);
         ShowErrorMessage(ErrorMessage);
         return -1;
      }
   }

   /* If the bitmap wasn't created, create it */
   if (hbm == NULLHANDLE) {
      memset (&bmih,0, sizeof(BITMAPINFOHEADER2));
      bmih.cbFix = 16;
      bmih.cx = cx;
      bmih.cy = cy*2;
      bmih.cPlanes = 1;
      bmih.cBitCount = 1;
      hbm = GpiCreateBitmap(hps, &bmih, 0L, NULL, NULL);
      if(!hbm) {
         ErrorCode = WinGetLastError(hab);
         sprintf(ErrorMessage, "GpiCreateBitmap()\n" "Return Code: %d.", ErrorCode);
         ShowErrorMessage(ErrorMessage);
         return -1;
      }
   }

   /* If we had an old pointer, destroy it */
   if (hptr != NULLHANDLE) {
      WinDestroyPointer(hptr);
   }
   /* Set the new pointer data */
   if (cursorMaskIndex == 0) {
      for (i=0; i<16; i++) {
         SqueakMousePointerAndMask[(31-i)*cx/8+0] = ~(checkedLongAt(cursorBitsIndex + (4 * i)) >> 24) & 0xFF;
         SqueakMousePointerAndMask[(31-i)*cx/8+1] = ~(checkedLongAt(cursorBitsIndex + (4 * i)) >> 16) & 0xFF;
         SqueakMousePointerXorMask[(31-i)*cx/8+0] = 0;
         SqueakMousePointerXorMask[(31-i)*cx/8+1] = 0;
      }
   } else {
      for (i=0; i<16; i++) {
         SqueakMousePointerAndMask[(31-i)*cx/8+0] = ~(checkedLongAt(cursorMaskIndex + (4 * i)) >> 24) & 0xFF;
         SqueakMousePointerAndMask[(31-i)*cx/8+1] = ~(checkedLongAt(cursorMaskIndex + (4 * i)) >> 16) & 0xFF;
         SqueakMousePointerXorMask[(31-i)*cx/8+0] = ((checkedLongAt(cursorMaskIndex + (4 * i)) >> 24)  ^
                                                    (checkedLongAt(cursorBitsIndex + (4 * i)) >> 24)) & 0xFF;
         SqueakMousePointerXorMask[(31-i)*cx/8+1] = ((checkedLongAt(cursorMaskIndex + (4 * i)) >> 16)  ^
                                                    (checkedLongAt(cursorBitsIndex + (4 * i)) >> 16)) & 0xFF;
      }
   }

   hbmOld = GpiSetBitmap(hps, hbm);
   if(hbmOld == HBM_ERROR) {
      ErrorCode = WinGetLastError(hab);
      sprintf(ErrorMessage, "GpiSetBitmap()\n" "Return Code: %d.", ErrorCode);
      ShowErrorMessage(ErrorMessage);
      return -1;
   }

   rc = GpiSetBitmapBits(hps, cy, cy, SqueakMousePointerAndMask, (BITMAPINFO2*)&bmih);
   if(rc==GPI_ALTERROR) {
      ErrorCode = WinGetLastError(hab);
      sprintf(ErrorMessage, "GpiSetBitmapBits()\n" "Return Code: %d.", ErrorCode);
      ShowErrorMessage(ErrorMessage);
      return -1;
   }
   rc = GpiSetBitmapBits(hps, 0, cy, SqueakMousePointerXorMask, (BITMAPINFO2*)&bmih);
   if(rc==GPI_ALTERROR) {
      ErrorCode = WinGetLastError(hab);
      sprintf(ErrorMessage, "GpiSetBitmapBits()\n" "Return Code: %d.", ErrorCode);
      ShowErrorMessage(ErrorMessage);
      return -1;
   }

   /* Create the new pointer */
   hptr = WinCreatePointer(HWND_DESKTOP, hbm, TRUE, -offsetX, cy+offsetY);
   if(!hptr) {
      ErrorCode = WinGetLastError(hab);
      sprintf(ErrorMessage, "WinCreatePointer()\n" "Return Code: %d.", ErrorCode);
      ShowErrorMessage(ErrorMessage);
      return -1;
   }
   /* Set the new pointer */
   rc = WinSetPointer(HWND_DESKTOP, hptr);
   if(!rc) {
      ErrorCode = WinGetLastError(hab);
      sprintf(ErrorMessage, "WinSetPointer()\n" "Return Code: %d.", ErrorCode);
      ShowErrorMessage(ErrorMessage);
      return -1;
   }
   return 0;
}

int ioShowDisplay(int dispBitsIndex, int width, int height, int depth,
                  int affectedL, int affectedR, int affectedT, int affectedB) {
   unsigned long ulScanLineBytes, ulScanLines;

   static int prevWidth=0, prevHeight=0, prevDepth=0;

   if(affectedR < affectedL || affectedT > affectedB)
      return 0;
   /*jmv This disables display update when Squeak is not the active window */
   if(hwndFrame != WinQueryActiveWindow(HWND_DESKTOP))
      return 0;

   /* This is for DIVE buffer to have the same size as Squeak screen */
   if (prevWidth != width || prevHeight != height || prevDepth != depth) {
      if(prevDepth) {
         ErrorCode = DiveFreeImageBuffer(DIVEHandle, DIVEBuffNum);
         if(ErrorCode) {
            sprintf(ErrorMessage, "DiveFreeImageBuffer()\n" "Return Code: %d.\n"
                    "Try starting Squeak with the NOVRAM option", ErrorCode);
            ErrorExit(ErrorMessage);
         }
         DIVEBuffNum = 0;
         if(NoVRAMBuffer) {  /* If we used a RAM DIVE Buffer, free it */
            free(NoVRAMBuffer);
            NoVRAMBuffer = 0;
         }
      }
      prevWidth = width;
      prevHeight = height;
      prevDepth = depth;
      switch(depth) {
         case 1: case 2: case 4: case 8:
            FccSrcColorFormat = FOURCC_LUT8; break;
         case 16:
            FccSrcColorFormat = FOURCC_R555; break;
         case 32:
            FccSrcColorFormat = FOURCC_BGR3; break;
         default:
            sprintf(ErrorMessage, "Not supported color format. Depth: %d.", depth);
            ErrorExit(ErrorMessage);
      }

      /* If we should not use VRAM DIVE Buffers */
      if(DoNotUseVRAMBuffer) {
         NoVRAMBuffer = malloc(((((width*depth-1) >> 5) + 1) << 2) * height);
         if(!NoVRAMBuffer) {
            sprintf(ErrorMessage, "Could not alloc OFF VRAM Video Buffer\n"
                    "Width: %d, Height: %d, Depth: %d.", width, height, depth);
            ErrorExit(ErrorMessage);
         }
      }
      ErrorCode = DiveAllocImageBuffer( DIVEHandle, &DIVEBuffNum, FccSrcColorFormat, width, height, 0, NoVRAMBuffer );
      if(ErrorCode) {
         sprintf(ErrorMessage, "DiveAllocImageBuffer()\n" "Return Code: %d.\n"
                 "Width: %d, Height: %d, Depth: %d.\n" "Try starting Squeak with the NOVRAM switch",
                 ErrorCode, width, height, depth);
         ErrorExit(ErrorMessage);
      }
   }

   ErrorCode = DiveBeginImageBufferAccess( DIVEHandle, DIVEBuffNum, (PBYTE*)&PtDIVESourceBuffer, &ulScanLineBytes, &ulScanLines );
   if (ErrorCode) {
      sprintf(ErrorMessage, "DiveBeginImageBufferAccess()\n" "Return Code: %d.\n", ErrorCode);
      ErrorExit(ErrorMessage);
   }

   /* Don't update anything outside DisplayScreen or outside the Squeak window */
   if (affectedR < 0) affectedR= 0;
   if (affectedB < 0) affectedB= 0;
   if (affectedL < 0) affectedL= 0;
   if (affectedT < 0) affectedT= 0;
   if (affectedR > width) affectedR= width;
   if (affectedB > height) affectedB= height;
   if (affectedL > width) affectedL= width;
   if (affectedT > height) affectedT= height;
   if (affectedR > WindowSizeX) affectedR = WindowSizeX;
   if (affectedB > WindowSizeY) affectedB = WindowSizeY;
   if (affectedL > WindowSizeX) affectedL = WindowSizeX;
   if (affectedT > WindowSizeY) affectedT = WindowSizeY;

   /* Tell DIVE about the new settings. */
   DIVEBlitterSetup.fccSrcColorFormat = FccSrcColorFormat;
   DIVEBlitterSetup.ulSrcWidth        = width;
   DIVEBlitterSetup.ulSrcHeight       = height;
   DIVEBlitterSetup.ulDstWidth        = width;
   DIVEBlitterSetup.ulDstHeight       = height;
   DIVEBlitterSetup.lScreenPosX       = ClientWindowPosition.x+FrameWindowPosition.x;
   DIVEBlitterSetup.lScreenPosY       = ClientWindowPosition.y+FrameWindowPosition.y+WindowSizeY-height;
   DIVEUpdateRect.xLeft = affectedL;
   DIVEUpdateRect.yBottom = height-affectedB;
   DIVEUpdateRect.xRight = affectedR;
   DIVEUpdateRect.yTop = height-affectedT;
   ErrorCode = DiveSetupBlitter (DIVEHandle, &DIVEBlitterSetup);
   if (ErrorCode) {
      sprintf(ErrorMessage, "DiveSetupBlitter()\n" "Return Code: %d.\n", ErrorCode);
      ErrorExit(ErrorMessage);
   }

   PtSqueakBuffer = (int*)dispBitsIndex;
   SqueakWidth = width;
   if (ulScanLineBytes != ((ulScanLineBytes>>2)<<2)) {
      sprintf(ErrorMessage, "ulScanLineBytes: %d\nPlease report this special case to jvuletic@dc.uba.ar", ulScanLineBytes);
      ErrorExit(ErrorMessage);
   }
   DIVEWidthInWords = ulScanLineBytes>>2;
   AffectedL = affectedL;
   AffectedR = affectedR;
   AffectedT = affectedT;
   AffectedB = affectedB;
   switch(depth) {
      case  1: CopyForDepth1(); break;
      case  2: CopyForDepth2(); break;
      case  4: CopyForDepth4(); break;
      case  8: CopyForDepth8(); break;
      case 16: CopyForDepth16(); break;
      case 32: CopyForDepth32(); break;
   }
   ErrorCode = DiveBlitImage (DIVEHandle, DIVEBuffNum, DIVE_BUFFER_SCREEN );
   if (ErrorCode) {
      sprintf(ErrorMessage, "DiveBlitImage()\n" "Return Code: %d.\n", ErrorCode);
      ErrorExit(ErrorMessage);
   }

   DiveEndImageBufferAccess (DIVEHandle, DIVEBuffNum);
   return 0;
}

int ioFormPrint(int bitsAddr, int width, int height, int depth,
                double hScale, double vScale, int landscapeFlag) {
   return true;
}

int ioForceDisplayUpdate(void) {
   WinUpdateWindow(hwndFrame);
   return 0;
}

int ioSetFullScreen(int fullScreen) {
   /* Not implemented yet (jmv!)*/
   return 0;
}

int ioSetDisplayMode(int width, int height, int depth, int fullscreenFlag) {
   /* Not implemented yet (jmv!)*/
   return 0;
}

int ioHasDisplayDepth(int depth) {
   /* Could be enhanced, actually asking DIVE for the required bit depth (jmv!) */
   if(depth == 1 || depth == 2 || depth == 4 || depth == 8 || depth == 16 || depth == 32)
      return 1;
   return 0;
}

/* Time & various */
int ioProcessEvents(void) {
   /* quick checks for asynchronous socket/sound i/o */
   if (socketPollFunction != 0)
      socketPollFunction(0, 0);
   while (WinPeekMsg (hab, &qmsg, 0, 0, 0, PM_REMOVE))        /* Start message loop */
      WinDispatchMsg (hab, &qmsg);
   return interruptPending;
}

int ioRelinquishProcessorForMicroseconds(int microSeconds) {
   /* sleep in select() for immediate response to socket i/o */
   if (socketPollFunction != 0)
      socketPollFunction(microSeconds, 0);
   DosSleep(microSeconds/1000);
   return microSeconds;
}

int ioMSecs(void) {
/*
   QWORD tmrTime;
   ULONG tmrFreq;
   ErrorCode = DosTmrQueryTime(&tmrTime);
   if (ErrorCode) {
      sprintf(ErrorMessage, "DosTmrQueryTime()\n" "Return Code: %d.\n", ErrorCode);
      ErrorExit(ErrorMessage);
   }
   ErrorCode = DosTmrQueryFreq(&tmrFreq);
   if (ErrorCode) {
      sprintf(ErrorMessage, "DosTmrQueryFreq()\n" "Return Code: %d.\n", ErrorCode);
      ErrorExit(ErrorMessage);
   }
En un subdirectorio hay un ejemplo de uso de esto. Verlo!. Estudiar su resolucion!
La resolucion de WinGetCurrentTime() es de SOLAMENTE 32mS!!! - chequearlo asi:

| a b |
Transcript clear.
a _ Time millisecondClockValue.
b _ Array new: 20.
1 to: b size do: [ :i |
   [ a = Time millisecondClockValue ] whileTrue: [].
   a _ Time millisecondClockValue.
   b at: i put: a ].
Transcript show: b printString.

*/
   return WinGetCurrentTime(hab) & 0x3FFFFFFF;
}

int ioLowResMSecs(void) {
   return WinGetCurrentTime(hab) & 0x3FFFFFFF;
}

int ioMicroMSecs(void) {
   // jmv Should be from hi-res clock
   return WinGetCurrentTime(hab) & 0x3FFFFFFF;
}

/* returns the local wall clock time */
int ioSeconds(void) {
    DATETIME     DateTime   = {0};
    int secs;
    int dy;
    static int nDaysPerMonth[14] = {
            0,  0,   31,  59,  90, 120, 151,
          181, 212, 243, 273, 304, 334, 365 };

    if(DosGetDateTime(&DateTime))
       return 0;

    /* Squeak epoch is Jan 1, 1901 */
    dy = DateTime.year - 1901; /* compute delta year */
    secs = dy * 365 * 24 * 60 * 60       /* base seconds */
           + (dy >> 2) * 24 * 60 * 60;   /* seconds of leap years */
    /* check if month > 2 and current year is a leap year */
    if(DateTime.month > 2 && (dy & 0x0003) == 0x0003)   /* compare with 0x0003 cause we substracted 1901! */
      secs += 24 * 60 * 60; /* add one day */
    /* add the days from the beginning of the year */
    secs += (nDaysPerMonth[DateTime.month] + DateTime.day - 1) * 24 * 60 * 60;
    /* add the hours, minutes, and seconds */
    secs +=  DateTime.seconds + 60*(DateTime.minutes + 60*DateTime.hours);
    return secs;
}

int ioBeep(void) {
   DosBeep(800, 100L);
   return 0;
}

int ioExit(void) {
   SilentExit(0);
   return 0;      // I don't like compiler warnings!
}

/* Clipboard */
int clipboardSize(void) {
   char *src;
   int len,tel;

   if(!WinOpenClipbrd(hab))
      return 0;
   len = 0;
   src = (char*)WinQueryClipbrdData(hab, CF_TEXT);
   if(src) {
      len = strlen(src);
      tel = len;
      while(tel--)
        if((*src++ == 0x0d) && (*src == 0x0a))
          len--;
   }
   WinCloseClipbrd(hab);
   return len;
}

/* Send the given string to the clipboard */
int clipboardWriteFromAt(int count, int byteArrayIndex, int startIndex) {
   char *dst,*src, *dst2;
   int adjCount, tel;

   if(!WinOpenClipbrd(hab))
      return -1;
   /* RvL 17-04-1998
      adjust count for inserting 0A into clipboard string */
   src = (unsigned char *)byteArrayIndex + startIndex;
   tel = count;
   adjCount = 0;
   while(tel--)
     if ((*src++ == 0x0D) && (*src != 0x0A))
       adjCount++;
   if(DosAllocSharedMem((void**)&dst, NULL, count+1+adjCount, PAG_WRITE | PAG_COMMIT | OBJ_GIVEABLE))
      return -1;
   src = (unsigned char *)byteArrayIndex + startIndex;
   dst2 = dst;
   while(count--)
      if((*src == 0x0D) && (src[1] != 0x0A)) {
         /* special case: crlf translation */
         *dst2++ = *src++;
         *dst2++ = 0x0A;
      } else {
         /* regular case: lookup translation */
         *dst2++ = iKeymap[*src++];
      }
   *dst2 = 0;
   WinEmptyClipbrd(hab);
   WinSetClipbrdData(hab, (unsigned long)dst, CF_TEXT, CFI_POINTER);
   WinCloseClipbrd(hab);
   return 0;
}

/* Transfer the clipboard data into the given byte array */
int clipboardReadIntoAt(int count, int byteArrayIndex, int startIndex) {
   char *src,*dst;
   int len;

   if(!WinOpenClipbrd(hab))
      return -1;
   dst = (char *)byteArrayIndex + startIndex;
   len = 0;
   src = (char*)WinQueryClipbrdData(hab, CF_TEXT);
   if(src) {
      len = strlen(src);
      if(len > count)
         len = count;
      while(len--)
         if((*src == 0x0D) && (src[1] == 0x0A)) {
            /* RvL 17-04-1998
               drop the line feed after a carriage return
               but leave lone line feeds alone
               may transfer less than 'len' bytes but who cares
               i.e. if they use the clipboardSize there should
               be no problem.*/
            *dst++ = *src++;
            src++;
         } else { /* regular case: lookup translation */
            *dst++ = keymap[*src++];
         }
   }
   WinCloseClipbrd(hab);
   return len;
}

/* Profile */
int clearProfile(void) { return 0;}
int dumpProfile(void) {return 0;}
int startProfiling(void) {return 0;}
int stopProfiling(void) {return 0;}

/***************************************************************************/
/* Function Definition                                                     */
/*          Support Function                                               */
/***************************************************************************/
void SilentExit(int returnCode) {
   /* DIVE */
   if(DIVEBuffNum) {
      DiveFreeImageBuffer(DIVEHandle, DIVEBuffNum);
      if(NoVRAMBuffer) {  /* If we used a RAM DIVE Buffer, free it */
         free(NoVRAMBuffer);
         NoVRAMBuffer = 0;
      }
   }
   if(DIVEHandle)
      DiveClose(DIVEHandle);
   /* Mouse Pointer */
   if (hptr)
      WinDestroyPointer(hptr);
   if(hbm)
      GpiDeleteBitmap(hbm);
   if(hps)
      GpiDestroyPS(hps);
   if(hdc)
      DevCloseDC(hdc);
   if(SqueakMousePointerAndMask)
      free(SqueakMousePointerAndMask);
   if(SqueakMousePointerXorMask)
      free(SqueakMousePointerXorMask);
   /* Palette */
   if(hpal)
      GpiDeletePalette(hpal);
   /* Main Window */
   if(hwndFrame != NULLHANDLE)
      if (WinIsWindow (hab, hwndFrame))
         WinDestroyWindow (hwndFrame);
   if(hmq != NULLHANDLE)
      WinDestroyMsgQueue (hmq);
   if(hab != NULLHANDLE)
      WinTerminate (hab);
   exit(returnCode);
}

void ErrorExit(char* ErrorMessage) {
   WinMessageBox (HWND_DESKTOP, hwndClient, ErrorMessage,
      "Squeak OS/2 Virtual Machine Error - Will exit Squeak without saving the image",
      0, MB_CANCEL | MB_ERROR | MB_MOVEABLE);
   SilentExit(1);
}

void ShowErrorMessage(char* ErrorMessage) {
   WinMessageBox (HWND_DESKTOP, hwndClient, ErrorMessage,
      "Squeak OS/2 Virtual Machine Error - Please exit Squeak as soon as possible",
      0, MB_OK | MB_ERROR | MB_MOVEABLE);
}

void ShowWarningMessage(char* ErrorMessage) {
   WinMessageBox (HWND_DESKTOP, hwndClient, ErrorMessage,
      "Squeak OS/2 Virtual Machine Warning - Some non-fatal error occured. Will not exit.",
      0, MB_OK | MB_ERROR | MB_MOVEABLE);
}

int printf(const char *fmt, ...) {
   va_list al;
   va_start(al, fmt);
   vsprintf(ErrorMessage, fmt, al);
   WinMessageBox (HWND_DESKTOP, hwndClient, ErrorMessage,
      "Squeak OS/2 Virtual Machine Error",
      0, MB_OK | MB_ERROR | MB_MOVEABLE);
   va_end(al);
   return 0;
}

/* display, mouse, keyboard, time i/o */
void recordMouseDown(void) {
  int stButtons= 0;

  if(WinGetKeyState(HWND_DESKTOP, VK_BUTTON1) & 0x8000) stButtons |= 4;
  if(WinGetKeyState(HWND_DESKTOP, VK_BUTTON3) & 0x8000) stButtons |= 1;
  if(WinGetKeyState(HWND_DESKTOP, VK_BUTTON2) & 0x8000) stButtons |= 2;

  if (stButtons == 4) {        /* red button (button1, left) honours the modifiers */
      if (WinGetKeyState(HWND_DESKTOP, VK_CTRL) & 0x8000)
        stButtons= 1;          /* blue (button3, middle) button if CTRL down */
      else if (WinGetKeyState(HWND_DESKTOP, VK_ALT) & 0x8000)
        stButtons= 2;          /* yellow (button2, right) button if ALT down */
  }
  buttonState = stButtons & 0x7;
}

void recordModifierButtons(void) {
   int modifiers=0;
   /* map shift to squeak shift bit */
   if(WinGetKeyState(HWND_DESKTOP, VK_SHIFT) & 0x8000)
      modifiers |= 1 << 3;
   /* Map Ctrl to Control */
   if((WinGetKeyState(HWND_DESKTOP, VK_CTRL) & 0x8000) && !(WinGetKeyState(HWND_DESKTOP, VK_ALT) & 0x8000))
      modifiers |= 1 << 4;
   /* Map Alt (the left one) to Command. */
   if((WinGetKeyState(HWND_DESKTOP, VK_ALT) & 0x8000) && !(WinGetKeyState(HWND_DESKTOP, VK_CTRL) & 0x8000))
      modifiers |= 1 << 6;
   /* Map Ctrl-Alt (the left one) to Option. */
   if((WinGetKeyState(HWND_DESKTOP, VK_CTRL) & 0x8000) && (WinGetKeyState(HWND_DESKTOP, VK_ALT) & 0x8000))
      modifiers |= 1 << 5;
   /* button state: low three bits are mouse buttons; next 4 bits are modifier bits */
   buttonState = modifiers | (buttonState & 0x7);
}

void recordVirtualKey(SHORT virtualKey) {
   int keystate = 0;

   switch (virtualKey) {
      case VK_BREAK:   /* Ctrl-Break emulates Esc */
      case VK_ESC:
         interruptPending= true;
         interruptCheckCounter= 0;
         break;

      case VK_END      : keystate = 4;  break;
      case VK_HOME     : keystate = 1;  break;
      case VK_LEFT     : keystate = 28; break;
      case VK_RIGHT    : keystate = 29; break;
      case VK_UP       : keystate = 30; break;
      case VK_DOWN     : keystate = 31; break;
      case VK_PAGEUP   : keystate = 11; break;
      case VK_PAGEDOWN : keystate = 12; break;

      /* Shift-Delete emulates Alt-x (Cut in Squeak) */
      case VK_DELETE:
         if(buttonState & (1 << 3)) {                /* Shift is down */
            buttonState = buttonState & (!(1<<3));   /* Reset Shift bit */
            keystate = 'x' | (1 << 11);              /* Sets Alt-x */
         } else
            keystate = 127;                 /* Sets Shift-Backspace */
         break;

      /* Shift-Insert emulates Alt-v (Paste in Squeak) */
      /* Ctrl-Insert emulates Alt-c (Copy in Squeak) */
      case VK_INSERT:
         if(buttonState & (1 << 3)) {                /* Shift is down */
            buttonState = buttonState & (!(1<<3));   /* Reset Shift bit */
            keystate = 'v' | (1 << 11);              /* Sets Alt-v */
         } else if(buttonState & (1 << 4)) {         /* Ctrl is down */
            buttonState = buttonState & (!(1<<4));   /* Reset Ctrl bit */
            keystate = 'c' | (1 << 11);              /* Sets Alt-c */
         } else {
//            keystate = 5;                          /* Win32 answers 5. I choose not to map the key! */
            return;
         }
         break;

      /* Not Mapped: VK_INSERT, VK_BACKTAB, VK_PAUSE, VK_SYSRQ, PRINTSCRN, VK_SCRLLOCK, VK_NUMLOCK. (jmv) */
      default: return;
   }
   keystate = keystate | ((buttonState >> 3) << 8);
   keyBuf[keyBufPut]= keystate;
   keyBufPut= (keyBufPut + 1) % KEYBUF_SIZE;
   if (keyBufGet == keyBufPut) {
      /* buffer overflow; drop the last character */
      keyBufGet= (keyBufGet + 1) % KEYBUF_SIZE;
      keyBufOverflows++;
   }
}

void recordKeystroke(SHORT characterCode) {
   int keystate=0;
   /* Map from OS/2 to Mac */
   keystate = keymap[characterCode];
   /* add the modifiers */
   keystate = keystate | ((buttonState >> 3) << 8);
   /* Add the key */
   keyBuf[keyBufPut]= keystate;
   keyBufPut= (keyBufPut + 1) % KEYBUF_SIZE;
   if (keyBufGet == keyBufPut) {
      /* buffer overflow; drop the last character */
      keyBufGet= (keyBufGet + 1) % KEYBUF_SIZE;
      keyBufOverflows++;
   }
}

/* Various setup */
void SetColorEntry(int index, int red, int green, int blue) {
   colorPalette[index].red = red>>8;
   colorPalette[index].green = green>>8;
   colorPalette[index].blue = blue>>8;
   colorPalette[index].flags = 0;
}

void SetUpPixmaps(void) {
   /* 1-bit colors (monochrome) */
   SetColorEntry(0, 65535, 65535, 65535);        /* white or transparent */
   SetColorEntry(1,     0,     0,     0);        /* black */

   /* additional colors for 2-bit color */
   SetColorEntry(2, 65535, 65535, 65535);        /* opaque white */
   SetColorEntry(3, 32768, 32768, 32768);        /* 1/2 gray */

   /* additional colors for 4-bit color */
   SetColorEntry( 4, 65535,     0,     0);        /* red */
   SetColorEntry( 5,     0, 65535,     0);        /* green */
   SetColorEntry( 6,     0,     0, 65535);        /* blue */
   SetColorEntry( 7,     0, 65535, 65535);        /* cyan */
   SetColorEntry( 8, 65535, 65535,     0);        /* yellow */
   SetColorEntry( 9, 65535,     0, 65535);        /* magenta */
   SetColorEntry(10,  8192,  8192,  8192);        /* 1/8 gray */
   SetColorEntry(11, 16384, 16384, 16384);        /* 2/8 gray */
   SetColorEntry(12, 24576, 24576, 24576);        /* 3/8 gray */
   SetColorEntry(13, 40959, 40959, 40959);        /* 5/8 gray */
   SetColorEntry(14, 49151, 49151, 49151);        /* 6/8 gray */
   SetColorEntry(15, 57343, 57343, 57343);        /* 7/8 gray */

   /* additional colors for 8-bit color */
   /* 24 more shades of gray (does not repeat 1/8th increments) */
   SetColorEntry(16,  2048,  2048,  2048);        /*  1/32 gray */
   SetColorEntry(17,  4096,  4096,  4096);        /*  2/32 gray */
   SetColorEntry(18,  6144,  6144,  6144);        /*  3/32 gray */
   SetColorEntry(19, 10240, 10240, 10240);        /*  5/32 gray */
   SetColorEntry(20, 12288, 12288, 12288);        /*  6/32 gray */
   SetColorEntry(21, 14336, 14336, 14336);        /*  7/32 gray */
   SetColorEntry(22, 18432, 18432, 18432);        /*  9/32 gray */
   SetColorEntry(23, 20480, 20480, 20480);        /* 10/32 gray */
   SetColorEntry(24, 22528, 22528, 22528);        /* 11/32 gray */
   SetColorEntry(25, 26624, 26624, 26624);        /* 13/32 gray */
   SetColorEntry(26, 28672, 28672, 28672);        /* 14/32 gray */
   SetColorEntry(27, 30720, 30720, 30720);        /* 15/32 gray */
   SetColorEntry(28, 34815, 34815, 34815);        /* 17/32 gray */
   SetColorEntry(29, 36863, 36863, 36863);        /* 18/32 gray */
   SetColorEntry(30, 38911, 38911, 38911);        /* 19/32 gray */
   SetColorEntry(31, 43007, 43007, 43007);        /* 21/32 gray */
   SetColorEntry(32, 45055, 45055, 45055);        /* 22/32 gray */
   SetColorEntry(33, 47103, 47103, 47103);        /* 23/32 gray */
   SetColorEntry(34, 51199, 51199, 51199);        /* 25/32 gray */
   SetColorEntry(35, 53247, 53247, 53247);        /* 26/32 gray */
   SetColorEntry(36, 55295, 55295, 55295);        /* 27/32 gray */
   SetColorEntry(37, 59391, 59391, 59391);        /* 29/32 gray */
   SetColorEntry(38, 61439, 61439, 61439);        /* 30/32 gray */
   SetColorEntry(39, 63487, 63487, 63487);        /* 31/32 gray */

   /* The remainder of color table defines a color cube with six steps
      for each primary color. Note that the corners of this cube repeat
      previous colors, but simplifies the mapping between RGB colors and
      color map indices. This color cube spans indices 40 through 255.
     */
   {
      int r, g, b;

      for (r= 0; r < 6; r++)
         for (g= 0; g < 6; g++)
            for (b= 0; b < 6; b++) {
               int i= 40 + ((36 * r) + (6 * b) + g);
               if (i > 255) error("index out of range in color table compuation");
               SetColorEntry(i, (r * 65535) / 5, (g * 65535) / 5, (b * 65535) / 5);
            }
   }

   hpal = GpiCreatePalette(hab, LCOL_PURECOLOR | LCOL_OVERRIDE_DEFAULT_COLORS,
                           LCOLF_CONSECRGB, 256, (unsigned long*)colorPalette);
   if ( !hpal ) {
      ErrorCode = WinGetLastError(hab);
      sprintf(ErrorMessage, "GpiCreatePalette()\n" "Return Code: %d.", ErrorCode);
      ShowErrorMessage(ErrorMessage);
      return;
   }

   ErrorCode = DiveSetSourcePalette(DIVEHandle, 0, 256, (unsigned char*)colorPalette);
   if(ErrorCode) {
      sprintf(ErrorMessage, "DiveSetSourcePalette()\n" "Return Code: %d.", ErrorCode);
      ShowErrorMessage(ErrorMessage);
      return;
   }
}

void SetupKeymap(void) {
  int i;
  for(i=0;i<256;i++)
    iKeymap[keymap[i]] = i;
}

void SetWindowSize(void) {
   int width, height, maxWidth, maxHeight;
   RECTL frameRect;
   if (savedWindowSize != 0) {
      width  = (unsigned) savedWindowSize >> 16;
      height = savedWindowSize & 0xFFFF;
   } else {
      width  = 640;
      height = 480;
   }
   /* Calc the necessary frame for the Squeak client area at the bottom left. */
   frameRect.xLeft = 0;
   frameRect.yBottom = 0;
   frameRect.xRight = width;
   frameRect.yTop = height;
   WinCalcFrameRect(hwndFrame, &frameRect, 0);
   WinSetWindowPos(hwndFrame, NULLHANDLE, frameRect.xLeft, frameRect.yBottom,
                   frameRect.xRight-frameRect.xLeft, frameRect.yTop-frameRect.yBottom,
                   SWP_SIZE | SWP_MOVE | SWP_ACTIVATE);
   /* Set DIVE Blitter data that wont change only once */
   DIVEBlitterSetup.ulStructLen       = sizeof( SETUP_BLITTER );
   DIVEBlitterSetup.ulSrcPosX         = 0;
   DIVEBlitterSetup.ulSrcPosY         = 0;
   DIVEBlitterSetup.fInvert           = FALSE;
   DIVEBlitterSetup.ulDitherType      = 1;
   DIVEBlitterSetup.fccDstColorFormat = FOURCC_SCRN;
   DIVEBlitterSetup.lDstPosX          = 0;
   DIVEBlitterSetup.lDstPosY          = 0;
   DIVEBlitterSetup.ulNumDstRects     = 1;
   DIVEBlitterSetup.pVisDstRects = &DIVEUpdateRect;
}

void setupFilesAndPath(void) {
  char *tmp;
  char tmpName[MAX_PATH+1];
  char currDir[MAX_PATH+1];
  unsigned long length = MAX_PATH;
  unsigned long disknum, logical;

  /* if imageName does not include the drive letter, add it */
  if(strchr(imageName,':')) {
     tmpName[0] = imageName[0];
     tmp = imageName+2;
  } else {
     DosQueryCurrentDisk(&disknum, &logical);
     tmpName[0] = (char)'A'-1+disknum;
     tmp = imageName;
  }
  tmpName[1] = '\0';
  strcat(tmpName, ":");

  /* if imageName does not include the full path from drive root, add it */
  if(!strchr(tmp,'\\')) {
     strcat(tmpName, "\\");
     DosQueryCurrentDir(0, currDir, &length);
     strcat(tmpName, currDir);
     strcat(tmpName,"\\");
  }
  strcat(tmpName, tmp);
  strcpy(imageName, tmpName);


  /* get the VM directory */
  strcpy(vmPath, vmName);
  *(strrchr(vmPath,'\\')+1) = '\0';
}

/* Squeak screen to DIVE buffer copy functions */
/* In all theese copy functions we assume that Squeak display lines are aligned
   to 32 bits words, and DIVE display lines too. Each one receives a Squeak format buffer
   and copies to a DIVE format buffer. Theese are time-critical functions. They should be
   as optimized as possible. That's why we keep a full screen DIVE source buffer, and just copy
   the portion that Squeak wants to display.  */
void CopyForDepth1(void) {
      unsigned bit;
      unsigned xSource, ySource, xSourceFrom, xSourceTo, ySourceFrom, ySourceTo;  /* all count 32 bit Words */
      unsigned xDest, yDest, yDestFrom, yDestTo;                                  /* all count 32 bit Words */
      union { int integer; char chars[4]; } sourceWord, destWord;
      int* ptSqueakBufferLine;
      int* ptDIVEBufferLine;
      int sourceWidthInWords = ((SqueakWidth-1) >>5) +1;

      xSourceFrom = AffectedL>>5;
      xSourceTo = ((AffectedR-1)>>5) +1;
      ySourceFrom = AffectedT*sourceWidthInWords;
      ySourceTo = AffectedB*sourceWidthInWords;

      yDestFrom = AffectedT*DIVEWidthInWords;
      yDestTo = AffectedB*DIVEWidthInWords;

      for(ySource=ySourceFrom, yDest=yDestFrom;  ySource<ySourceTo;  ySource+=sourceWidthInWords, yDest+=DIVEWidthInWords) {
         ptSqueakBufferLine = PtSqueakBuffer+ySource;
         ptDIVEBufferLine = PtDIVESourceBuffer+yDest;
         for(xSource=xSourceFrom;  xSource<xSourceTo;  xSource++) {
            for(bit=0; bit<32; bit++) {
               sourceWord.chars[3-(bit&3)] = (*(ptSqueakBufferLine+xSource)>>bit) & 1;
               if((bit & 3)==3) {
                  xDest = (xSource<<3)|(7-(bit>>2));
                  *(ptDIVEBufferLine+xDest) = sourceWord.integer;
               }
            }
         }
      }
}
void CopyForDepth2(void) {
      unsigned bit;
      unsigned xSource, ySource, xSourceFrom, xSourceTo, ySourceFrom, ySourceTo;  /* all count 32 bit Words */
      unsigned xDest, yDest, yDestFrom, yDestTo;                                  /* all count 32 bit Words */
      union { int integer; char chars[4]; } sourceWord, destWord;
      int* ptSqueakBufferLine;
      int* ptDIVEBufferLine;
      int sourceWidthInWords = ((SqueakWidth-1) >>4) +1;

      xSourceFrom = AffectedL>>4;
      xSourceTo = ((AffectedR-1)>>4) +1;
      ySourceFrom = AffectedT*sourceWidthInWords;
      ySourceTo = AffectedB*sourceWidthInWords;

      yDestFrom = AffectedT*DIVEWidthInWords;
      yDestTo = AffectedB*DIVEWidthInWords;

      for(ySource=ySourceFrom, yDest=yDestFrom;  ySource<ySourceTo;  ySource+=sourceWidthInWords, yDest+=DIVEWidthInWords) {
         ptSqueakBufferLine = PtSqueakBuffer+ySource;
         ptDIVEBufferLine = PtDIVESourceBuffer+yDest;
         for(xSource=xSourceFrom;  xSource<xSourceTo;  xSource++) {
            for(bit=0; bit<16; bit++) {
               sourceWord.chars[3-(bit&3)] = (*(ptSqueakBufferLine+xSource)>>(bit*2)) & 3;
               if((bit & 3)==3) {
                  xDest = (xSource<<2)|(3-(bit>>2));
                  *(ptDIVEBufferLine+xDest) = sourceWord.integer;
               }
            }
         }
      }
}
void CopyForDepth4(void) {
      unsigned bit;
      unsigned xSource, ySource, xSourceFrom, xSourceTo, ySourceFrom, ySourceTo;  /* all count 32 bit Words */
      unsigned xDest, yDest, yDestFrom, yDestTo;                                  /* all count 32 bit Words */
      union { int integer; char chars[4]; } sourceWord, destWord;
      int* ptSqueakBufferLine;
      int* ptDIVEBufferLine;
      int sourceWidthInWords = ((SqueakWidth-1) >>3) +1;

      xSourceFrom = AffectedL>>3;
      xSourceTo = ((AffectedR-1)>>3) +1;
      ySourceFrom = AffectedT*sourceWidthInWords;
      ySourceTo = AffectedB*sourceWidthInWords;

      yDestFrom = AffectedT*DIVEWidthInWords;
      yDestTo = AffectedB*DIVEWidthInWords;

      for(ySource=ySourceFrom, yDest=yDestFrom;  ySource<ySourceTo;  ySource+=sourceWidthInWords, yDest+=DIVEWidthInWords) {
         ptSqueakBufferLine = PtSqueakBuffer+ySource;
         ptDIVEBufferLine = PtDIVESourceBuffer+yDest;
         for(xSource=xSourceFrom;  xSource<xSourceTo;  xSource++) {
            for(bit=0; bit<8; bit++) {
               sourceWord.chars[3-(bit & 3)] = (*(ptSqueakBufferLine+xSource)>>(bit*4)) & 15;
               if((bit & 3)==3) {
                  xDest = (xSource<<1)|(1-(bit>>2));
                  *(ptDIVEBufferLine+xDest) = sourceWord.integer;
               }
            }
         }
      }
}
void CopyForDepth8(void) {
      unsigned x, ySource, xSourceFrom, xSourceTo, ySourceFrom, ySourceTo;  /* all count 32 bit Words */
      unsigned yDest, yDestFrom, yDestTo;                                   /* all count 32 bit Words */
      union { int integer; char chars[4]; } sourceWord, destWord;
      int* ptSqueakBufferLine;
      int* ptDIVEBufferLine;
      int sourceWidthInWords = ((SqueakWidth-1) >>2) +1;

      xSourceFrom = AffectedL>>2;
      xSourceTo = ((AffectedR-1)>>2) +1;
      ySourceFrom = AffectedT*sourceWidthInWords;
      ySourceTo = AffectedB*sourceWidthInWords;

      yDestFrom = AffectedT*DIVEWidthInWords;
      yDestTo = AffectedB*DIVEWidthInWords;

      for(ySource=ySourceFrom, yDest=yDestFrom;  ySource<ySourceTo;  ySource+=sourceWidthInWords, yDest+=DIVEWidthInWords) {
         ptSqueakBufferLine = PtSqueakBuffer+ySource;
         ptDIVEBufferLine = PtDIVESourceBuffer+yDest;
         for(x=xSourceFrom;  x<xSourceTo;  x++) {
            sourceWord.integer = *(ptSqueakBufferLine+x);
            destWord.chars[0] = sourceWord.chars[3];
            destWord.chars[1] = sourceWord.chars[2];
            destWord.chars[2] = sourceWord.chars[1];
            destWord.chars[3] = sourceWord.chars[0];
            *(ptDIVEBufferLine+x) = destWord.integer;
         }
      }
}
void CopyForDepth16(void) {
      unsigned x, ySource, xSourceFrom, xSourceTo, ySourceFrom, ySourceTo;  /* all count 32 bit Words */
      unsigned yDest, yDestFrom, yDestTo;                                   /* all count 32 bit Words */
      union { int integer; char chars[4]; } sourceWord, destWord;
      int* ptSqueakBufferLine;
      int* ptDIVEBufferLine;
      int sourceWidthInWords = ((SqueakWidth-1) >>1) +1;

      xSourceFrom = AffectedL>>1;
      xSourceTo = ((AffectedR-1)>>1) +1;
      ySourceFrom = AffectedT*sourceWidthInWords;
      ySourceTo = AffectedB*sourceWidthInWords;

      yDestFrom = AffectedT*DIVEWidthInWords;
      yDestTo = AffectedB*DIVEWidthInWords;

      for(ySource=ySourceFrom, yDest=yDestFrom;  ySource<ySourceTo;  ySource+=sourceWidthInWords, yDest+=DIVEWidthInWords) {
         ptSqueakBufferLine = PtSqueakBuffer+ySource;
         ptDIVEBufferLine = PtDIVESourceBuffer+yDest;
         for(x=xSourceFrom;  x<xSourceTo;  x++) {
            sourceWord.integer = *(ptSqueakBufferLine+x);
            destWord.chars[0] = sourceWord.chars[2];
            destWord.chars[1] = sourceWord.chars[3];
            destWord.chars[2] = sourceWord.chars[0];
            destWord.chars[3] = sourceWord.chars[1];
            *(ptDIVEBufferLine+x) = destWord.integer;
         }
      }
}
void CopyForDepth32(void) {
      unsigned xSource, ySource, xSourceFrom, xSourceTo, ySourceFrom, ySourceTo;  /* all count 32 bit Words */
      unsigned xDest, yDest, yDestFrom, yDestTo;                                  /* all count 32 bit Words */
      union { int integer; char chars[4]; } sourceWord, destWord;
      int* ptSqueakBufferLine;
      int* ptDIVEBufferLine;
      int sourceWidthInWords = SqueakWidth;

      xSourceFrom = AffectedL;
      xSourceTo = AffectedR;
      ySourceFrom = AffectedT*sourceWidthInWords;
      ySourceTo = AffectedB*sourceWidthInWords;

      yDestFrom = AffectedT*DIVEWidthInWords;
      yDestTo = AffectedB*DIVEWidthInWords;

      for(ySource=ySourceFrom, yDest=yDestFrom;  ySource<ySourceTo;  ySource+=sourceWidthInWords, yDest+=DIVEWidthInWords) {
         ptSqueakBufferLine = PtSqueakBuffer+ySource;
         ptDIVEBufferLine = PtDIVESourceBuffer+yDest;
         for(xSource=xSourceFrom;  xSource<xSourceTo;  xSource++) {
            xDest = (xSource>>2)*3;
            sourceWord.integer = *(ptSqueakBufferLine+xSource);
            switch(xSource & 3) {
               case 0:
                  destWord.integer = *(ptDIVEBufferLine+xDest);
                  destWord.chars[0] = sourceWord.chars[0];
                  destWord.chars[1] = sourceWord.chars[1];
                  destWord.chars[2] = sourceWord.chars[2];
                  *(ptDIVEBufferLine+xDest) = destWord.integer;
                  break;
               case 1:
                  destWord.integer = *(ptDIVEBufferLine+xDest);
                  destWord.chars[3] = sourceWord.chars[0];
                  *(ptDIVEBufferLine+xDest) = destWord.integer;
                  destWord.integer = *(ptDIVEBufferLine+xDest+1);
                  destWord.chars[0] = sourceWord.chars[1];
                  destWord.chars[1] = sourceWord.chars[2];
                  *(ptDIVEBufferLine+xDest+1) = destWord.integer;
                  break;
               case 2:
                  destWord.integer = *(ptDIVEBufferLine+xDest+1);
                  destWord.chars[2] = sourceWord.chars[0];
                  destWord.chars[3] = sourceWord.chars[1];
                  *(ptDIVEBufferLine+xDest+1) = destWord.integer;
                  destWord.integer = *(ptDIVEBufferLine+xDest+2);
                  destWord.chars[0] = sourceWord.chars[2];
                  *(ptDIVEBufferLine+xDest+2) = destWord.integer;
                  break;
               case 3:
                  destWord.integer = *(ptDIVEBufferLine+xDest+2);
                  destWord.chars[1] = sourceWord.chars[0];
                  destWord.chars[2] = sourceWord.chars[1];
                  destWord.chars[3] = sourceWord.chars[2];
                  *(ptDIVEBufferLine+xDest+2) = destWord.integer;
                  break;
            }
         }
      }
}

/***************************************************************************/
/* Function Definition                                                     */
/*          main() and windowProcedure()                                   */
/***************************************************************************/
int main(int argc, char * argv[]) {
   /* Handler for OS/2 exceptions */
   //EXCEPTIONREGISTRATIONRECORD xcpthand = { 0, &sqOS2ExceptionHandler };
   /* Window creation flags  */
   ULONG flCreateFlags = FCF_TITLEBAR | FCF_SYSMENU | FCF_SIZEBORDER | FCF_MINMAX | FCF_TASKLIST;
   TID   tidOpen;                              /* Thread ID of thread to handle file open */
   char  szWinTitle[100] = "Squeak - ";             /* String to hold window title jmv 100! */
   int virtualMemory = 0;
   FILE *f;
   long imageSize;
   int i;

   /* initialization */
   strcpy(vmName, argv[0]);     /* Fully qualified Squeak.EXE file (with disk and path) */
   if (argc >= 2)
      strcpy(imageName, argv[1]);  /* Fully qualified image file (with disk and path) if from Drag & Drop */
   else
      strcpy(imageName, "Squeak.image"); /* if no image name given , will try with Squeak.image and Squeak.changes */
   setupFilesAndPath();
   strcpy(documentName, "");
   strcat(szWinTitle, imageName);
   sqFileInit();

   /* Standard PM window creation */
   hab = WinInitialize (0);
   hmq = WinCreateMsgQueue (hab, 0);
   if (!WinRegisterClass (hab, WIN_CLASS_NAME, fnClientWndProc, CS_SIZEREDRAW | CS_MOVENOTIFY, 0))
      ErrorExit("Could not register Main Window");
   if (!(hwndFrame = WinCreateStdWindow (HWND_DESKTOP, WS_VISIBLE, &flCreateFlags,
         WIN_CLASS_NAME, szWinTitle, 0, NULLHANDLE, 0, &hwndClient)))
      ErrorExit("Could not create Main Window");

   /* Other command line arguments */
   for(i=1; i < argc; i++) {
      if(!stricmp(argv[i], "NOVRAM")) {
         DoNotUseVRAMBuffer = 1;
      } else if(!strnicmp(argv[i], "RAM:", 4)) {
         virtualMemory = atoi(argv[i]+4) << 20;
      }
   }

   /* Load the image */
   f = fopen(imageName, "rb");
   if (f == NULL) {
      sprintf(ErrorMessage, "Could not open the Squeak image file '%s'\n"
                            "Drop a valid image file on Squeak.exe, or use the following syntax:\n"
                            "Squeak <imageFile.image> <RAM:xxxx> <NOVRAM>\n"
                            "Defaults are Squeak.image, 3 times the size of the image, and use VRAM\n"
                            "<> indicate optional paramenter. RAM size is in decimal and in Mb", imageName);
      ErrorExit(ErrorMessage);
   }
   fseek(f, 0, SEEK_END);
   imageSize = ftell(f);
   fseek(f, 0, SEEK_SET);
   if(virtualMemory)
      virtualMemory += (int)imageSize;
   else
      virtualMemory = (int)imageSize + max(imageSize, 0x00400000) * 2;
   readImageFromFileHeapSize(f, virtualMemory);
   fclose(f);

   /* position, size and display the main window */
   SetWindowSize();

   /* Get an instance of DIVE APIs.    */
   if(DiveOpen(&DIVEHandle, FALSE, 0))    {
     ErrorExit("DIVE support couldn't be opened\n" "Install DIVE DLLs before using Squeak");
   }

   /* Complet setup */
   SetupKeymap();
   SetUpPixmaps();
   //DosSetExceptionHandler(&xcpthand);
   _control87(EM_UNDERFLOW, EM_UNDERFLOW); // Never raise floating point underflow exceptions, just answer zero
   _control87(EM_OVERFLOW, EM_OVERFLOW);   // Never raise floating point underflow exceptions, just answer infinity
   _control87(EM_INVALID, EM_INVALID);     // Never raise floating point invalid operation exceptions, just answer NaN

   /* Run Squeak */
   interpret();

   /* Exit Squeak */
   SilentExit(0);
   //DosUnsetExceptionHandler(&xcpthand); /* jmv May be it should be in SilentExit! */
   return 0;
}

/* Client window procedure - OS/2 Events handler */
MRESULT EXPENTRY fnClientWndProc(HWND hwnd, ULONG msg, MPARAM mp1, MPARAM mp2) {
   MRESULT mr = (MRESULT) FALSE;
   USHORT fsKeyFlags;

   switch (msg) {

       case WM_MOVE: {
          WinQueryWindowPos (hwndClient, &ClientWindowPosition);
          WinQueryWindowPos (hwndFrame, &FrameWindowPosition);
          break;
       }

       case WM_SIZE: {
          WindowSizeX = SHORT1FROMMP(mp2);
          WindowSizeY = SHORT2FROMMP(mp2);
          break;
       }

       case WM_PAINT: {
           RECTL updateWindowRect;
           HPS hps;
           /* Retrieve instance data */
           hps = WinBeginPaint (hwnd, NULLHANDLE, &updateWindowRect);
           WinFillRect(hps, &updateWindowRect, CLR_BACKGROUND);
           /* force redraw the next time ioShowDisplay() is called */
           fullDisplayUpdate();  /* this makes VM call ioShowDisplay */
           WinEndPaint (hps);
           break;
       }

       case WM_CLOSE: {
         HAB   hab;
         hab = WinQueryAnchorBlock(hwnd);
         if (WinMessageBox (HWND_DESKTOP, hwnd, "Exit Squeak without saving the image?",
                           "Squeak", 0,
                           MB_YESNO | MB_ICONQUESTION | MB_MOVEABLE) == MBID_YES) {
             WinPostMsg (hwnd, WM_QUIT, 0, 0);
          }
          break;
       }

       case WM_QUIT: {
           SilentExit(0);
           break;
       }

       /*  mousing */
       case WM_MOUSEMOVE:
          mousePosition.x = SHORT1FROMMP(mp1);
          mousePosition.y = SHORT2FROMMP(mp1);
          /* The IBM docs say this is very fast if settig the same again
             so it's not necessary to test if the pointer changed        */
          if (hptr)
             WinSetPointer(HWND_DESKTOP, hptr);
          break;

       case WM_BUTTON1DOWN:
       case WM_BUTTON2DOWN:
       case WM_BUTTON3DOWN:
       case WM_BUTTON1UP:
       case WM_BUTTON2UP:
       case WM_BUTTON3UP:
       case WM_BUTTON1DBLCLK:
          WinSetActiveWindow(HWND_DESKTOP, hwnd);
          recordMouseDown();
          recordModifierButtons();
          break;

       case WM_CHAR:
          fsKeyFlags = (USHORT) SHORT1FROMMP(mp1);
          recordModifierButtons();
          /* Only if its a key down event */
          if(!(fsKeyFlags & KC_KEYUP)) {

             /* Normal characters are not KC_VIRTUALKEY */
             /* Enter, Space, Backspace, numeric keypad are KC_VIRTUALKEY */
             if((fsKeyFlags & KC_CHAR)) {
                if(!(fsKeyFlags & KC_DEADKEY))
                   recordKeystroke(SHORT1FROMMP(mp2));

             /* Break, Esc, Home, End, arrow keys, delete, sh-del, sh-ins,
                ctrl-ins, and Alt-Keypad are not KC_CHAR but are KC_VIRTUALKEY*/
             } else if((fsKeyFlags & KC_VIRTUALKEY)) {
                /* Filter Alt-Keypad (We are entering and ASCII code) */
                if( !( (fsKeyFlags & KC_ALT) &&
                       (CHAR4FROMMP(mp1)==71 || CHAR4FROMMP(mp1)==72 ||
                        CHAR4FROMMP(mp1)==73 || CHAR4FROMMP(mp1)==75 ||
                        CHAR4FROMMP(mp1)==77 || CHAR4FROMMP(mp1)==79 ||
                        CHAR4FROMMP(mp1)==80 || CHAR4FROMMP(mp1)==81 ||
                        CHAR4FROMMP(mp1)==82)                            ) )
                recordVirtualKey(SHORT2FROMMP(mp2));

             /* Ctrl and/or Alt with any key does not return KC_CHAR, but has
                a valid SHORT1FROMMP(mp2) for the key pressed */
             } else {
                if((fsKeyFlags & KC_CTRL) || (fsKeyFlags & KC_ALT)) {
                   if(!(fsKeyFlags & KC_DEADKEY))
                      recordKeystroke(SHORT1FROMMP(mp2));
                }
             }

          }
          break;

       default:
          mr = WinDefWindowProc (hwnd, msg, mp1, mp2);
          break;
   }   /* Endswitch msg */

   return mr;
}   /* End of function */

ULONG _System sqOS2ExceptionHandler(PEXCEPTIONREPORTRECORD pERepRec,
                            PEXCEPTIONREGISTRATIONRECORD pERegRec,
                            PCONTEXTRECORD pCtxRec,
                            PVOID p) {
   ULONG   ulWritten,
           ulMemSize,
           flMemAttrs;

   APIRET  ulrc;

   /* Not currently used. But who knows... */

   /* If an overflow, warn the user the first time */
   /*
   if (pERepRec->ExceptionNum == XCPT_FLOAT_OVERFLOW) {
      sprintf(ErrorMessage, "A Floating Point Overflow exception occured.\n"
                            "Will answer INFINITY this and any future time until you exit Squeak.");
      ShowErrorMessage(ErrorMessage);
      _clear87();
      _control87(EM_OVERFLOW, EM_OVERFLOW);
      return (XCPT_CONTINUE_EXECUTION);
   }*/

   return (XCPT_CONTINUE_SEARCH);
}
