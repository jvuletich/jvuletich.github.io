/* This is an automatically generated table of all named primitive in the VM */

/* Function prototypes */
int primitiveDisablePowerManager(void);
int moduleUnloaded(void);
int BitBltPlugin_primitiveDrawLoop(void);
int BitBltPlugin_initialiseModule(void);
int BitBltPlugin_copyBitsFromtoat(void);
int BitBltPlugin_loadBitBltFrom(void);
int BitBltPlugin_primitiveWarpBits(void);
int BitBltPlugin_copyBits(void);
int BitBltPlugin_primitiveScanCharacters(void);
int BitBltPlugin_getModuleName(void);
int BitBltPlugin_primitiveCopyBits(void);
int BitBltPlugin_primitiveDisplayString(void);
int BitBltPlugin_setInterpreter(void);
int B2DPlugin_primitiveSetColorTransform(void);
int B2DPlugin_primitiveDisplaySpanBuffer(void);
int B2DPlugin_primitiveSetBitBltPlugin(void);
int B2DPlugin_primitiveSetEdgeTransform(void);
int B2DPlugin_primitiveNextFillEntry(void);
int B2DPlugin_primitiveAddActiveEdgeEntry(void);
int B2DPlugin_primitiveRenderImage(void);
int B2DPlugin_primitiveInitializeProcessing(void);
int B2DPlugin_primitiveAddBitmapFill(void);
int B2DPlugin_primitiveNextActiveEdgeEntry(void);
int B2DPlugin_primitiveAddRect(void);
int B2DPlugin_primitiveChangedActiveEdgeEntry(void);
int B2DPlugin_primitiveSetAALevel(void);
int B2DPlugin_primitiveFinishedProcessing(void);
int B2DPlugin_primitiveGetOffset(void);
int B2DPlugin_primitiveSetDepth(void);
int B2DPlugin_primitiveAddBezier(void);
int B2DPlugin_primitiveGetCounts(void);
int B2DPlugin_primitiveGetTimes(void);
int B2DPlugin_primitiveNeedsFlushPut(void);
int B2DPlugin_primitiveGetFailureReason(void);
int B2DPlugin_primitiveGetDepth(void);
int B2DPlugin_primitiveGetAALevel(void);
int B2DPlugin_primitiveGetBezierStats(void);
int B2DPlugin_primitiveAbortProcessing(void);
int B2DPlugin_primitiveAddPolygon(void);
int B2DPlugin_primitiveAddGradientFill(void);
int B2DPlugin_primitiveSetOffset(void);
int B2DPlugin_initialiseModule(void);
int B2DPlugin_primitiveMergeFillFrom(void);
int B2DPlugin_primitiveAddLine(void);
int B2DPlugin_getModuleName(void);
int B2DPlugin_setInterpreter(void);
int B2DPlugin_primitiveSetClipRect(void);
int B2DPlugin_primitiveDoProfileStats(void);
int B2DPlugin_primitiveInitializeBuffer(void);
int B2DPlugin_primitiveRegisterExternalEdge(void);
int B2DPlugin_primitiveGetClipRect(void);
int B2DPlugin_primitiveRegisterExternalFill(void);
int B2DPlugin_primitiveAddOval(void);
int B2DPlugin_primitiveNeedsFlush(void);
int B2DPlugin_primitiveAddCompressedShape(void);
int B2DPlugin_primitiveNextGlobalEdgeEntry(void);
int B2DPlugin_primitiveCopyBuffer(void);
int B2DPlugin_primitiveAddBezierShape(void);
int B2DPlugin_moduleUnloaded(void);
int B2DPlugin_primitiveRenderScanline(void);
int SurfacePlugin_ioGetSurfaceFormat(void);
int SurfacePlugin_initialiseModule(void);
int SurfacePlugin_shutdownModule(void);
int SurfacePlugin_ioLockSurface(void);
int SurfacePlugin_ioUnlockSurface(void);
int SurfacePlugin_ioUnregisterSurface(void);
int SurfacePlugin_ioRegisterSurface(void);
int SurfacePlugin_ioFindSurface(void);
int SurfacePlugin_ioShowSurface(void);
int SurfacePlugin_getModuleName(void);
int SurfacePlugin_setInterpreter(void);
int FilePlugin_initialiseModule(void);
int FilePlugin_primitiveFileGetPosition(void);
int FilePlugin_primitiveDirectoryCreate(void);
int FilePlugin_primitiveDirectoryDelimitor(void);
int FilePlugin_getModuleName(void);
int FilePlugin_primitiveDirectorySetMacTypeAndCreator(void);
int FilePlugin_primitiveFileDelete(void);
int FilePlugin_primitiveFileSetPosition(void);
int FilePlugin_primitiveDirectoryDelete(void);
int FilePlugin_primitiveDirectoryLookup(void);
int FilePlugin_primitiveFileAtEnd(void);
int FilePlugin_setInterpreter(void);
int FilePlugin_primitiveFileClose(void);
int FilePlugin_primitiveFileSize(void);
int FilePlugin_primitiveFileRename(void);
int FilePlugin_shutdownModule(void);
int FilePlugin_primitiveFileOpen(void);
int FilePlugin_primitiveDirectoryGetMacTypeAndCreator(void);
int FilePlugin_setMacFileTypeAndCreator(void);
int FilePlugin_primitiveFileWrite(void);
int FilePlugin_primitiveFileRead(void);
int SocketPlugin_primitiveResolverAbortLookup(void);
int SocketPlugin_primitiveSocketAccept3Semaphores(void);
int SocketPlugin_primitiveInitializeNetwork(void);
int SocketPlugin_primitiveResolverAddressLookupResult(void);
int SocketPlugin_primitiveSocketConnectionStatus(void);
int SocketPlugin_primitiveSocketRemotePort(void);
int SocketPlugin_primitiveSocketSendDataBufCount(void);
int SocketPlugin_primitiveResolverNameLookupResult(void);
int SocketPlugin_primitiveSocketListenWithOrWithoutBacklog(void);
int SocketPlugin_primitiveSocketDestroy(void);
int SocketPlugin_primitiveSocketReceiveDataBufCount(void);
int SocketPlugin_primitiveSocketAbortConnection(void);
int SocketPlugin_primitiveSocketListenOnPort(void);
int SocketPlugin_primitiveSocketError(void);
int SocketPlugin_primitiveSocketLocalPort(void);
int SocketPlugin_primitiveSocketReceiveUDPDataBufCount(void);
int SocketPlugin_primitiveSocketCreate3Semaphores(void);
int SocketPlugin_primitiveSocketCreate(void);
int SocketPlugin_primitiveSocketRemoteAddress(void);
int SocketPlugin_primitiveSocketSetOptions(void);
int SocketPlugin_primitiveResolverStatus(void);
int SocketPlugin_primitiveResolverStartNameLookup(void);
int SocketPlugin_primitiveSocketSendUDPDataBufCount(void);
int SocketPlugin_initialiseModule(void);
int SocketPlugin_primitiveResolverError(void);
int SocketPlugin_primitiveSocketGetOptions(void);
int SocketPlugin_getModuleName(void);
int SocketPlugin_primitiveResolverLocalAddress(void);
int SocketPlugin_setInterpreter(void);
int SocketPlugin_primitiveSocketReceiveDataAvailable(void);
int SocketPlugin_primitiveResolverStartAddressLookup(void);
int SocketPlugin_primitiveSocketSendDone(void);
int SocketPlugin_primitiveSocketConnectToPort(void);
int SocketPlugin_shutdownModule(void);
int SocketPlugin_primitiveSocketLocalAddress(void);
int SocketPlugin_primitiveSocketListenOnPortBacklog(void);
int SocketPlugin_primitiveSocketAccept(void);
int SocketPlugin_primitiveSocketCloseConnection(void);
int MIDIPlugin_primitiveMIDIGetPortDirectionality(void);
int MIDIPlugin_primitiveMIDIParameterGetOrSet(void);
int MIDIPlugin_primitiveMIDIWrite(void);
int MIDIPlugin_primitiveMIDIClosePort(void);
int MIDIPlugin_primitiveMIDIRead(void);
int MIDIPlugin_primitiveMIDIParameterSet(void);
int MIDIPlugin_primitiveMIDIGetPortName(void);
int MIDIPlugin_shutdownModule(void);
int MIDIPlugin_primitiveMIDIOpenPort(void);
int MIDIPlugin_primitiveMIDIGetClock(void);
int MIDIPlugin_initialiseModule(void);
int MIDIPlugin_primitiveMIDIGetPortCount(void);
int MIDIPlugin_getModuleName(void);
int MIDIPlugin_primitiveMIDIParameterGet(void);
int MIDIPlugin_setInterpreter(void);
int SerialPlugin_setInterpreter(void);
int SerialPlugin_primitiveSerialPortRead(void);
int SerialPlugin_primitiveSerialPortClose(void);
int SerialPlugin_primitiveSerialPortWrite(void);
int SerialPlugin_getModuleName(void);
int SerialPlugin_primitiveSerialPortOpen(void);
int SerialPlugin_initialiseModule(void);
int SerialPlugin_shutdownModule(void);
int JoystickTabletPlugin_shutdownModule(void);
int JoystickTabletPlugin_initialiseModule(void);
int JoystickTabletPlugin_primitiveReadJoystick(void);
int JoystickTabletPlugin_primitiveReadTablet(void);
int JoystickTabletPlugin_getModuleName(void);
int JoystickTabletPlugin_primitiveGetTabletParameters(void);
int JoystickTabletPlugin_setInterpreter(void);
int AsynchFilePlugin_primitiveAsyncFileReadResult(void);
int AsynchFilePlugin_primitiveAsyncFileWriteStart(void);
int AsynchFilePlugin_primitiveAsyncFileOpen(void);
int AsynchFilePlugin_initialiseModule(void);
int AsynchFilePlugin_primitiveAsyncFileClose(void);
int AsynchFilePlugin_shutdownModule(void);
int AsynchFilePlugin_primitiveAsyncFileWriteResult(void);
int AsynchFilePlugin_getModuleName(void);
int AsynchFilePlugin_primitiveAsyncFileReadStart(void);
int AsynchFilePlugin_setInterpreter(void);
int SoundPlugin_primitiveSoundAvailableSpace(void);
int SoundPlugin_primitiveSoundStartWithSemaphore(void);
int SoundPlugin_primitiveSoundStopRecording(void);
int SoundPlugin_primitiveSoundSetRecordLevel(void);
int SoundPlugin_primitiveSoundGetRecordingSampleRate(void);
int SoundPlugin_primitiveSoundSetLeftVolume(void);
int SoundPlugin_primitiveSoundPlaySamples(void);
int SoundPlugin_primitiveSoundInsertSamples(void);
int SoundPlugin_initialiseModule(void);
int SoundPlugin_shutdownModule(void);
int SoundPlugin_primitiveSoundStop(void);
int SoundPlugin_primitiveSoundStartRecording(void);
int SoundPlugin_primitiveSoundRecordSamples(void);
int SoundPlugin_primitiveSoundPlaySilence(void);
int SoundPlugin_primitiveSoundStart(void);
int SoundPlugin_primitiveSoundGetVolume(void);
int SoundPlugin_getModuleName(void);
int SoundPlugin_setInterpreter(void);
int SoundGenerationPlugin_primitiveSampledSoundMix(void);
int SoundGenerationPlugin_primitiveFMSoundMix(void);
int SoundGenerationPlugin_primitivePluckedSoundMix(void);
int SoundGenerationPlugin_primitiveMixSampledSound(void);
int SoundGenerationPlugin_primitiveApplyReverb(void);
int SoundGenerationPlugin_primitiveMixFMSound(void);
int SoundGenerationPlugin_primitiveMixLoopedSampledSound(void);
int SoundGenerationPlugin_primitiveWaveTableSoundMix(void);
int SoundGenerationPlugin_primitiveMixPluckedSound(void);
int SoundGenerationPlugin_primitiveOldSampledSoundMix(void);
int SoundGenerationPlugin_getModuleName(void);
int SoundGenerationPlugin_setInterpreter(void);
int ADPCMCodecPlugin_primitiveDecodeStereo(void);
int ADPCMCodecPlugin_primitiveDecodeMono(void);
int ADPCMCodecPlugin_primitiveEncodeStereo(void);
int ADPCMCodecPlugin_getModuleName(void);
int ADPCMCodecPlugin_primitiveEncodeMono(void);
int ADPCMCodecPlugin_setInterpreter(void);
int Klatt_getModuleName(void);
int Klatt_primitiveSynthesizeFrameIntoStartingAt(void);
int Klatt_setInterpreter(void);
int SoundCodecPrims_primitiveGSMNewState(void);
int SoundCodecPrims_primitiveGSMEncode(void);
int SoundCodecPrims_getModuleName(void);
int SoundCodecPrims_primitiveGSMDecode(void);
int SoundCodecPrims_setInterpreter(void);
int LargeIntegers_primAnyBitFromTo(void);
int LargeIntegers_primDigitSubtractWith(void);
int LargeIntegers_primDigitBitShift(void);
int LargeIntegers_primDigitBitLogicWithOp(void);
int LargeIntegers_primDigitMultiplyNegative(void);
int LargeIntegers_primDigitMultiplyWithNegative(void);
int LargeIntegers_primCheckIfCModuleExists(void);
int LargeIntegers_primDigitCompare(void);
int LargeIntegers_primDigitCompareWith(void);
int LargeIntegers_primDigitBitOr(void);
int LargeIntegers_primNormalizePositive(void);
int LargeIntegers_primDigitAdd(void);
int LargeIntegers_primDigitDivWithNegative(void);
int LargeIntegers_getModuleName(void);
int LargeIntegers_setInterpreter(void);
int LargeIntegers_primNormalizeNegative(void);
int LargeIntegers__primDigitBitShift(void);
int LargeIntegers_primDigitBitAnd(void);
int LargeIntegers_primDigitBitXor(void);
int LargeIntegers_primDigitAddWith(void);
int LargeIntegers_primDigitDivNegative(void);
int LargeIntegers_primAsLargeInteger(void);
int LargeIntegers_primDigitSubtract(void);
int LargeIntegers_primGetModuleName(void);
int LargeIntegers_primDigitBitShiftMagnitude(void);
int LargeIntegers_primNormalize(void);
int FFTPlugin_primitiveFFTScaleData(void);
int FFTPlugin_primitiveFFTTransformData(void);
int FFTPlugin_primitiveFFTPermuteData(void);
int FFTPlugin_getModuleName(void);
int FFTPlugin_setInterpreter(void);
int FloatArrayPlugin_primitiveAtPut(void);
int FloatArrayPlugin_primitiveMulScalar(void);
int FloatArrayPlugin_primitiveDivScalar(void);
int FloatArrayPlugin_primitiveDotProduct(void);
int FloatArrayPlugin_primitiveAddScalar(void);
int FloatArrayPlugin_primitiveEqual(void);
int FloatArrayPlugin_primitiveSubScalar(void);
int FloatArrayPlugin_primitiveDivFloatArray(void);
int FloatArrayPlugin_primitiveMulFloatArray(void);
int FloatArrayPlugin_primitiveAddFloatArray(void);
int FloatArrayPlugin_primitiveSubFloatArray(void);
int FloatArrayPlugin_primitiveHash(void);
int FloatArrayPlugin_primitiveAt(void);
int FloatArrayPlugin_getModuleName(void);
int FloatArrayPlugin_setInterpreter(void);
int Matrix2x3Plugin_primitiveTransformPoint(void);
int Matrix2x3Plugin_primitiveIsIdentity(void);
int Matrix2x3Plugin_primitiveTransformRectInto(void);
int Matrix2x3Plugin_primitiveInvertPoint(void);
int Matrix2x3Plugin_primitiveComposeMatrix(void);
int Matrix2x3Plugin_getModuleName(void);
int Matrix2x3Plugin_primitiveIsPureTranslation(void);
int Matrix2x3Plugin_primitiveInvertRectInto(void);
int Matrix2x3Plugin_setInterpreter(void);
int ZipPlugin_primitiveZipSendBlock(void);
int ZipPlugin_primitiveInflateDecompressBlock(void);
int ZipPlugin_primitiveDeflateBlock(void);
int ZipPlugin_primitiveUpdateGZipCrc32(void);
int ZipPlugin_getModuleName(void);
int ZipPlugin_primitiveDeflateUpdateHashTable(void);
int ZipPlugin_setInterpreter(void);
int Squeak3D_b3dTransformPrimitiveNormal(void);
int Squeak3D_primitiveSetBitBltPlugin(void);
int Squeak3D_b3dTransformMatrixWithInto(void);
int Squeak3D_b3dTransformVertexBuffer(void);
int Squeak3D_b3dRasterizerVersion(void);
int Squeak3D_b3dLoadVertexBuffer(void);
int Squeak3D_b3dTransformPrimitivePosition(void);
int Squeak3D_initialiseModule(void);
int Squeak3D_b3dPrimitiveTextureSize(void);
int Squeak3D_b3dTransformPrimitiveRasterPosition(void);
int Squeak3D_b3dStartRasterizer(void);
int Squeak3D_b3dInitializeRasterizerState(void);
int Squeak3D_b3dPrimitiveNextClippedTriangle(void);
int Squeak3D_b3dComputeMinIndexZ(void);
int Squeak3D_setInterpreter(void);
int Squeak3D_getModuleName(void);
int Squeak3D_b3dShadeVertexBuffer(void);
int Squeak3D_b3dClipPolygon(void);
int Squeak3D_b3dShaderVersion(void);
int Squeak3D_b3dTransformerVersion(void);
int Squeak3D_b3dLoadIndexArray(void);
int Squeak3D_b3dDetermineClipFlags(void);
int Squeak3D_b3dPrimitiveObjectSize(void);
int Squeak3D_b3dComputeMinZ(void);
int Squeak3D_b3dInplaceHouseHolderInvert(void);
int Squeak3D_moduleUnloaded(void);
int Squeak3D_b3dInitPrimitiveObject(void);
int DSAPrims_primitiveHashBlock(void);
int DSAPrims_primitiveExpandBlock(void);
int DSAPrims_primitiveBigMultiply(void);
int DSAPrims_primitiveHasSecureHashPrimitive(void);
int DSAPrims_getModuleName(void);
int DSAPrims_primitiveBigDivide(void);
int DSAPrims_primitiveHighestNonZeroDigitIndex(void);
int DSAPrims_setInterpreter(void);
int DropPlugin_shutdownModule(void);
int DropPlugin_primitiveDropRequestFileName(void);
int DropPlugin_primitiveDropRequestFileHandle(void);
int DropPlugin_getModuleName(void);
int DropPlugin_initialiseModule(void);
int DropPlugin_setInterpreter(void);
int MiscPrimitivePlugin_primitiveIndexOfAsciiInString(void);
int MiscPrimitivePlugin_primitiveCompareString(void);
int MiscPrimitivePlugin_primitiveConvert8BitSigned(void);
int MiscPrimitivePlugin_primitiveFindFirstInString(void);
int MiscPrimitivePlugin_primitiveDecompressFromByteArray(void);
int MiscPrimitivePlugin_primitiveTranslateStringWithTable(void);
int MiscPrimitivePlugin_getModuleName(void);
int MiscPrimitivePlugin_primitiveFindSubstring(void);
int MiscPrimitivePlugin_primitiveCompressToByteArray(void);
int MiscPrimitivePlugin_setInterpreter(void);
/* extra (platform specific) prototypes */
#define XFN(name) int name(void);
#define XFN2(module, name) int module##_##name(void);
#include "platform.exports"
#undef XFN
#undef XFN2


/* Function names */
char *internalPrimitiveNames[][2] = {
{ "", "primitiveDisablePowerManager" },
{ "", "moduleUnloaded" },
{ "BitBltPlugin", "primitiveDrawLoop" },
{ "BitBltPlugin", "initialiseModule" },
{ "BitBltPlugin", "copyBitsFromtoat" },
{ "BitBltPlugin", "loadBitBltFrom" },
{ "BitBltPlugin", "primitiveWarpBits" },
{ "BitBltPlugin", "copyBits" },
{ "BitBltPlugin", "primitiveScanCharacters" },
{ "BitBltPlugin", "getModuleName" },
{ "BitBltPlugin", "primitiveCopyBits" },
{ "BitBltPlugin", "primitiveDisplayString" },
{ "BitBltPlugin", "setInterpreter" },
{ "B2DPlugin", "primitiveSetColorTransform" },
{ "B2DPlugin", "primitiveDisplaySpanBuffer" },
{ "B2DPlugin", "primitiveSetBitBltPlugin" },
{ "B2DPlugin", "primitiveSetEdgeTransform" },
{ "B2DPlugin", "primitiveNextFillEntry" },
{ "B2DPlugin", "primitiveAddActiveEdgeEntry" },
{ "B2DPlugin", "primitiveRenderImage" },
{ "B2DPlugin", "primitiveInitializeProcessing" },
{ "B2DPlugin", "primitiveAddBitmapFill" },
{ "B2DPlugin", "primitiveNextActiveEdgeEntry" },
{ "B2DPlugin", "primitiveAddRect" },
{ "B2DPlugin", "primitiveChangedActiveEdgeEntry" },
{ "B2DPlugin", "primitiveSetAALevel" },
{ "B2DPlugin", "primitiveFinishedProcessing" },
{ "B2DPlugin", "primitiveGetOffset" },
{ "B2DPlugin", "primitiveSetDepth" },
{ "B2DPlugin", "primitiveAddBezier" },
{ "B2DPlugin", "primitiveGetCounts" },
{ "B2DPlugin", "primitiveGetTimes" },
{ "B2DPlugin", "primitiveNeedsFlushPut" },
{ "B2DPlugin", "primitiveGetFailureReason" },
{ "B2DPlugin", "primitiveGetDepth" },
{ "B2DPlugin", "primitiveGetAALevel" },
{ "B2DPlugin", "primitiveGetBezierStats" },
{ "B2DPlugin", "primitiveAbortProcessing" },
{ "B2DPlugin", "primitiveAddPolygon" },
{ "B2DPlugin", "primitiveAddGradientFill" },
{ "B2DPlugin", "primitiveSetOffset" },
{ "B2DPlugin", "initialiseModule" },
{ "B2DPlugin", "primitiveMergeFillFrom" },
{ "B2DPlugin", "primitiveAddLine" },
{ "B2DPlugin", "getModuleName" },
{ "B2DPlugin", "setInterpreter" },
{ "B2DPlugin", "primitiveSetClipRect" },
{ "B2DPlugin", "primitiveDoProfileStats" },
{ "B2DPlugin", "primitiveInitializeBuffer" },
{ "B2DPlugin", "primitiveRegisterExternalEdge" },
{ "B2DPlugin", "primitiveGetClipRect" },
{ "B2DPlugin", "primitiveRegisterExternalFill" },
{ "B2DPlugin", "primitiveAddOval" },
{ "B2DPlugin", "primitiveNeedsFlush" },
{ "B2DPlugin", "primitiveAddCompressedShape" },
{ "B2DPlugin", "primitiveNextGlobalEdgeEntry" },
{ "B2DPlugin", "primitiveCopyBuffer" },
{ "B2DPlugin", "primitiveAddBezierShape" },
{ "B2DPlugin", "moduleUnloaded" },
{ "B2DPlugin", "primitiveRenderScanline" },
{ "SurfacePlugin", "ioGetSurfaceFormat" },
{ "SurfacePlugin", "initialiseModule" },
{ "SurfacePlugin", "shutdownModule" },
{ "SurfacePlugin", "ioLockSurface" },
{ "SurfacePlugin", "ioUnlockSurface" },
{ "SurfacePlugin", "ioUnregisterSurface" },
{ "SurfacePlugin", "ioRegisterSurface" },
{ "SurfacePlugin", "ioFindSurface" },
{ "SurfacePlugin", "ioShowSurface" },
{ "SurfacePlugin", "getModuleName" },
{ "SurfacePlugin", "setInterpreter" },
{ "FilePlugin", "initialiseModule" },
{ "FilePlugin", "primitiveFileGetPosition" },
{ "FilePlugin", "primitiveDirectoryCreate" },
{ "FilePlugin", "primitiveDirectoryDelimitor" },
{ "FilePlugin", "getModuleName" },
{ "FilePlugin", "primitiveDirectorySetMacTypeAndCreator" },
{ "FilePlugin", "primitiveFileDelete" },
{ "FilePlugin", "primitiveFileSetPosition" },
{ "FilePlugin", "primitiveDirectoryDelete" },
{ "FilePlugin", "primitiveDirectoryLookup" },
{ "FilePlugin", "primitiveFileAtEnd" },
{ "FilePlugin", "setInterpreter" },
{ "FilePlugin", "primitiveFileClose" },
{ "FilePlugin", "primitiveFileSize" },
{ "FilePlugin", "primitiveFileRename" },
{ "FilePlugin", "shutdownModule" },
{ "FilePlugin", "primitiveFileOpen" },
{ "FilePlugin", "primitiveDirectoryGetMacTypeAndCreator" },
{ "FilePlugin", "setMacFileTypeAndCreator" },
{ "FilePlugin", "primitiveFileWrite" },
{ "FilePlugin", "primitiveFileRead" },
{ "SocketPlugin", "primitiveResolverAbortLookup" },
{ "SocketPlugin", "primitiveSocketAccept3Semaphores" },
{ "SocketPlugin", "primitiveInitializeNetwork" },
{ "SocketPlugin", "primitiveResolverAddressLookupResult" },
{ "SocketPlugin", "primitiveSocketConnectionStatus" },
{ "SocketPlugin", "primitiveSocketRemotePort" },
{ "SocketPlugin", "primitiveSocketSendDataBufCount" },
{ "SocketPlugin", "primitiveResolverNameLookupResult" },
{ "SocketPlugin", "primitiveSocketListenWithOrWithoutBacklog" },
{ "SocketPlugin", "primitiveSocketDestroy" },
{ "SocketPlugin", "primitiveSocketReceiveDataBufCount" },
{ "SocketPlugin", "primitiveSocketAbortConnection" },
{ "SocketPlugin", "primitiveSocketListenOnPort" },
{ "SocketPlugin", "primitiveSocketError" },
{ "SocketPlugin", "primitiveSocketLocalPort" },
{ "SocketPlugin", "primitiveSocketReceiveUDPDataBufCount" },
{ "SocketPlugin", "primitiveSocketCreate3Semaphores" },
{ "SocketPlugin", "primitiveSocketCreate" },
{ "SocketPlugin", "primitiveSocketRemoteAddress" },
{ "SocketPlugin", "primitiveSocketSetOptions" },
{ "SocketPlugin", "primitiveResolverStatus" },
{ "SocketPlugin", "primitiveResolverStartNameLookup" },
{ "SocketPlugin", "primitiveSocketSendUDPDataBufCount" },
{ "SocketPlugin", "initialiseModule" },
{ "SocketPlugin", "primitiveResolverError" },
{ "SocketPlugin", "primitiveSocketGetOptions" },
{ "SocketPlugin", "getModuleName" },
{ "SocketPlugin", "primitiveResolverLocalAddress" },
{ "SocketPlugin", "setInterpreter" },
{ "SocketPlugin", "primitiveSocketReceiveDataAvailable" },
{ "SocketPlugin", "primitiveResolverStartAddressLookup" },
{ "SocketPlugin", "primitiveSocketSendDone" },
{ "SocketPlugin", "primitiveSocketConnectToPort" },
{ "SocketPlugin", "shutdownModule" },
{ "SocketPlugin", "primitiveSocketLocalAddress" },
{ "SocketPlugin", "primitiveSocketListenOnPortBacklog" },
{ "SocketPlugin", "primitiveSocketAccept" },
{ "SocketPlugin", "primitiveSocketCloseConnection" },
{ "MIDIPlugin", "primitiveMIDIGetPortDirectionality" },
{ "MIDIPlugin", "primitiveMIDIParameterGetOrSet" },
{ "MIDIPlugin", "primitiveMIDIWrite" },
{ "MIDIPlugin", "primitiveMIDIClosePort" },
{ "MIDIPlugin", "primitiveMIDIRead" },
{ "MIDIPlugin", "primitiveMIDIParameterSet" },
{ "MIDIPlugin", "primitiveMIDIGetPortName" },
{ "MIDIPlugin", "shutdownModule" },
{ "MIDIPlugin", "primitiveMIDIOpenPort" },
{ "MIDIPlugin", "primitiveMIDIGetClock" },
{ "MIDIPlugin", "initialiseModule" },
{ "MIDIPlugin", "primitiveMIDIGetPortCount" },
{ "MIDIPlugin", "getModuleName" },
{ "MIDIPlugin", "primitiveMIDIParameterGet" },
{ "MIDIPlugin", "setInterpreter" },
{ "SerialPlugin", "setInterpreter" },
{ "SerialPlugin", "primitiveSerialPortRead" },
{ "SerialPlugin", "primitiveSerialPortClose" },
{ "SerialPlugin", "primitiveSerialPortWrite" },
{ "SerialPlugin", "getModuleName" },
{ "SerialPlugin", "primitiveSerialPortOpen" },
{ "SerialPlugin", "initialiseModule" },
{ "SerialPlugin", "shutdownModule" },
{ "JoystickTabletPlugin", "shutdownModule" },
{ "JoystickTabletPlugin", "initialiseModule" },
{ "JoystickTabletPlugin", "primitiveReadJoystick" },
{ "JoystickTabletPlugin", "primitiveReadTablet" },
{ "JoystickTabletPlugin", "getModuleName" },
{ "JoystickTabletPlugin", "primitiveGetTabletParameters" },
{ "JoystickTabletPlugin", "setInterpreter" },
{ "AsynchFilePlugin", "primitiveAsyncFileReadResult" },
{ "AsynchFilePlugin", "primitiveAsyncFileWriteStart" },
{ "AsynchFilePlugin", "primitiveAsyncFileOpen" },
{ "AsynchFilePlugin", "initialiseModule" },
{ "AsynchFilePlugin", "primitiveAsyncFileClose" },
{ "AsynchFilePlugin", "shutdownModule" },
{ "AsynchFilePlugin", "primitiveAsyncFileWriteResult" },
{ "AsynchFilePlugin", "getModuleName" },
{ "AsynchFilePlugin", "primitiveAsyncFileReadStart" },
{ "AsynchFilePlugin", "setInterpreter" },
{ "SoundPlugin", "primitiveSoundAvailableSpace" },
{ "SoundPlugin", "primitiveSoundStartWithSemaphore" },
{ "SoundPlugin", "primitiveSoundStopRecording" },
{ "SoundPlugin", "primitiveSoundSetRecordLevel" },
{ "SoundPlugin", "primitiveSoundGetRecordingSampleRate" },
{ "SoundPlugin", "primitiveSoundSetLeftVolume" },
{ "SoundPlugin", "primitiveSoundPlaySamples" },
{ "SoundPlugin", "primitiveSoundInsertSamples" },
{ "SoundPlugin", "initialiseModule" },
{ "SoundPlugin", "shutdownModule" },
{ "SoundPlugin", "primitiveSoundStop" },
{ "SoundPlugin", "primitiveSoundStartRecording" },
{ "SoundPlugin", "primitiveSoundRecordSamples" },
{ "SoundPlugin", "primitiveSoundPlaySilence" },
{ "SoundPlugin", "primitiveSoundStart" },
{ "SoundPlugin", "primitiveSoundGetVolume" },
{ "SoundPlugin", "getModuleName" },
{ "SoundPlugin", "setInterpreter" },
{ "SoundGenerationPlugin", "primitiveSampledSoundMix" },
{ "SoundGenerationPlugin", "primitiveFMSoundMix" },
{ "SoundGenerationPlugin", "primitivePluckedSoundMix" },
{ "SoundGenerationPlugin", "primitiveMixSampledSound" },
{ "SoundGenerationPlugin", "primitiveApplyReverb" },
{ "SoundGenerationPlugin", "primitiveMixFMSound" },
{ "SoundGenerationPlugin", "primitiveMixLoopedSampledSound" },
{ "SoundGenerationPlugin", "primitiveWaveTableSoundMix" },
{ "SoundGenerationPlugin", "primitiveMixPluckedSound" },
{ "SoundGenerationPlugin", "primitiveOldSampledSoundMix" },
{ "SoundGenerationPlugin", "getModuleName" },
{ "SoundGenerationPlugin", "setInterpreter" },
{ "ADPCMCodecPlugin", "primitiveDecodeStereo" },
{ "ADPCMCodecPlugin", "primitiveDecodeMono" },
{ "ADPCMCodecPlugin", "primitiveEncodeStereo" },
{ "ADPCMCodecPlugin", "getModuleName" },
{ "ADPCMCodecPlugin", "primitiveEncodeMono" },
{ "ADPCMCodecPlugin", "setInterpreter" },
{ "Klatt", "getModuleName" },
{ "Klatt", "primitiveSynthesizeFrameIntoStartingAt" },
{ "Klatt", "setInterpreter" },
{ "SoundCodecPrims", "primitiveGSMNewState" },
{ "SoundCodecPrims", "primitiveGSMEncode" },
{ "SoundCodecPrims", "getModuleName" },
{ "SoundCodecPrims", "primitiveGSMDecode" },
{ "SoundCodecPrims", "setInterpreter" },
{ "LargeIntegers", "primAnyBitFromTo" },
{ "LargeIntegers", "primDigitSubtractWith" },
{ "LargeIntegers", "primDigitBitShift" },
{ "LargeIntegers", "primDigitBitLogicWithOp" },
{ "LargeIntegers", "primDigitMultiplyNegative" },
{ "LargeIntegers", "primDigitMultiplyWithNegative" },
{ "LargeIntegers", "primCheckIfCModuleExists" },
{ "LargeIntegers", "primDigitCompare" },
{ "LargeIntegers", "primDigitCompareWith" },
{ "LargeIntegers", "primDigitBitOr" },
{ "LargeIntegers", "primNormalizePositive" },
{ "LargeIntegers", "primDigitAdd" },
{ "LargeIntegers", "primDigitDivWithNegative" },
{ "LargeIntegers", "getModuleName" },
{ "LargeIntegers", "setInterpreter" },
{ "LargeIntegers", "primNormalizeNegative" },
{ "LargeIntegers", "_primDigitBitShift" },
{ "LargeIntegers", "primDigitBitAnd" },
{ "LargeIntegers", "primDigitBitXor" },
{ "LargeIntegers", "primDigitAddWith" },
{ "LargeIntegers", "primDigitDivNegative" },
{ "LargeIntegers", "primAsLargeInteger" },
{ "LargeIntegers", "primDigitSubtract" },
{ "LargeIntegers", "primGetModuleName" },
{ "LargeIntegers", "primDigitBitShiftMagnitude" },
{ "LargeIntegers", "primNormalize" },
{ "FFTPlugin", "primitiveFFTScaleData" },
{ "FFTPlugin", "primitiveFFTTransformData" },
{ "FFTPlugin", "primitiveFFTPermuteData" },
{ "FFTPlugin", "getModuleName" },
{ "FFTPlugin", "setInterpreter" },
{ "FloatArrayPlugin", "primitiveAtPut" },
{ "FloatArrayPlugin", "primitiveMulScalar" },
{ "FloatArrayPlugin", "primitiveDivScalar" },
{ "FloatArrayPlugin", "primitiveDotProduct" },
{ "FloatArrayPlugin", "primitiveAddScalar" },
{ "FloatArrayPlugin", "primitiveEqual" },
{ "FloatArrayPlugin", "primitiveSubScalar" },
{ "FloatArrayPlugin", "primitiveDivFloatArray" },
{ "FloatArrayPlugin", "primitiveMulFloatArray" },
{ "FloatArrayPlugin", "primitiveAddFloatArray" },
{ "FloatArrayPlugin", "primitiveSubFloatArray" },
{ "FloatArrayPlugin", "primitiveHash" },
{ "FloatArrayPlugin", "primitiveAt" },
{ "FloatArrayPlugin", "getModuleName" },
{ "FloatArrayPlugin", "setInterpreter" },
{ "Matrix2x3Plugin", "primitiveTransformPoint" },
{ "Matrix2x3Plugin", "primitiveIsIdentity" },
{ "Matrix2x3Plugin", "primitiveTransformRectInto" },
{ "Matrix2x3Plugin", "primitiveInvertPoint" },
{ "Matrix2x3Plugin", "primitiveComposeMatrix" },
{ "Matrix2x3Plugin", "getModuleName" },
{ "Matrix2x3Plugin", "primitiveIsPureTranslation" },
{ "Matrix2x3Plugin", "primitiveInvertRectInto" },
{ "Matrix2x3Plugin", "setInterpreter" },
{ "ZipPlugin", "primitiveZipSendBlock" },
{ "ZipPlugin", "primitiveInflateDecompressBlock" },
{ "ZipPlugin", "primitiveDeflateBlock" },
{ "ZipPlugin", "primitiveUpdateGZipCrc32" },
{ "ZipPlugin", "getModuleName" },
{ "ZipPlugin", "primitiveDeflateUpdateHashTable" },
{ "ZipPlugin", "setInterpreter" },
{ "Squeak3D", "b3dTransformPrimitiveNormal" },
{ "Squeak3D", "primitiveSetBitBltPlugin" },
{ "Squeak3D", "b3dTransformMatrixWithInto" },
{ "Squeak3D", "b3dTransformVertexBuffer" },
{ "Squeak3D", "b3dRasterizerVersion" },
{ "Squeak3D", "b3dLoadVertexBuffer" },
{ "Squeak3D", "b3dTransformPrimitivePosition" },
{ "Squeak3D", "initialiseModule" },
{ "Squeak3D", "b3dPrimitiveTextureSize" },
{ "Squeak3D", "b3dTransformPrimitiveRasterPosition" },
{ "Squeak3D", "b3dStartRasterizer" },
{ "Squeak3D", "b3dInitializeRasterizerState" },
{ "Squeak3D", "b3dPrimitiveNextClippedTriangle" },
{ "Squeak3D", "b3dComputeMinIndexZ" },
{ "Squeak3D", "setInterpreter" },
{ "Squeak3D", "getModuleName" },
{ "Squeak3D", "b3dShadeVertexBuffer" },
{ "Squeak3D", "b3dClipPolygon" },
{ "Squeak3D", "b3dShaderVersion" },
{ "Squeak3D", "b3dTransformerVersion" },
{ "Squeak3D", "b3dLoadIndexArray" },
{ "Squeak3D", "b3dDetermineClipFlags" },
{ "Squeak3D", "b3dPrimitiveObjectSize" },
{ "Squeak3D", "b3dComputeMinZ" },
{ "Squeak3D", "b3dInplaceHouseHolderInvert" },
{ "Squeak3D", "moduleUnloaded" },
{ "Squeak3D", "b3dInitPrimitiveObject" },
{ "DSAPrims", "primitiveHashBlock" },
{ "DSAPrims", "primitiveExpandBlock" },
{ "DSAPrims", "primitiveBigMultiply" },
{ "DSAPrims", "primitiveHasSecureHashPrimitive" },
{ "DSAPrims", "getModuleName" },
{ "DSAPrims", "primitiveBigDivide" },
{ "DSAPrims", "primitiveHighestNonZeroDigitIndex" },
{ "DSAPrims", "setInterpreter" },
{ "DropPlugin", "shutdownModule" },
{ "DropPlugin", "primitiveDropRequestFileName" },
{ "DropPlugin", "primitiveDropRequestFileHandle" },
{ "DropPlugin", "getModuleName" },
{ "DropPlugin", "initialiseModule" },
{ "DropPlugin", "setInterpreter" },
{ "MiscPrimitivePlugin", "primitiveIndexOfAsciiInString" },
{ "MiscPrimitivePlugin", "primitiveCompareString" },
{ "MiscPrimitivePlugin", "primitiveConvert8BitSigned" },
{ "MiscPrimitivePlugin", "primitiveFindFirstInString" },
{ "MiscPrimitivePlugin", "primitiveDecompressFromByteArray" },
{ "MiscPrimitivePlugin", "primitiveTranslateStringWithTable" },
{ "MiscPrimitivePlugin", "getModuleName" },
{ "MiscPrimitivePlugin", "primitiveFindSubstring" },
{ "MiscPrimitivePlugin", "primitiveCompressToByteArray" },
{ "MiscPrimitivePlugin", "setInterpreter" },
/* extra (platform specific) names */
#define XFN(name) { "", #name },
#define XFN2(module, name) { #module, #name },
#include "platform.exports"
#undef XFN
#undef XFN2
{ NULL, NULL }
};

/* Function addresses */
void *internalPrimitiveAddresses[] = {
(void*)primitiveDisablePowerManager,
(void*)moduleUnloaded,
(void*)BitBltPlugin_primitiveDrawLoop,
(void*)BitBltPlugin_initialiseModule,
(void*)BitBltPlugin_copyBitsFromtoat,
(void*)BitBltPlugin_loadBitBltFrom,
(void*)BitBltPlugin_primitiveWarpBits,
(void*)BitBltPlugin_copyBits,
(void*)BitBltPlugin_primitiveScanCharacters,
(void*)BitBltPlugin_getModuleName,
(void*)BitBltPlugin_primitiveCopyBits,
(void*)BitBltPlugin_primitiveDisplayString,
(void*)BitBltPlugin_setInterpreter,
(void*)B2DPlugin_primitiveSetColorTransform,
(void*)B2DPlugin_primitiveDisplaySpanBuffer,
(void*)B2DPlugin_primitiveSetBitBltPlugin,
(void*)B2DPlugin_primitiveSetEdgeTransform,
(void*)B2DPlugin_primitiveNextFillEntry,
(void*)B2DPlugin_primitiveAddActiveEdgeEntry,
(void*)B2DPlugin_primitiveRenderImage,
(void*)B2DPlugin_primitiveInitializeProcessing,
(void*)B2DPlugin_primitiveAddBitmapFill,
(void*)B2DPlugin_primitiveNextActiveEdgeEntry,
(void*)B2DPlugin_primitiveAddRect,
(void*)B2DPlugin_primitiveChangedActiveEdgeEntry,
(void*)B2DPlugin_primitiveSetAALevel,
(void*)B2DPlugin_primitiveFinishedProcessing,
(void*)B2DPlugin_primitiveGetOffset,
(void*)B2DPlugin_primitiveSetDepth,
(void*)B2DPlugin_primitiveAddBezier,
(void*)B2DPlugin_primitiveGetCounts,
(void*)B2DPlugin_primitiveGetTimes,
(void*)B2DPlugin_primitiveNeedsFlushPut,
(void*)B2DPlugin_primitiveGetFailureReason,
(void*)B2DPlugin_primitiveGetDepth,
(void*)B2DPlugin_primitiveGetAALevel,
(void*)B2DPlugin_primitiveGetBezierStats,
(void*)B2DPlugin_primitiveAbortProcessing,
(void*)B2DPlugin_primitiveAddPolygon,
(void*)B2DPlugin_primitiveAddGradientFill,
(void*)B2DPlugin_primitiveSetOffset,
(void*)B2DPlugin_initialiseModule,
(void*)B2DPlugin_primitiveMergeFillFrom,
(void*)B2DPlugin_primitiveAddLine,
(void*)B2DPlugin_getModuleName,
(void*)B2DPlugin_setInterpreter,
(void*)B2DPlugin_primitiveSetClipRect,
(void*)B2DPlugin_primitiveDoProfileStats,
(void*)B2DPlugin_primitiveInitializeBuffer,
(void*)B2DPlugin_primitiveRegisterExternalEdge,
(void*)B2DPlugin_primitiveGetClipRect,
(void*)B2DPlugin_primitiveRegisterExternalFill,
(void*)B2DPlugin_primitiveAddOval,
(void*)B2DPlugin_primitiveNeedsFlush,
(void*)B2DPlugin_primitiveAddCompressedShape,
(void*)B2DPlugin_primitiveNextGlobalEdgeEntry,
(void*)B2DPlugin_primitiveCopyBuffer,
(void*)B2DPlugin_primitiveAddBezierShape,
(void*)B2DPlugin_moduleUnloaded,
(void*)B2DPlugin_primitiveRenderScanline,
(void*)SurfacePlugin_ioGetSurfaceFormat,
(void*)SurfacePlugin_initialiseModule,
(void*)SurfacePlugin_shutdownModule,
(void*)SurfacePlugin_ioLockSurface,
(void*)SurfacePlugin_ioUnlockSurface,
(void*)SurfacePlugin_ioUnregisterSurface,
(void*)SurfacePlugin_ioRegisterSurface,
(void*)SurfacePlugin_ioFindSurface,
(void*)SurfacePlugin_ioShowSurface,
(void*)SurfacePlugin_getModuleName,
(void*)SurfacePlugin_setInterpreter,
(void*)FilePlugin_initialiseModule,
(void*)FilePlugin_primitiveFileGetPosition,
(void*)FilePlugin_primitiveDirectoryCreate,
(void*)FilePlugin_primitiveDirectoryDelimitor,
(void*)FilePlugin_getModuleName,
(void*)FilePlugin_primitiveDirectorySetMacTypeAndCreator,
(void*)FilePlugin_primitiveFileDelete,
(void*)FilePlugin_primitiveFileSetPosition,
(void*)FilePlugin_primitiveDirectoryDelete,
(void*)FilePlugin_primitiveDirectoryLookup,
(void*)FilePlugin_primitiveFileAtEnd,
(void*)FilePlugin_setInterpreter,
(void*)FilePlugin_primitiveFileClose,
(void*)FilePlugin_primitiveFileSize,
(void*)FilePlugin_primitiveFileRename,
(void*)FilePlugin_shutdownModule,
(void*)FilePlugin_primitiveFileOpen,
(void*)FilePlugin_primitiveDirectoryGetMacTypeAndCreator,
(void*)FilePlugin_setMacFileTypeAndCreator,
(void*)FilePlugin_primitiveFileWrite,
(void*)FilePlugin_primitiveFileRead,
(void*)SocketPlugin_primitiveResolverAbortLookup,
(void*)SocketPlugin_primitiveSocketAccept3Semaphores,
(void*)SocketPlugin_primitiveInitializeNetwork,
(void*)SocketPlugin_primitiveResolverAddressLookupResult,
(void*)SocketPlugin_primitiveSocketConnectionStatus,
(void*)SocketPlugin_primitiveSocketRemotePort,
(void*)SocketPlugin_primitiveSocketSendDataBufCount,
(void*)SocketPlugin_primitiveResolverNameLookupResult,
(void*)SocketPlugin_primitiveSocketListenWithOrWithoutBacklog,
(void*)SocketPlugin_primitiveSocketDestroy,
(void*)SocketPlugin_primitiveSocketReceiveDataBufCount,
(void*)SocketPlugin_primitiveSocketAbortConnection,
(void*)SocketPlugin_primitiveSocketListenOnPort,
(void*)SocketPlugin_primitiveSocketError,
(void*)SocketPlugin_primitiveSocketLocalPort,
(void*)SocketPlugin_primitiveSocketReceiveUDPDataBufCount,
(void*)SocketPlugin_primitiveSocketCreate3Semaphores,
(void*)SocketPlugin_primitiveSocketCreate,
(void*)SocketPlugin_primitiveSocketRemoteAddress,
(void*)SocketPlugin_primitiveSocketSetOptions,
(void*)SocketPlugin_primitiveResolverStatus,
(void*)SocketPlugin_primitiveResolverStartNameLookup,
(void*)SocketPlugin_primitiveSocketSendUDPDataBufCount,
(void*)SocketPlugin_initialiseModule,
(void*)SocketPlugin_primitiveResolverError,
(void*)SocketPlugin_primitiveSocketGetOptions,
(void*)SocketPlugin_getModuleName,
(void*)SocketPlugin_primitiveResolverLocalAddress,
(void*)SocketPlugin_setInterpreter,
(void*)SocketPlugin_primitiveSocketReceiveDataAvailable,
(void*)SocketPlugin_primitiveResolverStartAddressLookup,
(void*)SocketPlugin_primitiveSocketSendDone,
(void*)SocketPlugin_primitiveSocketConnectToPort,
(void*)SocketPlugin_shutdownModule,
(void*)SocketPlugin_primitiveSocketLocalAddress,
(void*)SocketPlugin_primitiveSocketListenOnPortBacklog,
(void*)SocketPlugin_primitiveSocketAccept,
(void*)SocketPlugin_primitiveSocketCloseConnection,
(void*)MIDIPlugin_primitiveMIDIGetPortDirectionality,
(void*)MIDIPlugin_primitiveMIDIParameterGetOrSet,
(void*)MIDIPlugin_primitiveMIDIWrite,
(void*)MIDIPlugin_primitiveMIDIClosePort,
(void*)MIDIPlugin_primitiveMIDIRead,
(void*)MIDIPlugin_primitiveMIDIParameterSet,
(void*)MIDIPlugin_primitiveMIDIGetPortName,
(void*)MIDIPlugin_shutdownModule,
(void*)MIDIPlugin_primitiveMIDIOpenPort,
(void*)MIDIPlugin_primitiveMIDIGetClock,
(void*)MIDIPlugin_initialiseModule,
(void*)MIDIPlugin_primitiveMIDIGetPortCount,
(void*)MIDIPlugin_getModuleName,
(void*)MIDIPlugin_primitiveMIDIParameterGet,
(void*)MIDIPlugin_setInterpreter,
(void*)SerialPlugin_setInterpreter,
(void*)SerialPlugin_primitiveSerialPortRead,
(void*)SerialPlugin_primitiveSerialPortClose,
(void*)SerialPlugin_primitiveSerialPortWrite,
(void*)SerialPlugin_getModuleName,
(void*)SerialPlugin_primitiveSerialPortOpen,
(void*)SerialPlugin_initialiseModule,
(void*)SerialPlugin_shutdownModule,
(void*)JoystickTabletPlugin_shutdownModule,
(void*)JoystickTabletPlugin_initialiseModule,
(void*)JoystickTabletPlugin_primitiveReadJoystick,
(void*)JoystickTabletPlugin_primitiveReadTablet,
(void*)JoystickTabletPlugin_getModuleName,
(void*)JoystickTabletPlugin_primitiveGetTabletParameters,
(void*)JoystickTabletPlugin_setInterpreter,
(void*)AsynchFilePlugin_primitiveAsyncFileReadResult,
(void*)AsynchFilePlugin_primitiveAsyncFileWriteStart,
(void*)AsynchFilePlugin_primitiveAsyncFileOpen,
(void*)AsynchFilePlugin_initialiseModule,
(void*)AsynchFilePlugin_primitiveAsyncFileClose,
(void*)AsynchFilePlugin_shutdownModule,
(void*)AsynchFilePlugin_primitiveAsyncFileWriteResult,
(void*)AsynchFilePlugin_getModuleName,
(void*)AsynchFilePlugin_primitiveAsyncFileReadStart,
(void*)AsynchFilePlugin_setInterpreter,
(void*)SoundPlugin_primitiveSoundAvailableSpace,
(void*)SoundPlugin_primitiveSoundStartWithSemaphore,
(void*)SoundPlugin_primitiveSoundStopRecording,
(void*)SoundPlugin_primitiveSoundSetRecordLevel,
(void*)SoundPlugin_primitiveSoundGetRecordingSampleRate,
(void*)SoundPlugin_primitiveSoundSetLeftVolume,
(void*)SoundPlugin_primitiveSoundPlaySamples,
(void*)SoundPlugin_primitiveSoundInsertSamples,
(void*)SoundPlugin_initialiseModule,
(void*)SoundPlugin_shutdownModule,
(void*)SoundPlugin_primitiveSoundStop,
(void*)SoundPlugin_primitiveSoundStartRecording,
(void*)SoundPlugin_primitiveSoundRecordSamples,
(void*)SoundPlugin_primitiveSoundPlaySilence,
(void*)SoundPlugin_primitiveSoundStart,
(void*)SoundPlugin_primitiveSoundGetVolume,
(void*)SoundPlugin_getModuleName,
(void*)SoundPlugin_setInterpreter,
(void*)SoundGenerationPlugin_primitiveSampledSoundMix,
(void*)SoundGenerationPlugin_primitiveFMSoundMix,
(void*)SoundGenerationPlugin_primitivePluckedSoundMix,
(void*)SoundGenerationPlugin_primitiveMixSampledSound,
(void*)SoundGenerationPlugin_primitiveApplyReverb,
(void*)SoundGenerationPlugin_primitiveMixFMSound,
(void*)SoundGenerationPlugin_primitiveMixLoopedSampledSound,
(void*)SoundGenerationPlugin_primitiveWaveTableSoundMix,
(void*)SoundGenerationPlugin_primitiveMixPluckedSound,
(void*)SoundGenerationPlugin_primitiveOldSampledSoundMix,
(void*)SoundGenerationPlugin_getModuleName,
(void*)SoundGenerationPlugin_setInterpreter,
(void*)ADPCMCodecPlugin_primitiveDecodeStereo,
(void*)ADPCMCodecPlugin_primitiveDecodeMono,
(void*)ADPCMCodecPlugin_primitiveEncodeStereo,
(void*)ADPCMCodecPlugin_getModuleName,
(void*)ADPCMCodecPlugin_primitiveEncodeMono,
(void*)ADPCMCodecPlugin_setInterpreter,
(void*)Klatt_getModuleName,
(void*)Klatt_primitiveSynthesizeFrameIntoStartingAt,
(void*)Klatt_setInterpreter,
(void*)SoundCodecPrims_primitiveGSMNewState,
(void*)SoundCodecPrims_primitiveGSMEncode,
(void*)SoundCodecPrims_getModuleName,
(void*)SoundCodecPrims_primitiveGSMDecode,
(void*)SoundCodecPrims_setInterpreter,
(void*)LargeIntegers_primAnyBitFromTo,
(void*)LargeIntegers_primDigitSubtractWith,
(void*)LargeIntegers_primDigitBitShift,
(void*)LargeIntegers_primDigitBitLogicWithOp,
(void*)LargeIntegers_primDigitMultiplyNegative,
(void*)LargeIntegers_primDigitMultiplyWithNegative,
(void*)LargeIntegers_primCheckIfCModuleExists,
(void*)LargeIntegers_primDigitCompare,
(void*)LargeIntegers_primDigitCompareWith,
(void*)LargeIntegers_primDigitBitOr,
(void*)LargeIntegers_primNormalizePositive,
(void*)LargeIntegers_primDigitAdd,
(void*)LargeIntegers_primDigitDivWithNegative,
(void*)LargeIntegers_getModuleName,
(void*)LargeIntegers_setInterpreter,
(void*)LargeIntegers_primNormalizeNegative,
(void*)LargeIntegers__primDigitBitShift,
(void*)LargeIntegers_primDigitBitAnd,
(void*)LargeIntegers_primDigitBitXor,
(void*)LargeIntegers_primDigitAddWith,
(void*)LargeIntegers_primDigitDivNegative,
(void*)LargeIntegers_primAsLargeInteger,
(void*)LargeIntegers_primDigitSubtract,
(void*)LargeIntegers_primGetModuleName,
(void*)LargeIntegers_primDigitBitShiftMagnitude,
(void*)LargeIntegers_primNormalize,
(void*)FFTPlugin_primitiveFFTScaleData,
(void*)FFTPlugin_primitiveFFTTransformData,
(void*)FFTPlugin_primitiveFFTPermuteData,
(void*)FFTPlugin_getModuleName,
(void*)FFTPlugin_setInterpreter,
(void*)FloatArrayPlugin_primitiveAtPut,
(void*)FloatArrayPlugin_primitiveMulScalar,
(void*)FloatArrayPlugin_primitiveDivScalar,
(void*)FloatArrayPlugin_primitiveDotProduct,
(void*)FloatArrayPlugin_primitiveAddScalar,
(void*)FloatArrayPlugin_primitiveEqual,
(void*)FloatArrayPlugin_primitiveSubScalar,
(void*)FloatArrayPlugin_primitiveDivFloatArray,
(void*)FloatArrayPlugin_primitiveMulFloatArray,
(void*)FloatArrayPlugin_primitiveAddFloatArray,
(void*)FloatArrayPlugin_primitiveSubFloatArray,
(void*)FloatArrayPlugin_primitiveHash,
(void*)FloatArrayPlugin_primitiveAt,
(void*)FloatArrayPlugin_getModuleName,
(void*)FloatArrayPlugin_setInterpreter,
(void*)Matrix2x3Plugin_primitiveTransformPoint,
(void*)Matrix2x3Plugin_primitiveIsIdentity,
(void*)Matrix2x3Plugin_primitiveTransformRectInto,
(void*)Matrix2x3Plugin_primitiveInvertPoint,
(void*)Matrix2x3Plugin_primitiveComposeMatrix,
(void*)Matrix2x3Plugin_getModuleName,
(void*)Matrix2x3Plugin_primitiveIsPureTranslation,
(void*)Matrix2x3Plugin_primitiveInvertRectInto,
(void*)Matrix2x3Plugin_setInterpreter,
(void*)ZipPlugin_primitiveZipSendBlock,
(void*)ZipPlugin_primitiveInflateDecompressBlock,
(void*)ZipPlugin_primitiveDeflateBlock,
(void*)ZipPlugin_primitiveUpdateGZipCrc32,
(void*)ZipPlugin_getModuleName,
(void*)ZipPlugin_primitiveDeflateUpdateHashTable,
(void*)ZipPlugin_setInterpreter,
(void*)Squeak3D_b3dTransformPrimitiveNormal,
(void*)Squeak3D_primitiveSetBitBltPlugin,
(void*)Squeak3D_b3dTransformMatrixWithInto,
(void*)Squeak3D_b3dTransformVertexBuffer,
(void*)Squeak3D_b3dRasterizerVersion,
(void*)Squeak3D_b3dLoadVertexBuffer,
(void*)Squeak3D_b3dTransformPrimitivePosition,
(void*)Squeak3D_initialiseModule,
(void*)Squeak3D_b3dPrimitiveTextureSize,
(void*)Squeak3D_b3dTransformPrimitiveRasterPosition,
(void*)Squeak3D_b3dStartRasterizer,
(void*)Squeak3D_b3dInitializeRasterizerState,
(void*)Squeak3D_b3dPrimitiveNextClippedTriangle,
(void*)Squeak3D_b3dComputeMinIndexZ,
(void*)Squeak3D_setInterpreter,
(void*)Squeak3D_getModuleName,
(void*)Squeak3D_b3dShadeVertexBuffer,
(void*)Squeak3D_b3dClipPolygon,
(void*)Squeak3D_b3dShaderVersion,
(void*)Squeak3D_b3dTransformerVersion,
(void*)Squeak3D_b3dLoadIndexArray,
(void*)Squeak3D_b3dDetermineClipFlags,
(void*)Squeak3D_b3dPrimitiveObjectSize,
(void*)Squeak3D_b3dComputeMinZ,
(void*)Squeak3D_b3dInplaceHouseHolderInvert,
(void*)Squeak3D_moduleUnloaded,
(void*)Squeak3D_b3dInitPrimitiveObject,
(void*)DSAPrims_primitiveHashBlock,
(void*)DSAPrims_primitiveExpandBlock,
(void*)DSAPrims_primitiveBigMultiply,
(void*)DSAPrims_primitiveHasSecureHashPrimitive,
(void*)DSAPrims_getModuleName,
(void*)DSAPrims_primitiveBigDivide,
(void*)DSAPrims_primitiveHighestNonZeroDigitIndex,
(void*)DSAPrims_setInterpreter,
(void*)DropPlugin_shutdownModule,
(void*)DropPlugin_primitiveDropRequestFileName,
(void*)DropPlugin_primitiveDropRequestFileHandle,
(void*)DropPlugin_getModuleName,
(void*)DropPlugin_initialiseModule,
(void*)DropPlugin_setInterpreter,
(void*)MiscPrimitivePlugin_primitiveIndexOfAsciiInString,
(void*)MiscPrimitivePlugin_primitiveCompareString,
(void*)MiscPrimitivePlugin_primitiveConvert8BitSigned,
(void*)MiscPrimitivePlugin_primitiveFindFirstInString,
(void*)MiscPrimitivePlugin_primitiveDecompressFromByteArray,
(void*)MiscPrimitivePlugin_primitiveTranslateStringWithTable,
(void*)MiscPrimitivePlugin_getModuleName,
(void*)MiscPrimitivePlugin_primitiveFindSubstring,
(void*)MiscPrimitivePlugin_primitiveCompressToByteArray,
(void*)MiscPrimitivePlugin_setInterpreter,
/* extra (platform specific) addresses */
#define XFN(name) (void*) name,
#define XFN2(module, name) (void*) module##_##name,
#include "platform.exports"
#undef XFN
#undef XFN2
NULL
};

